import React, { useState, useEffect } from 'react';
import { IdxTopNav } from './components/idx/IdxTopNav';
import { IdxSidebar, NavItemKey } from './components/idx/IdxSidebar';
import { FeatureStatusBanner } from './components/idx/featureStatus';
import { CreateLiquidityPoolView } from './components/idx/CreateLiquidityPoolView';
import { BotDashboardView } from './components/idx/BotDashboardView';
import { VolumeBotView } from './components/idx/VolumeBotView';
import { ManageLiquidityView } from './components/idx/ManageLiquidityView';
import { HoldersMakerView } from './components/idx/HoldersMakerView';
import { CreateTokenProView } from './components/idx/CreateTokenProView';
import { TokenHubView } from './components/idx/TokenHubView';
import { TokenBurnView } from './components/idx/TokenBurnView';
import { BulkSenderView } from './components/idx/BulkSenderView';
import { UpdateMetadataView } from './components/idx/UpdateMetadataView';
import { RevokeAuthoritiesView } from './components/idx/RevokeAuthoritiesView';
import { LiquiditySimulatorView } from './components/idx/LiquiditySimulatorView';
import { FastSwapView } from './components/idx/FastSwapView';
import { ReactionBoosterView } from './components/idx/ReactionBoosterView';
import { LaunchlabView } from './components/idx/LaunchlabView';
import { IdxExchangeView } from './components/idx/IdxExchangeView';
import { PumpFlywheelView } from './components/idx/PumpFlywheelView';
import { OmegaOperatorView } from './components/operator/OmegaOperatorView';
import { BlankNetworkBalanceView } from './components/blank/BlankNetworkBalanceView';
import { BashamStakingPoolsView } from './components/basham/BashamStakingPoolsView';
import { BashamMemeLaunchView } from './components/basham/BashamMemeLaunchView';
import { PumpBondingCurvePoolPage } from './components/idx/PumpBondingCurvePoolPage';
import { HotWalletsNetworkView } from './components/wallets/HotWalletsNetworkView';
import { RealOnChainBalancesPanel } from './components/idx/RealOnChainBalancesPanel';
import { LaunchpadView } from './components/launchpad/LaunchpadView';

import type {
  TokenMetadata,
  RaydiumPool,
  VolumeBotConfig,
  HoldersMakerConfig,
  ReactionBoosterState,
  TokenLiveState,
  FlywheelState,
  FlywheelConfig,
  LedgerEntry,
  SyndicateWallet,
  RebalanceCycleState,
  WalletState,
} from './types';

export function App() {
  // The on-chain launchpad is the home screen
  const [activeTab, setActiveTab] = useState<NavItemKey>('launchpad');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Raydium & IDX AutoBot State (Default to Solana Mainnet-Beta)
  const [cluster, setCluster] = useState<'mainnet-beta' | 'devnet'>('mainnet-beta');
  const [tokens, setTokens] = useState<TokenMetadata[]>([]);
  const [pools, setPools] = useState<RaydiumPool[]>([]);
  const [wallet, setWallet] = useState<WalletState>({
    address: 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i',
    formattedAddress: 'HTN1...ZV5i',
    solBalance: 0.003051937,
    network: 'Solana Mainnet-Beta',
    cluster: 'mainnet-beta',
    tokens: [],
  });

  const [volumeConfig, setVolumeConfig] = useState<VolumeBotConfig>({
    enabled: true,
    mode: 'MICRO',
    targetVolume24hSol: 1.5,
    minTradeSol: 0.0005,
    maxTradeSol: 0.0025,
    intervalSeconds: 20,
    buySellRatioPct: 80,
    slippagePct: 1.0,
    totalVolumeGeneratedSol: 0.018418,
    totalTradesExecuted: 7,
    activeWalletsCount: 1,
    recentTrades: [],
  });

  const [holdersConfig, setHoldersConfig] = useState<HoldersMakerConfig>({
    status: 'IDLE',
    targetHoldersCount: 100,
    currentHoldersCount: 18,
    tokenMint: 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3',
    tokenSymbol: 'RARINU',
    amountPerWallet: 10000,
    solGasPerWallet: 0.0005,
    wallets: [],
    totalDistributedTokens: 0,
    totalSolGasSpent: 0,
  });

  const [reactions, setReactions] = useState<ReactionBoosterState>({
    rocketsCount: 1420,
    firesCount: 980,
    bullsCount: 1150,
    heartsCount: 840,
    dexScreenerTrendingScore: 94.5,
    pumpFunSentimentPct: 98.2,
    autoBoostEnabled: true,
    lastBoostTimestamp: Date.now(),
  });

  // Pump Mechanisms State
  const [tokenState, setTokenState] = useState<TokenLiveState | null>(null);
  const [flywheelState, setFlywheelState] = useState<FlywheelState | null>(null);
  const [config, setConfig] = useState<FlywheelConfig | null>(null);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [syndicateWallets, setSyndicateWallets] = useState<SyndicateWallet[]>([]);
  const [rebalanceCycle, setRebalanceCycle] = useState<RebalanceCycleState | null>(null);

  const fetchWalletData = async () => {
    try {
      const [resWallet, resRealDetails, resTokens] = await Promise.all([
        fetch('/api/wallet/status'),
        fetch(`/api/solana/wallet-details?address=${wallet.address}&cluster=${cluster}`),
        fetch('/api/tokens/list'),
      ]);

      let currentTokens: TokenMetadata[] = [];
      if (resTokens.ok) {
        const d = await resTokens.json();
        if (d.tokens) {
          currentTokens = d.tokens;
          setTokens(d.tokens);
        }
      }

      if (resRealDetails.ok) {
        const d = await resRealDetails.json();
        if (d.ok) {
          setWallet((prev) => ({
            ...prev,
            solBalance: d.solBalance,
            solBalanceUsd: d.solBalanceUsd,
            cluster: d.cluster,
            network: d.network,
            tokenAccounts: d.tokenAccounts,
            recentSignatures: d.recentSignatures,
            tokens: currentTokens.length > 0 ? currentTokens : prev.tokens,
          }));
        }
      } else if (resWallet.ok) {
        const d = await resWallet.json();
        if (d.wallet) setWallet(d.wallet);
      }
    } catch {
      // Graceful retain
    }
  };

  const fetchFastData = async () => {
    try {
      const [
        resPools,
        resVol,
        resHolders,
        resReact,
        resFlywheel,
        resLedger,
        resSynd,
        resCycle,
      ] = await Promise.all([
        fetch('/api/raydium/pools'),
        fetch('/api/bot/volume/status'),
        fetch('/api/bot/holders/status'),
        fetch('/api/bot/reactions/status'),
        fetch('/api/flywheel/status'),
        fetch('/api/flywheel/ledger?limit=30'),
        fetch('/api/syndicate/wallets'),
        fetch('/api/syndicate/cycle'),
      ]);

      if (resPools.ok) {
        const d = await resPools.json();
        if (d.pools) setPools(d.pools);
      }
      if (resVol.ok) {
        const d = await resVol.json();
        if (d.config) setVolumeConfig(d.config);
      }
      if (resHolders.ok) {
        const d = await resHolders.json();
        if (d.config) setHoldersConfig(d.config);
      }
      if (resReact.ok) {
        const d = await resReact.json();
        if (d.reactions) setReactions(d.reactions);
      }
      if (resFlywheel.ok) {
        const d = await resFlywheel.json();
        if (d.token) setTokenState(d.token);
        if (d.state) setFlywheelState(d.state);
        if (d.config) setConfig(d.config);
      }
      if (resLedger.ok) {
        const d = await resLedger.json();
        if (Array.isArray(d)) setLedger(d);
      }
      if (resSynd.ok) {
        const d = await resSynd.json();
        if (d.wallets) setSyndicateWallets(d.wallets);
      }
      if (resCycle.ok) {
        const d = await resCycle.json();
        if (d.cycle) setRebalanceCycle(d.cycle);
      }
    } catch {
      // Graceful retain
    }
  };

  const fetchAllData = async () => {
    await Promise.all([fetchWalletData(), fetchFastData()]);
  };

  useEffect(() => {
    fetchAllData();
    const fastInterval = setInterval(fetchFastData, 5000);
    const walletInterval = setInterval(fetchWalletData, 20000);
    return () => {
      clearInterval(fastInterval);
      clearInterval(walletInterval);
    };
  }, [wallet.address, cluster]);

  const handleTriggerBurst = async () => {
    try {
      await fetch('/api/bot/volume/burst', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountSol: 0.5 }),
      });
      fetchAllData();
    } catch (e) {
      console.warn('Trigger burst notice:', e);
    }
  };

  const handleTriggerPump = async () => {
    try {
      await fetch('/api/pump/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountSol: 0.05 }),
      });
      fetchAllData();
    } catch (e) {
      console.warn('Trigger pump notice:', e);
    }
  };

  const handleUpdateVolumeConfig = async (updates: Partial<VolumeBotConfig>) => {
    try {
      await fetch('/api/bot/volume/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      fetchAllData();
    } catch (e) {
      console.warn('Update volume notice:', e);
    }
  };

  return (
    <div className="min-h-screen bg-[#06080e] text-[#f1f5f9] flex flex-col font-sans selection:bg-[#0284c7] selection:text-white">
      {/* Top Header Navigation matching screenshot */}
      <IdxTopNav
        activeTab={activeTab}
        onNavigate={(tab) => setActiveTab(tab)}
        wallet={wallet}
        tokens={tokens}
        cluster={cluster}
        onClusterChange={(c) => {
          setCluster(c);
          setWallet((prev) => ({
            ...prev,
            cluster: c,
            network: c === 'mainnet-beta' ? 'Solana Mainnet-Beta' : 'Solana Devnet',
          }));
        }}
        onRefreshWallet={fetchAllData}
        onWalletAddressChange={(address, providerName) => {
          setWallet((prev) => ({
            ...prev,
            address,
            formattedAddress: `${address.slice(0, 4)}...${address.slice(-4)}`,
            provider: providerName || 'Connected',
          }));
          fetch(`/api/solana/wallet-details?address=${address}&cluster=${cluster}`)
            .then((r) => r.json())
            .then((d) => {
              if (d.ok) {
                setWallet((prev) => ({
                  ...prev,
                  solBalance: d.solBalance,
                  solBalanceUsd: d.solBalanceUsd,
                  tokenAccounts: d.tokenAccounts,
                  recentSignatures: d.recentSignatures,
                }));
              }
            })
            .catch(() => {});
        }}
        onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
      />

      <div className="flex flex-1">
        {/* Left Sidebar Navigation matching screenshot */}
        {sidebarOpen && (
          <IdxSidebar
            activeTab={activeTab}
            onNavigate={(tab) => setActiveTab(tab)}
          />
        )}

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          <FeatureStatusBanner viewKey={activeTab} />
          {activeTab !== 'launchpad' && (
            <RealOnChainBalancesPanel
              onRefreshAll={fetchAllData}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'launchpad' && <LaunchpadView />}

          {activeTab === 'meme_launch' && (
            <BashamMemeLaunchView
              wallet={wallet}
              onNavigateToStaking={() => setActiveTab('staking_pools')}
              onNavigateToCreatePool={() => setActiveTab('create_pool')}
              onNavigateToAITaskForce={() => setActiveTab('operator_ai_taskforce')}
            />
          )}

          {activeTab === 'staking_pools' && (
            <BashamStakingPoolsView
              wallet={wallet}
              tokens={tokens}
              onNavigateToMemeLaunch={() => setActiveTab('meme_launch')}
              onRefreshWallet={fetchWalletData}
            />
          )}

          {activeTab === 'blank_balance' && (
            <BlankNetworkBalanceView
              onNavigateToPool={() => setActiveTab('create_pool')}
              onNavigateToTrade={() => setActiveTab('exchange')}
              walletSolBalance={wallet.solBalance}
              tokens={tokens}
              onRefreshAll={fetchAllData}
            />
          )}

          {activeTab === 'hot_wallets' && (
            <HotWalletsNetworkView
              onRefreshAll={fetchAllData}
              walletSolBalance={wallet.solBalance}
              userAddress={wallet.address}
              cluster={cluster}
              onNavigateTab={(tab) => setActiveTab(tab as any)}
            />
          )}

          {activeTab === 'pump_engine' && (
            <PumpBondingCurvePoolPage
              onNavigateTab={(tab: any) => setActiveTab(tab)}
              walletSolBalance={wallet.solBalance}
            />
          )}

          {activeTab === 'create_pool' && (
            <CreateLiquidityPoolView
              tokens={tokens}
              walletSolBalance={wallet.solBalance}
              onPoolCreated={fetchAllData}
              onNavigateToManage={() => setActiveTab('manage_liquidity')}
              onNavigateToTrade={(tab) => setActiveTab((tab as any) || 'pump_engine')}
            />
          )}

          {activeTab === 'dashboard' && (
            <BotDashboardView
              pools={pools}
              tokens={tokens}
              volumeConfig={volumeConfig}
              flywheelState={flywheelState}
              holdersConfig={holdersConfig}
              onNavigate={(tab) => setActiveTab(tab)}
              onTriggerBurst={handleTriggerBurst}
              onTriggerPump={handleTriggerPump}
            />
          )}

          {activeTab === 'volume_bot' && (
            <VolumeBotView
              config={volumeConfig}
              pools={pools}
              onUpdateConfig={handleUpdateVolumeConfig}
              onTriggerBurst={handleTriggerBurst}
            />
          )}

          {activeTab === 'manage_liquidity' && (
            <ManageLiquidityView
              pools={pools}
              walletAddress={wallet.address}
              onRefresh={fetchAllData}
              onNavigateToCreate={() => setActiveTab('create_pool')}
            />
          )}

          {activeTab === 'holders_maker' && (
            <HoldersMakerView
              config={holdersConfig}
              tokens={tokens}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'create_token' && (
            <CreateTokenProView
              onTokenCreated={fetchAllData}
              onNavigateToPool={() => setActiveTab('create_pool')}
              tokens={tokens}
              recipientAddress={wallet.address}
            />
          )}

          {activeTab === 'token_hub' && (
            <TokenHubView
              tokens={tokens}
              onNavigate={(tab) => setActiveTab(tab)}
              onRefresh={fetchAllData}
              recipientAddress={wallet.address}
            />
          )}

          {activeTab === 'token_burn' && (
            <TokenBurnView
              tokens={tokens}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'bulk_sender' && (
            <BulkSenderView
              tokens={tokens}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'update_metadata' && (
            <UpdateMetadataView
              tokens={tokens}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'revoke_authorities' && (
            <RevokeAuthoritiesView
              tokens={tokens}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'liquidity_simulator' && (
            <LiquiditySimulatorView />
          )}

          {activeTab === 'fast_swap' && (
            <FastSwapView
              tokens={tokens}
              walletSolBalance={wallet.solBalance}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'reaction_booster' && (
            <ReactionBoosterView
              reactions={reactions}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'launchlab' && (
            <LaunchlabView
              onNavigateToCreatePool={() => setActiveTab('create_pool')}
            />
          )}

          {activeTab === 'exchange' && (
            <IdxExchangeView
              pools={pools}
              tokens={tokens}
              walletSolBalance={wallet.solBalance}
            />
          )}

          {activeTab === 'pump_flywheel' && (
            <PumpFlywheelView
              tokenState={tokenState}
              flywheelState={flywheelState}
              config={config}
              ledger={ledger}
              wallets={syndicateWallets}
              rebalanceCycle={rebalanceCycle}
              onRefresh={fetchAllData}
              onTriggerInjection={handleTriggerPump}
            />
          )}

          {activeTab.startsWith('operator') && (
            <OmegaOperatorView
              key={activeTab}
              initialTab={
                activeTab === 'operator_ai_taskforce'
                  ? 'ai_taskforce'
                  : activeTab.replace('operator_', '') || 'command'
              }
              onNavigateToTools={(tab) => setActiveTab(tab as any)}
              walletSolBalance={wallet.solBalance}
            />
          )}
        </main>
      </div>

      {/* Floating Action Button for Quick Swap / Pool matching screenshot */}
      <button
        onClick={() => setActiveTab('create_pool')}
        className="fixed bottom-6 right-6 p-3.5 rounded-full bg-[#051a14] hover:bg-[#092b21] text-emerald-400 shadow-2xl shadow-emerald-950/80 hover:scale-105 transition-all z-50 flex items-center justify-center border-2 border-emerald-500/60"
        title="Create Liquidity Pool"
      >
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current stroke-2">
          <rect x="3" y="11" width="18" height="10" rx="2" />
          <circle cx="12" cy="5" r="2" />
          <path d="M12 7v4" />
          <line x1="8" y1="16" x2="8" y2="16" strokeLinecap="round" />
          <line x1="16" y1="16" x2="16" y2="16" strokeLinecap="round" />
        </svg>
      </button>
    </div>
  );
}

export default App;
