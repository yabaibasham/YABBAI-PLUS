import './polyfills'; // must stay first: defines Buffer for Solana packages
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Secondary runtime guard for multi-wallet extension property collisions
try {
  const existingEth = Object.getOwnPropertyDescriptor(window, 'ethereum');
  if (!existingEth) {
    let ethValue: any = (window as any).ethereum;
    Object.defineProperty(window, 'ethereum', {
      configurable: true,
      enumerable: true,
      get() {
        return ethValue;
      },
      set(val) {
        ethValue = val;
      },
    });
  }
} catch {
  // Ignore if already locked by browser extension
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
