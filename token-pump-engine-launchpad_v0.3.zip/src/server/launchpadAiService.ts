import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { PublicKey } from '@solana/web3.js';
import { getConnection } from './solanaWeb3Service';
import { LAUNCHPAD_CLUSTER, LAUNCHPAD_PROGRAM_ID, launchpadService } from './launchpadService';
import * as L from '../lib/launchpad/client';

/**
 * AI + growth layer for the launchpad. Everything it says is computed from on-chain state that
 * launchpadService.state() reads. Gemini only writes words around those numbers; it never invents
 * figures, and when no model answers the response says `ai: false` and returns the rule-based result.
 *
 *   discovery()       Trending / New / Near graduation / Graduated rankings
 *   tokenReport(mint) Holder concentration + creator holdings from getTokenLargestAccounts, risk flags
 *   draftLaunch(idea) Gemini drafts name, symbol and description for the Launch form (creator edits before signing)
 *   growth()          Metrics history (snapshots every 10 min) + growth actions from real trends
 *
 * Env: GEMINI_API_KEY (optional), LAUNCHPAD_AI_MODEL (optional, defaults to GEMINI_MODEL / gemini-2.5-flash)
 *      LAUNCHPAD_METRICS_FILE (optional; default src/server/data/launchpad_metrics.json)
 */

const LAMPORTS = 1_000_000_000;
const SNAPSHOT_EVERY_MS = 10 * 60_000;
const KEEP_TOTALS_MS = 90 * 24 * 3600_000;
const KEEP_MINTS_MS = 26 * 3600_000;
const METRICS_FILE =
  process.env.LAUNCHPAD_METRICS_FILE || path.join(process.cwd(), 'src', 'server', 'data', 'launchpad_metrics.json');

// ---------------------------------------------------------------- Gemini

let genai: GoogleGenAI | null = null;
function client(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) return null;
  if (!genai) genai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  return genai;
}
const models = () =>
  [process.env.LAUNCHPAD_AI_MODEL, process.env.GEMINI_MODEL, process.env.GEMINI_FALLBACK_MODEL, 'gemini-2.5-flash'].filter(
    (m, i, a): m is string => Boolean(m) && a.indexOf(m) === i
  );

const SYSTEM = [
  'You assist the operator and users of a Solana token launchpad.',
  'Only use numbers that appear in the provided data. Never invent prices, volumes, holders or returns.',
  'Never promise or predict profit or price movement. Never suggest fake volume, wash trading, bundled or',
  'coordinated buying, fake holders, bots that trade with themselves, or anything that misleads buyers.',
  'Be concise and practical.',
].join(' ');

async function ask(prompt: string, json = false): Promise<{ text: string; model: string } | null> {
  const c = client();
  if (!c) return null;
  for (const model of models()) {
    try {
      const r = await c.models.generateContent({
        model,
        contents: prompt,
        config: { systemInstruction: SYSTEM, ...(json ? { responseMimeType: 'application/json' } : {}) },
      });
      if (r.text) return { text: r.text, model };
    } catch (e: any) {
      console.warn(`[launchpadAi] ${model} failed: ${e?.message || e}`);
    }
  }
  return null;
}

// ---------------------------------------------------------------- metrics history

interface TotalsSnap {
  at: number;
  launches: number;
  volume: number; // lamports (number is fine below 2^53 ≈ 9M SOL)
  trades: number;
  platformFees: number;
  creatorFees: number;
  feeWallet: number | null;
}
interface MintSnap {
  at: number;
  v: Record<string, [number, number]>; // mint -> [volumeLamports, trades]
}
interface History {
  programId: string;
  cluster: string;
  totals: TotalsSnap[];
  mints: MintSnap[];
}

let history: History | null = null;
function loadHistory(): History {
  if (history) return history;
  try {
    const h = JSON.parse(readFileSync(METRICS_FILE, 'utf8')) as History;
    if (h.programId === LAUNCHPAD_PROGRAM_ID && h.cluster === LAUNCHPAD_CLUSTER) history = h;
  } catch {
    // first run
  }
  history ??= { programId: LAUNCHPAD_PROGRAM_ID, cluster: LAUNCHPAD_CLUSTER, totals: [], mints: [] };
  return history;
}
function saveHistory() {
  try {
    const dir = path.dirname(METRICS_FILE);
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    writeFileSync(METRICS_FILE, JSON.stringify(history));
  } catch (e: any) {
    console.warn('[launchpadAi] could not save metrics history:', e?.message);
  }
}

const num = (v: unknown) => Number(v ?? 0);

/** Called with every fresh state read; stores at most one snapshot per 10 minutes. */
export function recordSnapshot(state: any) {
  if (state?.status !== 'LIVE' || !state.totals) return;
  const h = loadHistory();
  const now = Date.now();
  const last = h.totals[h.totals.length - 1];
  if (last && now - last.at < SNAPSHOT_EVERY_MS) return;
  const t = state.totals;
  h.totals.push({
    at: now,
    launches: num(t.launches),
    volume: num(t.volumeLamports),
    trades: num(t.trades),
    platformFees: num(t.platformFeesLamports),
    creatorFees: num(t.creatorFeesLamports),
    feeWallet: t.feeRecipientBalanceLamports == null ? null : num(t.feeRecipientBalanceLamports),
  });
  const v: MintSnap['v'] = {};
  for (const l of state.launches || []) if (l.curve) v[l.mint] = [num(l.curve.volumeLamports), num(l.curve.tradeCount)];
  h.mints.push({ at: now, v });
  h.totals = h.totals.filter((s) => now - s.at <= KEEP_TOTALS_MS);
  h.mints = h.mints.filter((s) => now - s.at <= KEEP_MINTS_MS);
  saveHistory();
}

/** Oldest snapshot at least `ms` old (or the oldest we have), for "change over the last X". */
function baseline<T extends { at: number }>(list: T[], ms: number): T | null {
  const cutoff = Date.now() - ms;
  let pick: T | null = null;
  for (const s of list) {
    if (s.at <= cutoff) pick = s;
    else break;
  }
  return pick ?? list[0] ?? null;
}

// ---------------------------------------------------------------- discovery

async function liveState() {
  const s = await launchpadService.state();
  recordSnapshot(s);
  return s;
}

function curveOf(l: any): L.CurveAccount | null {
  if (!l?.curve) return null;
  const c = l.curve;
  const B = (x: unknown) => BigInt((x as any) ?? 0);
  return {
    ...c,
    launchIndex: B(c.launchIndex), createdAt: B(c.createdAt), virtualSolReserves: B(c.virtualSolReserves),
    virtualTokenReserves: B(c.virtualTokenReserves), realSolReserves: B(c.realSolReserves), realTokenReserves: B(c.realTokenReserves),
    initialRealTokenReserves: B(c.initialRealTokenReserves), tokenTotalSupply: B(c.tokenTotalSupply), volumeLamports: B(c.volumeLamports),
    feesLamports: B(c.feesLamports), creatorFeesLamports: B(c.creatorFeesLamports), creatorFeesClaimed: B(c.creatorFeesClaimed),
    tradeCount: B(c.tradeCount), migrationSol: B(c.migrationSol), migrationTokens: B(c.migrationTokens),
  };
}

export const launchpadAiService = {
  recordSnapshot,

  async discovery() {
    const s = await liveState();
    if (s.status !== 'LIVE') return { ok: true, status: s.status, lists: null };
    const h = loadHistory();
    // Use a windowed baseline only once it covers at least an hour; before that, rank on activity since launch.
    const candidate = baseline(h.mints, 24 * 3600_000);
    const base24 = candidate && Date.now() - candidate.at >= 3600_000 ? candidate : null;
    const windowHours = base24 ? (Date.now() - base24.at) / 3600_000 : 0;
    const nowSec = Date.now() / 1000;

    const rows = (s.launches as any[]).map((l) => {
      const c = curveOf(l);
      const volume = c ? Number(c.volumeLamports) : 0;
      const trades = c ? Number(c.tradeCount) : 0;
      const prev = base24?.v[l.mint];
      const ageHours = c ? Math.max(1 / 60, (nowSec - Number(c.createdAt)) / 3600) : 0;
      // Real windowed volume when history covers it; otherwise lifetime volume (labelled as such).
      const recentVolume = prev ? volume - prev[0] : volume;
      const recentTrades = prev ? trades - prev[1] : trades;
      const progress = c ? L.progressPct(c) : 0;
      return {
        mint: l.mint,
        name: l.name,
        symbol: l.symbol,
        image: l.image,
        creator: l.creator,
        ageHours: Number(ageHours.toFixed(2)),
        progressPct: Number(progress.toFixed(2)),
        volumeSol: volume / LAMPORTS,
        trades,
        recentVolumeSol: recentVolume / LAMPORTS,
        recentTrades,
        recentWindow: prev ? `${windowHours.toFixed(1)}h` : 'since launch',
        live: Boolean(c && !c.complete),
        graduated: Boolean(c?.migrated),
        soldOut: Boolean(c?.complete),
        // Trending: recent SOL volume, weighted by distinct trading activity and gently by recency.
        score: (recentVolume / LAMPORTS) * Math.log2(2 + recentTrades) / Math.pow(1 + ageHours / 48, 0.5),
      };
    });

    const by = (f: (r: (typeof rows)[number]) => number) => [...rows].sort((a, b) => f(b) - f(a));
    return {
      ok: true,
      status: 'LIVE',
      cluster: LAUNCHPAD_CLUSTER,
      historyHours: Number(windowHours.toFixed(1)),
      method:
        'Trending = SOL volume in the window × log2(2 + trades) ÷ √(1 + age/48h). Window is the last 24h once the server has 24h of snapshots, otherwise since launch.',
      lists: {
        trending: by((r) => r.score).filter((r) => r.live && r.recentTrades > 0).slice(0, 20),
        nearGraduation: by((r) => r.progressPct).filter((r) => r.live && r.progressPct >= 50).slice(0, 20),
        newest: by((r) => -r.ageHours).slice(0, 20),
        graduated: by((r) => r.volumeSol).filter((r) => r.graduated || r.soldOut).slice(0, 20),
      },
    };
  },

  async tokenReport(mint: string, withAi = true) {
    const s = await liveState();
    const launch = (s.launches || []).find((l: any) => l.mint === mint);
    if (!launch) return { ok: false, error: 'That mint was not launched on this launchpad.' };
    const c = curveOf(launch);
    if (!c) return { ok: false, error: 'Curve account could not be read.' };

    const P = L.launchpadPdas(LAUNCHPAD_PROGRAM_ID);
    const supply = Number(c.tokenTotalSupply);
    const vault = P.vault(mint).toBase58();
    const creatorAta = P.ata(launch.creator, mint).toBase58();
    const migrationAta = s.global?.migrationAuthority ? P.ata(s.global.migrationAuthority, mint).toBase58() : '';

    let largest: { address: string; amount: number }[] = [];
    let holdersError: string | null = null;
    try {
      const r = await getConnection(LAUNCHPAD_CLUSTER).getTokenLargestAccounts(new PublicKey(mint), 'confirmed');
      largest = r.value.map((a) => ({ address: a.address.toBase58(), amount: Number(a.amount) }));
    } catch (e: any) {
      holdersError = `Holder data unavailable from this RPC (${e?.message || 'error'}). Set SOLANA_${LAUNCHPAD_CLUSTER === 'devnet' ? 'DEVNET' : 'MAINNET'}_RPC to a Helius/QuickNode URL.`;
    }
    const outside = largest.filter((a) => a.address !== vault && a.address !== migrationAta && a.amount > 0);
    // Before graduation: % of tokens bought off the curve. After: % of total supply (the DEX pool's vault
    // then shows up as a large holder, which is expected).
    const circulating = c.migrated ? supply : Number(c.initialRealTokenReserves - c.realTokenReserves);
    const pctOf = (n: number, d: number) => (d > 0 ? (n / d) * 100 : 0);
    const top1 = outside[0]?.amount ?? 0;
    const top10 = outside.slice(0, 10).reduce((n, a) => n + a.amount, 0);
    const creatorHolds = largest.find((a) => a.address === creatorAta)?.amount ?? 0;

    const flags: { level: 'info' | 'warn' | 'high'; text: string }[] = [
      { level: 'info', text: 'Mint authority revoked and freeze authority never set (enforced by the launchpad program).' },
      { level: 'info', text: 'Metadata is immutable (enforced by the launchpad program).' },
    ];
    if (!holdersError && circulating > 0) {
      const t1 = pctOf(top1, circulating);
      const t10 = pctOf(top10, circulating);
      const cr = pctOf(creatorHolds, circulating);
      if (t1 >= 30) flags.push({ level: 'high', text: `One wallet holds ${t1.toFixed(1)}% of tokens bought so far.` });
      else if (t1 >= 15) flags.push({ level: 'warn', text: `Largest wallet holds ${t1.toFixed(1)}% of tokens bought so far.` });
      if (t10 >= 70) flags.push({ level: 'warn', text: `Top 10 wallets hold ${t10.toFixed(1)}% of tokens bought so far.` });
      if (cr >= 20) flags.push({ level: 'high', text: `The creator holds ${cr.toFixed(1)}% of tokens bought so far.` });
      else if (cr >= 5) flags.push({ level: 'warn', text: `The creator holds ${cr.toFixed(1)}% of tokens bought so far.` });
    }
    if (Number(c.tradeCount) < 5 && !c.complete) flags.push({ level: 'warn', text: 'Very few trades so far; price can move sharply.' });
    if (c.complete && !c.migrated) flags.push({ level: 'info', text: 'Sold out; waiting for the platform to seed the DEX pool.' });
    if (c.migrated) flags.push({ level: 'info', text: 'Graduated: percentages are of total supply, and the largest holder is usually the DEX pool vault.' });
    if (c.migrated && c.migrationPool) flags.push({ level: 'info', text: `Graduated to DEX pool ${c.migrationPool}.` });

    const facts = {
      name: launch.name,
      symbol: launch.symbol,
      progressPct: Number(L.progressPct(c).toFixed(2)),
      volumeSol: Number(c.volumeLamports) / LAMPORTS,
      trades: Number(c.tradeCount),
      raisedSol: Number(c.migrated ? c.migrationSol : c.realSolReserves) / LAMPORTS,
      creatorFeesEarnedSol: Number(c.creatorFeesLamports) / LAMPORTS,
      top1PctOfBought: Number(pctOf(top1, circulating).toFixed(2)),
      top10PctOfBought: Number(pctOf(top10, circulating).toFixed(2)),
      creatorPctOfBought: Number(pctOf(creatorHolds, circulating).toFixed(2)),
      description: launch.description,
      flags: flags.map((f) => `${f.level}: ${f.text}`),
    };
    let summary: string | null = null;
    let model: string | null = null;
    if (withAi) {
      const r = await ask(
        `Write a neutral 2-3 sentence risk summary for a buyer considering this token. Use only these facts. ` +
          `End with: "Not financial advice."\n${JSON.stringify(facts)}`
      );
      summary = r?.text.trim() ?? null;
      model = r?.model ?? null;
    }
    return {
      ok: true,
      mint,
      facts,
      flags,
      holdersError,
      topHolders: outside.slice(0, 10).map((a) => ({
        tokenAccount: a.address,
        pctOfBought: Number(pctOf(a.amount, circulating).toFixed(2)),
        isCreator: a.address === creatorAta,
      })),
      ai: Boolean(summary),
      model,
      summary,
    };
  },

  async draftLaunch(body: { idea?: string; tone?: string }) {
    const idea = String(body.idea || '').trim().slice(0, 500);
    if (idea.length < 3) return { ok: false, error: 'Describe the token idea in a few words.' };
    const r = await ask(
      `Draft launch metadata for a community token based on this idea: "${idea}". Tone: ${String(body.tone || 'fun, honest').slice(0, 40)}.\n` +
        `Return JSON {"name": string (max ${L.MAX_NAME_LEN} chars), "symbol": string (2-${L.MAX_SYMBOL_LEN} uppercase letters/digits), ` +
        `"description": string (max 400 chars; no promises of returns, no "guaranteed", no price targets), "tagline": string (max 80 chars)}.`,
      true
    );
    if (!r) return { ok: false, error: 'AI is not configured (set GEMINI_API_KEY) or no model answered. Fill the form by hand.' };
    try {
      const j = JSON.parse(r.text.replace(/^```json|```$/g, '').trim());
      const name = String(j.name || '').trim().slice(0, L.MAX_NAME_LEN);
      const symbol = String(j.symbol || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, L.MAX_SYMBOL_LEN);
      const description = String(j.description || '').trim().slice(0, 1000);
      if (!name || !symbol) throw new Error('missing fields');
      return { ok: true, model: r.model, name, symbol, description, tagline: String(j.tagline || '').slice(0, 80) };
    } catch {
      return { ok: false, error: 'The AI answer could not be read. Try again or fill the form by hand.' };
    }
  },

  async growth() {
    const s = await liveState();
    const h = loadHistory();
    const last = h.totals[h.totals.length - 1] ?? null;
    const d1 = baseline(h.totals, 24 * 3600_000);
    const d7 = baseline(h.totals, 7 * 24 * 3600_000);
    const delta = (from: TotalsSnap | null) =>
      last && from && from !== last
        ? {
            hours: Number(((last.at - from.at) / 3600_000).toFixed(1)),
            launches: last.launches - from.launches,
            volumeSol: (last.volume - from.volume) / LAMPORTS,
            trades: last.trades - from.trades,
            platformFeesSol: (last.platformFees - from.platformFees) / LAMPORTS,
            creatorFeesSol: (last.creatorFees - from.creatorFees) / LAMPORTS,
          }
        : null;
    const day = delta(d1);
    const week = delta(d7);

    // Rule-based actions from real state. These always run; AI only adds wording on top.
    const actions: { priority: 'now' | 'soon' | 'idea'; text: string }[] = [];
    const t = s.totals;
    if (s.status === 'NOT_DEPLOYED') actions.push({ priority: 'now', text: 'Deploy the program (DEPLOY.md, devnet first).' });
    if (s.status === 'NOT_INITIALIZED') actions.push({ priority: 'now', text: 'Initialize the launchpad from the Platform tab with the deployer wallet.' });
    if (s.status === 'LIVE' && t) {
      if (num(t.awaitingMigration) > 0)
        actions.push({ priority: 'now', text: `${t.awaitingMigration} sold-out curve(s) are waiting for migration. Holders can't trade until the DEX pool exists.` });
      if (t.feeRecipientBalanceLamports != null && num(t.feeRecipientBalanceLamports) < 1_000_000)
        actions.push({ priority: 'now', text: 'Fee wallet holds under 0.001 SOL. Small fee transfers can fail until it is rent-exempt; send it 0.002 SOL.' });
      if (s.global?.paused) actions.push({ priority: 'now', text: 'Launches and buys are paused.' });
      if (num(t.launches) === 0) actions.push({ priority: 'soon', text: 'No launches yet. Launch a first token yourself with honest metadata, then share the link.' });
      if (num(t.launches) > 0 && num(t.trades) / Math.max(1, num(t.launches)) < 3)
        actions.push({ priority: 'soon', text: 'Most launches have under 3 trades. Discovery is the bottleneck: share the Discover tab and each token page.' });
      if (num(t.creatorFeesUnclaimedLamports) > 0)
        actions.push({ priority: 'idea', text: `Creators have ${(num(t.creatorFeesUnclaimedLamports) / LAMPORTS).toFixed(4)} SOL unclaimed. Tell them; paid creators promote their tokens.` });
      if (day && day.volumeSol <= 0 && num(t.launches) > 0)
        actions.push({ priority: 'soon', text: 'No new volume in the last day. Check RPC health and whether the app is reachable.' });
      if (s.cluster === 'devnet') actions.push({ priority: 'idea', text: 'Still on devnet. Mainnet only after an independent audit (see AUDIT_PREP.md).' });
    }

    let narrative: string | null = null;
    let model: string | null = null;
    if (s.status === 'LIVE') {
      const r = await ask(
        `You are reviewing a token launchpad's real on-chain metrics. In at most 5 bullet points, say what is working, ` +
          `what is not, and the most useful next steps to grow honest usage (more real creators and real traders). ` +
          `Use only these numbers.\n${JSON.stringify({ totals: t, last24h: day, last7d: week, ruleActions: actions })}`
      );
      narrative = r?.text.trim() ?? null;
      model = r?.model ?? null;
    }

    return {
      ok: true,
      status: s.status,
      cluster: s.cluster,
      snapshots: h.totals.length,
      firstSnapshotAt: h.totals[0]?.at ?? null,
      last24h: day,
      last7d: week,
      series: h.totals.slice(-288).map((x) => ({
        at: x.at,
        volumeSol: x.volume / LAMPORTS,
        platformFeesSol: x.platformFees / LAMPORTS,
        creatorFeesSol: x.creatorFees / LAMPORTS,
        launches: x.launches,
        trades: x.trades,
      })),
      actions,
      ai: Boolean(narrative),
      model,
      narrative,
    };
  },
};
