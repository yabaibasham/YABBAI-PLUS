import { Buffer } from 'buffer';
import { Connection, PublicKey, Transaction, VersionedTransaction, SendTransactionError } from '@solana/web3.js';
import { getConnection } from './solanaWeb3Service';
import * as L from '../lib/launchpad/client';

/**
 * Server side of the launchpad: reads the program's on-chain state, relays wallet-signed
 * transactions, and (optionally) pins token metadata to IPFS. It never holds keys or signs.
 *
 * Env:
 *   LAUNCHPAD_CLUSTER     devnet (default) | mainnet-beta
 *   LAUNCHPAD_PROGRAM_ID  defaults to the program ID in programs/meme-pump-engine
 *   SOLANA_DEVNET_RPC / SOLANA_MAINNET_RPC   optional RPC URLs (e.g. Helius)
 *   PINATA_JWT            optional, enables image + metadata upload to IPFS
 *   IPFS_GATEWAY          optional, default https://ipfs.io/ipfs/
 */

type Cluster = 'devnet' | 'mainnet-beta';
export const LAUNCHPAD_CLUSTER: Cluster = process.env.LAUNCHPAD_CLUSTER === 'mainnet-beta' ? 'mainnet-beta' : 'devnet';
export const LAUNCHPAD_PROGRAM_ID = process.env.LAUNCHPAD_PROGRAM_ID || L.DEFAULT_PROGRAM_ID;
const IPFS_GATEWAY = (process.env.IPFS_GATEWAY || 'https://ipfs.io/ipfs/').replace(/\/?$/, '/');
const MAX_LAUNCHES_LISTED = 200;
const STATE_TTL_MS = 8_000;

const conn = (): Connection => getConnection(LAUNCHPAD_CLUSTER);
const P = L.launchpadPdas(LAUNCHPAD_PROGRAM_ID);

/** bigint -> string, recursively, so state can go over JSON. */
function ser<T>(v: T): any {
  if (typeof v === 'bigint') return v.toString();
  if (Array.isArray(v)) return v.map(ser);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, ser(x)]));
  return v;
}

async function getMany(keys: PublicKey[]) {
  const out: (Awaited<ReturnType<Connection['getMultipleAccountsInfo']>>[number])[] = [];
  for (let i = 0; i < keys.length; i += 100) {
    out.push(...(await conn().getMultipleAccountsInfo(keys.slice(i, i + 100), 'confirmed')));
  }
  return out;
}

/** Upgrade authority from the program's ProgramData account (who may initialize). */
function upgradeAuthorityOf(data: Uint8Array | undefined): string | null {
  if (!data || data.length < 45) return null;
  const tag = new DataView(data.buffer, data.byteOffset, data.byteLength).getUint32(0, true);
  if (tag !== 3 || data[12] !== 1) return null;
  return new PublicKey(data.slice(13, 45)).toBase58();
}

const imageCache = new Map<string, { at: number; image: string | null; description: string | null }>();
function toHttp(uri: string) {
  return uri.startsWith('ipfs://') ? IPFS_GATEWAY + uri.slice(7).replace(/^ipfs\//, '') : uri;
}
async function metadataJson(uri: string): Promise<{ image: string | null; description: string | null }> {
  if (!/^(https:\/\/|ipfs:\/\/)/.test(uri)) return { image: null, description: null };
  const hit = imageCache.get(uri);
  if (hit && Date.now() - hit.at < 30 * 60_000) return hit;
  let result = { image: null as string | null, description: null as string | null };
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4_000);
    const res = await fetch(toHttp(uri), { signal: ctrl.signal });
    clearTimeout(timer);
    if (res.ok) {
      const j: any = await res.json();
      result = {
        image: typeof j?.image === 'string' ? toHttp(j.image) : null,
        description: typeof j?.description === 'string' ? j.description.slice(0, 500) : null,
      };
    }
  } catch {
    // leave image empty; the UI shows initials
  }
  imageCache.set(uri, { at: Date.now(), ...result });
  return result;
}

let stateCache: { at: number; data: any } | null = null;

export const launchpadService = {
  config() {
    return {
      ok: true,
      cluster: LAUNCHPAD_CLUSTER,
      programId: LAUNCHPAD_PROGRAM_ID,
      pinataEnabled: Boolean(process.env.PINATA_JWT),
      explorerSuffix: LAUNCHPAD_CLUSTER === 'devnet' ? '?cluster=devnet' : '',
      defaults: ser(L.DEFAULT_CURVE),
    };
  },

  async state(force = false) {
    if (!force && stateCache && Date.now() - stateCache.at < STATE_TTL_MS) return stateCache.data;
    const fetchedAt = Date.now();
    const base = { ok: true, cluster: LAUNCHPAD_CLUSTER, programId: LAUNCHPAD_PROGRAM_ID, fetchedAt };

    const [programAcc, programDataAcc, globalAcc] = await getMany([P.programId, P.programData, P.global]);
    const upgradeAuthority = upgradeAuthorityOf(programDataAcc?.data);
    if (!programAcc || !programAcc.executable) {
      const data = { ...base, status: 'NOT_DEPLOYED', upgradeAuthority: null, global: null, launches: [], totals: null };
      stateCache = { at: fetchedAt, data };
      return data;
    }
    if (!globalAcc) {
      const data = { ...base, status: 'NOT_INITIALIZED', upgradeAuthority, global: null, launches: [], totals: null };
      stateCache = { at: fetchedAt, data };
      return data;
    }

    const global = L.decodeGlobal(globalAcc.data);
    const count = Number(global.launchCount);
    const first = Math.max(0, count - MAX_LAUNCHES_LISTED);
    const indexes = Array.from({ length: count - first }, (_, i) => first + i);
    const records = (await getMany(indexes.map((i) => P.launchRecord(i))))
      .map((a) => (a ? L.decodeLaunchRecord(a.data) : null))
      .filter((r): r is L.LaunchRecordAccount => Boolean(r));
    const curveAccs = await getMany(records.map((r) => P.curve(r.mint)));
    const metaAccs = await getMany(records.map((r) => P.metadata(r.mint)));

    const launches = await Promise.all(
      records.map(async (rec, i) => {
        const curve = curveAccs[i] ? L.decodeCurve(curveAccs[i]!.data) : null;
        const meta = metaAccs[i] ? L.decodeMetadataBasics(metaAccs[i]!.data) : { name: '', symbol: '', uri: '' };
        const extra = meta.uri ? await metadataJson(meta.uri) : { image: null, description: null };
        return { ...rec, ...meta, ...extra, curve };
      })
    );
    launches.sort((a, b) => Number(b.index - a.index));

    const curves = launches.map((l) => l.curve).filter(Boolean) as L.CurveAccount[];
    const sum = (f: (c: L.CurveAccount) => bigint) => curves.reduce((n, c) => n + f(c), 0n);
    const feeRecipientBalance = await conn().getBalance(new PublicKey(global.feeRecipient), 'confirmed').catch(() => null);

    const data = ser({
      ...base,
      status: 'LIVE',
      upgradeAuthority,
      global,
      launches,
      totals: {
        launches: global.launchCount,
        totalFeesLamports: sum((c) => c.feesLamports),
        platformFeesLamports: sum((c) => c.feesLamports - c.creatorFeesLamports),
        creatorFeesLamports: sum((c) => c.creatorFeesLamports),
        creatorFeesUnclaimedLamports: sum((c) => L.unclaimedCreatorFees(c)),
        volumeLamports: sum((c) => c.volumeLamports),
        trades: sum((c) => c.tradeCount),
        raisedLamports: sum((c) => c.realSolReserves),
        soldOut: curves.filter((c) => c.complete).length,
        awaitingMigration: curves.filter((c) => c.complete && !c.migrated).length,
        feeRecipientBalanceLamports: feeRecipientBalance,
      },
    });
    stateCache = { at: fetchedAt, data };
    return data;
  },

  async latestBlockhash() {
    const { blockhash, lastValidBlockHeight } = await conn().getLatestBlockhash('confirmed');
    return { ok: true, blockhash, lastValidBlockHeight, cluster: LAUNCHPAD_CLUSTER };
  },

  async tokenBalance(owner: string, mint: string) {
    const ata = P.ata(owner, mint);
    const info = await conn().getTokenAccountBalance(ata, 'confirmed').catch(() => null);
    return { ok: true, ata: ata.toBase58(), amount: info?.value.amount ?? '0' };
  },

  /** Relays a wallet-signed transaction. Only transactions that call the launchpad program are accepted. */
  async send(base64: string) {
    const raw = Buffer.from(String(base64 || ''), 'base64');
    if (raw.length === 0 || raw.length > 1232) return { ok: false, error: 'Transaction is empty or too large.' };

    let programIds: string[] = [];
    try {
      const tx = Transaction.from(raw);
      programIds = tx.instructions.map((ix) => ix.programId.toBase58());
    } catch {
      try {
        const vtx = VersionedTransaction.deserialize(raw);
        const keys = vtx.message.staticAccountKeys;
        programIds = vtx.message.compiledInstructions.map((ix) => keys[ix.programIdIndex].toBase58());
      } catch {
        return { ok: false, error: 'Could not read that transaction.' };
      }
    }
    if (!programIds.includes(LAUNCHPAD_PROGRAM_ID)) {
      return { ok: false, error: 'Only launchpad transactions can be sent through this server.' };
    }

    let signature: string;
    try {
      signature = await conn().sendRawTransaction(raw, { skipPreflight: false, preflightCommitment: 'confirmed', maxRetries: 3 });
    } catch (e: any) {
      const logs: string[] = (e instanceof SendTransactionError ? e.logs : e?.logs) || [];
      const text = [e?.message || String(e), ...logs].join('\n');
      return { ok: false, error: L.describeProgramError(text), logs: logs.slice(-12) };
    }

    // Poll for confirmation over HTTP (no websockets needed).
    const started = Date.now();
    while (Date.now() - started < 60_000) {
      const st = (await conn().getSignatureStatuses([signature])).value[0];
      if (st?.err) return { ok: false, signature, error: L.describeProgramError(JSON.stringify(st.err)) };
      if (st && (st.confirmationStatus === 'confirmed' || st.confirmationStatus === 'finalized')) {
        stateCache = null;
        return { ok: true, signature, confirmationStatus: st.confirmationStatus };
      }
      await new Promise((r) => setTimeout(r, 1_500));
    }
    return { ok: false, signature, error: 'Sent, but not confirmed within 60 seconds. Check the signature on Solscan before retrying.' };
  },

  /** Pins an image (data URL) and the token metadata JSON to IPFS via Pinata. */
  async uploadMetadata(body: {
    name?: string;
    symbol?: string;
    description?: string;
    imageDataUrl?: string;
    imageUrl?: string;
    website?: string;
    twitter?: string;
    telegram?: string;
  }) {
    const jwt = process.env.PINATA_JWT;
    if (!jwt) return { ok: false, error: 'IPFS upload is not set up. Add PINATA_JWT to the server secrets, or paste a metadata URL.' };
    const name = String(body.name || '').trim().slice(0, L.MAX_NAME_LEN);
    const symbol = String(body.symbol || '').trim().slice(0, L.MAX_SYMBOL_LEN);
    if (!name || !symbol) return { ok: false, error: 'Name and symbol are required.' };

    let image = String(body.imageUrl || '').trim();
    if (body.imageDataUrl) {
      const m = /^data:(image\/(png|jpeg|gif|webp));base64,(.+)$/.exec(body.imageDataUrl);
      if (!m) return { ok: false, error: 'Image must be a PNG, JPEG, GIF or WebP.' };
      const bytes = Buffer.from(m[3], 'base64');
      if (bytes.length > 2_000_000) return { ok: false, error: 'Image must be under 2 MB.' };
      const form = new FormData();
      form.append('file', new Blob([bytes], { type: m[1] }), `${symbol.toLowerCase()}.${m[2] === 'jpeg' ? 'jpg' : m[2]}`);
      form.append('pinataMetadata', JSON.stringify({ name: `${symbol} image` }));
      const res = await fetch('https://api.pinata.cloud/pinning/pinFileToIPFS', {
        method: 'POST',
        headers: { Authorization: `Bearer ${jwt}` },
        body: form,
      });
      if (!res.ok) return { ok: false, error: `Image upload failed (HTTP ${res.status}).` };
      image = IPFS_GATEWAY + (await res.json()).IpfsHash;
    }
    if (!image) return { ok: false, error: 'Add an image.' };

    const content: Record<string, unknown> = {
      name,
      symbol,
      description: String(body.description || '').slice(0, 1000),
      image,
      ...(body.website ? { external_url: String(body.website) } : {}),
      extensions: {
        ...(body.website ? { website: String(body.website) } : {}),
        ...(body.twitter ? { twitter: String(body.twitter) } : {}),
        ...(body.telegram ? { telegram: String(body.telegram) } : {}),
      },
    };
    const res = await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ pinataContent: content, pinataMetadata: { name: `${symbol} metadata` } }),
    });
    if (!res.ok) return { ok: false, error: `Metadata upload failed (HTTP ${res.status}).` };
    const uri = IPFS_GATEWAY + (await res.json()).IpfsHash;
    if (uri.length > L.MAX_URI_LEN) return { ok: false, error: 'Metadata URL is too long; set a shorter IPFS_GATEWAY.' };
    return { ok: true, uri, image };
  },
};

// end of src/server/launchpadService.ts
