import { useMemo, useState, useEffect } from 'react';
import {
  PublicKey,
  Transaction,
  TransactionInstruction,
  SystemProgram,
  SYSVAR_RENT_PUBKEY,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddressSync,
} from '@solana/spl-token';
import { computeBuyQuote, computeSellQuote } from '../lib/curve';

export const PROGRAM_ID = new PublicKey('J7yRzjdTL9HPaEikZ3vzcU7z6BFqcYKTBkYPqKEbvyrh');
export const CURVE_SEED = Buffer.from('curve');
export const SOL_VAULT_SEED = Buffer.from('sol_vault');
export const GLOBAL_SEED = Buffer.from('global');

// 8-byte Anchor method discriminators derived from sha256("global:<method_name>")[0..8]
export const ANCHOR_DISCRIMINATORS = {
  initializeGlobal: Uint8Array.from([143, 237, 244, 252, 196, 60, 203, 149]),
  initializeCurve: Uint8Array.from([104, 182, 137, 102, 133, 227, 194, 98]),
  buy: Uint8Array.from([102, 6, 61, 18, 1, 218, 235, 234]),
  sell: Uint8Array.from([51, 230, 133, 164, 1, 127, 131, 173]),
  migrateToRaydium: Uint8Array.from([215, 128, 201, 169, 14, 181, 116, 237]),
};

export interface CurveAccountState {
  creator: string;
  mint: string;
  tokenVault: string;
  solVault: string;
  virtualSolReserves: number;
  virtualTokenReserves: number;
  realSolReserves: number;
  realTokenReserves: number;
  complete: boolean;
  bump: number;
}

export function usePumpProgram(mintAddress?: string) {
  const [curveState, setCurveState] = useState<CurveAccountState | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const pdas = useMemo(() => {
    if (!mintAddress) return null;
    try {
      const mint = new PublicKey(mintAddress);
      const [curveStatePda, curveBump] = PublicKey.findProgramAddressSync(
        [CURVE_SEED, mint.toBuffer()],
        PROGRAM_ID
      );
      const [solVaultPda, solVaultBump] = PublicKey.findProgramAddressSync(
        [SOL_VAULT_SEED, mint.toBuffer()],
        PROGRAM_ID
      );
      const [globalPda, globalBump] = PublicKey.findProgramAddressSync(
        [GLOBAL_SEED],
        PROGRAM_ID
      );
      const tokenVault = getAssociatedTokenAddressSync(mint, curveStatePda, true);

      return {
        mint,
        curveStatePda,
        curveBump,
        solVaultPda,
        solVaultBump,
        globalPda,
        globalBump,
        tokenVault,
      };
    } catch {
      return null;
    }
  }, [mintAddress]);

  // Fetch on-chain curve details from backend proxy
  const fetchCurve = async () => {
    if (!mintAddress) return;
    try {
      setLoading(true);
      const res = await fetch(`/api/bonding-curve/${mintAddress}`);
      if (res.ok) {
        const data = await res.json();
        if (data.curve) {
          setCurveState({
            creator: data.curve.creator,
            mint: data.curve.mint,
            tokenVault: pdas?.tokenVault.toBase58() || '',
            solVault: pdas?.solVaultPda.toBase58() || '',
            virtualSolReserves: data.curve.virtual_sol_reserves,
            virtualTokenReserves: data.curve.virtual_token_reserves,
            realSolReserves: data.curve.real_sol_reserves,
            realTokenReserves: data.curve.real_token_reserves,
            complete: data.curve.complete,
            bump: 255,
          });
        }
      }
    } catch (e: any) {
      setError(e?.message || 'Failed to fetch bonding curve state');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCurve();
  }, [mintAddress]);

  // Build Buy Instruction matching Anchor layout
  const createBuyInstruction = (
    buyer: PublicKey,
    solAmountLamports: number,
    minTokensOut: number,
    feeRecipient: PublicKey
  ) => {
    if (!pdas) throw new Error('PDAs not derived');

    const buyerTokenAccount = getAssociatedTokenAddressSync(pdas.mint, buyer);

    // Encode Instruction Data: 8 bytes discriminator + 8 bytes sol_amount (u64 le) + 8 bytes min_tokens_out (u64 le)
    const data = new Uint8Array(8 + 8 + 8);
    data.set(ANCHOR_DISCRIMINATORS.buy, 0);
    const view = new DataView(data.buffer);
    view.setBigUint64(8, BigInt(solAmountLamports), true);
    view.setBigUint64(16, BigInt(minTokensOut), true);

    return new TransactionInstruction({
      programId: PROGRAM_ID,
      keys: [
        { pubkey: buyer, isSigner: true, isWritable: true },
        { pubkey: pdas.globalPda, isSigner: false, isWritable: false },
        { pubkey: pdas.curveStatePda, isSigner: false, isWritable: true },
        { pubkey: pdas.mint, isSigner: false, isWritable: false },
        { pubkey: pdas.tokenVault, isSigner: false, isWritable: true },
        { pubkey: pdas.solVaultPda, isSigner: false, isWritable: true },
        { pubkey: buyerTokenAccount, isSigner: false, isWritable: true },
        { pubkey: feeRecipient, isSigner: false, isWritable: true },
        { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
        { pubkey: ASSOCIATED_TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
        { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      ],
      data: Buffer.from(data),
    });
  };

  return {
    pdas,
    curveState,
    loading,
    error,
    refreshCurve: fetchCurve,
    createBuyInstruction,
    computeBuyQuote,
    computeSellQuote,
  };
}
