import { useState } from 'react';
import { PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';

export interface SwapExecutionResult {
  ok: boolean;
  signature?: string;
  tokenAmount?: number;
  solAmount?: number;
  isBuy: boolean;
  error?: string;
}

export const usePumpEngine = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const executeSwap = async (
    mintAddress: string,
    solAmount: number,
    isBuy: boolean,
    slippagePct: number = 1.0
  ): Promise<SwapExecutionResult> => {
    setLoading(true);
    setError(null);

    try {
      const anyWin = window as any;
      const provider = anyWin.phantom?.solana || anyWin.solana || anyWin.solflare;

      let buyerPublicKey: PublicKey | null = null;
      let signature = '';

      if (provider) {
        try {
          if (!provider.publicKey) {
            const resp = await provider.connect();
            buyerPublicKey = resp?.publicKey || provider.publicKey;
          } else {
            buyerPublicKey = provider.publicKey;
          }
        } catch (connErr: any) {
          console.warn('Wallet connection prompt ignored:', connErr);
        }
      }

      // If browser wallet extension is active, request on-chain transaction signature
      if (provider && buyerPublicKey) {
        const lamports = Math.floor(solAmount * LAMPORTS_PER_SOL);
        let vaultTarget: PublicKey;
        try {
          vaultTarget = new PublicKey(mintAddress);
        } catch {
          vaultTarget = buyerPublicKey;
        }

        const transaction = new Transaction().add(
          SystemProgram.transfer({
            fromPubkey: buyerPublicKey,
            toPubkey: vaultTarget,
            lamports: Math.max(1000, lamports),
          })
        );

        try {
          const bhRes = await fetch('/api/solana/recent-blockhash');
          if (bhRes.ok) {
            const bhData = await bhRes.json();
            transaction.recentBlockhash = bhData.blockhash;
            transaction.feePayer = buyerPublicKey;
          }
        } catch {
          // fallback
        }

        if (typeof provider.signAndSendTransaction === 'function') {
          const res = await provider.signAndSendTransaction(transaction);
          signature = res.signature || res;
        } else if (typeof provider.sendTransaction === 'function') {
          signature = await provider.sendTransaction(transaction);
        }
      }

      // Relay to server-side bonding curve engine
      const res = await fetch('/api/bonding-curve/trade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mint: mintAddress,
          solAmount,
          isBuy,
          slippagePct,
          buyerAddress: buyerPublicKey ? buyerPublicKey.toBase58() : 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i',
          signature: signature || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to execute bonding curve swap');
      }

      return {
        ok: true,
        signature: signature || data.signature,
        tokenAmount: data.tokenAmount,
        solAmount: data.solAmount,
        isBuy,
      };
    } catch (err: any) {
      console.error('usePumpEngine executeSwap error:', err);
      const msg = err?.message || 'Transaction failed or was cancelled';
      setError(msg);
      return {
        ok: false,
        error: msg,
        isBuy,
      };
    } finally {
      setLoading(false);
    }
  };

  return { executeSwap, loading, error };
};
