import React from 'react';

/**
 * Honest status for every screen, shown as a sidebar badge and a banner on the screen itself.
 *
 *  LIVE       Reads the chain and/or sends transactions your wallet signs. Numbers are real.
 *  SIMULATED  Demo data or made-up results. Keep for design/testing; never show these numbers as revenue.
 *  BLOCKED    Simulated, and deliberately never connected to mainnet: fake volume, fake holders and
 *             coordinated pumps mislead buyers (wash trading / market manipulation).
 *  UNVERIFIED Not audited in this pass. Treat any number as unconfirmed until you check it on Solscan.
 */
export type FeatureStatus = 'LIVE' | 'SIMULATED' | 'BLOCKED' | 'UNVERIFIED';

export const FEATURE_STATUS: Record<string, FeatureStatus> = {
  launchpad: 'LIVE',
  manage_liquidity: 'LIVE',
  pump_engine: 'SIMULATED',
  create_token: 'SIMULATED',
  create_pool: 'SIMULATED',
  dashboard: 'SIMULATED',
  exchange: 'SIMULATED',
  liquidity_simulator: 'SIMULATED',
  volume_bot: 'BLOCKED',
  holders_maker: 'BLOCKED',
  reaction_booster: 'BLOCKED',
  pump_flywheel: 'BLOCKED',
  operator_syndicate: 'BLOCKED',
};

export const statusOf = (key: string): FeatureStatus => FEATURE_STATUS[key] ?? 'UNVERIFIED';

export const STATUS_BADGE: Record<FeatureStatus, { text: string; cls: string }> = {
  LIVE: { text: 'LIVE', cls: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' },
  SIMULATED: { text: 'SIM', cls: 'bg-slate-500/20 text-slate-300 border-slate-500/40' },
  BLOCKED: { text: 'SIM ONLY', cls: 'bg-rose-500/20 text-rose-300 border-rose-500/40' },
  UNVERIFIED: { text: 'UNVERIFIED', cls: 'bg-amber-500/15 text-amber-300 border-amber-500/40' },
};

const BANNER: Record<Exclude<FeatureStatus, 'LIVE'>, { cls: string; text: string }> = {
  SIMULATED: {
    cls: 'border-slate-500/40 bg-slate-500/10 text-slate-200',
    text: 'Simulated screen: the numbers and results here are demo data, not on-chain activity or revenue. Use the Launchpad for real launches and trades.',
  },
  BLOCKED: {
    cls: 'border-rose-500/40 bg-rose-500/10 text-rose-200',
    text: 'Simulation only, and intentionally never connected to mainnet. Fake volume, fake holders and coordinated buying mislead buyers and are market manipulation. Real growth on this platform comes from real traders and the creator fee share.',
  },
  UNVERIFIED: {
    cls: 'border-amber-500/40 bg-amber-500/10 text-amber-200',
    text: 'Unverified screen: not audited as live. Confirm any balance, APY or revenue figure on Solscan before relying on it.',
  },
};

export const FeatureStatusBanner: React.FC<{ viewKey: string }> = ({ viewKey }) => {
  const s = statusOf(viewKey);
  if (s === 'LIVE') return null;
  const b = BANNER[s];
  return (
    <div className={`mb-4 p-3 rounded-xl border text-xs font-mono leading-relaxed ${b.cls}`}>
      <b>{s}</b> · {b.text}
    </div>
  );
};
