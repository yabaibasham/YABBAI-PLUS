import React, { useState } from 'react';
import { TokenMetadata } from '../../types';
import { ArrowLeftRight, CheckCircle2, RefreshCw, Zap, Sliders } from 'lucide-react';

interface FastSwapViewProps {
  tokens: TokenMetadata[];
  walletSolBalance: number;
  onRefresh: () => void;
}

export const FastSwapView: React.FC<FastSwapViewProps> = ({
  tokens,
  walletSolBalance,
  onRefresh,
}) => {
  const [fromToken, setFromToken] = useState<'SOL' | 'TOKEN'>('SOL');
  const [amountIn, setAmountIn] = useState<string>('0.0005');
  const [slippage, setSlippage] = useState<number>(1.0);
  const [loading, setLoading] = useState<boolean>(false);
  const [txSuccess, setTxSuccess] = useState<string | null>(null);

  const selectedToken = tokens[0] || { symbol: 'RARINU', priceSol: 0.000000001026 };
  const priceSol = 0.000000001026;

  const parsedIn = parseFloat(amountIn) || 0;
  const estimatedOut =
    fromToken === 'SOL'
      ? parsedIn > 0
        ? Math.round((parsedIn / priceSol) * 0.99)
        : 0
      : parsedIn > 0
      ? (parsedIn * priceSol * 0.99).toFixed(6)
      : '0';

  const handleSwap = async () => {
    try {
      setLoading(true);
      setTxSuccess(null);
      const res = await fetch('/api/swap/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromMint: fromToken === 'SOL' ? 'SOL' : selectedToken.mint,
          toMint: fromToken === 'SOL' ? selectedToken.mint : 'SOL',
          amountIn: parsedIn,
          slippage,
        }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setTxSuccess(`Atomic swap confirmed! Received ~${data.amountOut} ${fromToken === 'SOL' ? selectedToken.symbol : 'SOL'} · Tx: ${data.txSignature || '5kRaydiumSwap'}`);
        onRefresh();
      }
    } catch (e: any) {
      console.warn('Swap notice:', e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-6 pb-12 font-mono text-xs">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-[10px] text-cyan-400 font-bold uppercase">
            Raydium AMM Aggregator
          </span>
          <span className="text-[#8a93a8]">Instant Route</span>
        </div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">
          Fast Swap
        </h1>
        <p className="text-[#8a93a8] mt-1 text-sm font-sans">
          Execute instant atomic swaps against your Raydium liquidity pool with zero MEV frontrunning.
        </p>
      </div>

      <div className="rounded-2xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-2xl space-y-4">
        {/* You Pay */}
        <div className="p-3.5 rounded-xl bg-[#111624] border border-[#1f283d] space-y-1.5">
          <div className="flex items-center justify-between text-[#8a93a8]">
            <span>YOU PAY</span>
            <span>Balance: {fromToken === 'SOL' ? `${walletSolBalance} SOL` : `${selectedToken.userBalance.toLocaleString()} ${selectedToken.symbol}`}</span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <input
              type="text"
              value={amountIn}
              onChange={(e) => setAmountIn(e.target.value)}
              placeholder="0.0"
              className="w-full bg-transparent text-xl font-bold text-white focus:outline-none"
            />
            <span className="px-2.5 py-1 rounded bg-[#1c2438] text-white font-bold text-xs shrink-0">
              {fromToken === 'SOL' ? 'SOL' : selectedToken.symbol}
            </span>
          </div>
        </div>

        {/* Swap Switch Button */}
        <div className="flex justify-center -my-2 relative z-10">
          <button
            onClick={() => setFromToken(fromToken === 'SOL' ? 'TOKEN' : 'SOL')}
            className="p-2 rounded-xl bg-[#162035] hover:bg-[#202c48] border border-[#2b3856] text-cyan-400 shadow-md transition-colors"
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>
        </div>

        {/* You Receive */}
        <div className="p-3.5 rounded-xl bg-[#111624] border border-[#1f283d] space-y-1.5">
          <div className="flex items-center justify-between text-[#8a93a8]">
            <span>YOU RECEIVE (ESTIMATED)</span>
            <span>Fee: 0.25%</span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <div className="text-xl font-bold text-white">
              {estimatedOut.toLocaleString()}
            </div>
            <span className="px-2.5 py-1 rounded bg-[#1c2438] text-white font-bold text-xs shrink-0">
              {fromToken === 'SOL' ? selectedToken.symbol : 'SOL'}
            </span>
          </div>
        </div>

        {/* Slippage Selector */}
        <div className="flex items-center justify-between text-[11px] text-[#8a93a8]">
          <span>Slippage Tolerance</span>
          <div className="flex items-center gap-1">
            {[0.5, 1.0, 2.0].map((s) => (
              <button
                key={s}
                onClick={() => setSlippage(s)}
                className={`px-2 py-0.5 rounded border ${
                  slippage === s
                    ? 'bg-[#0284c7] text-white border-[#0284c7]'
                    : 'bg-[#111624] border-[#1f283d] text-[#8a93a8]'
                }`}
              >
                {s}%
              </button>
            ))}
          </div>
        </div>

        {txSuccess && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{txSuccess}</span>
          </div>
        )}

        <button
          onClick={handleSwap}
          disabled={loading || parsedIn <= 0}
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#0284c7] to-[#0369a1] hover:from-[#38bdf8] hover:to-[#0284c7] text-white font-bold shadow-lg shadow-cyan-950/40 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Routing through Raydium Pool...</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4" />
              <span>Instant Swap</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
