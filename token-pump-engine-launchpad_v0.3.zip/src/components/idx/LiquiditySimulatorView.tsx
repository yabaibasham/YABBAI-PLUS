import React, { useState } from 'react';
import { BarChart3, TrendingUp, Sliders, ShieldAlert, ArrowRight } from 'lucide-react';

export const LiquiditySimulatorView: React.FC = () => {
  const [baseTokens, setBaseTokens] = useState<number>(877383839);
  const [solLiquidity, setSolLiquidity] = useState<number>(10);
  const solPriceUsd = 148.5;

  const initialPriceSol = baseTokens > 0 ? solLiquidity / baseTokens : 0;
  const initialPriceUsd = initialPriceSol * solPriceUsd;
  const initialMarketCap = 1_000_000_000 * initialPriceUsd;
  const poolDepthUsd = solLiquidity * 2 * solPriceUsd;

  const scenarios = [0.1, 0.5, 1.0, 5.0, 10.0, 25.0];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 font-mono text-xs">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-[10px] text-cyan-400 font-bold uppercase">
            Raydium AMM Math Simulator
          </span>
          <span className="text-[#8a93a8]">Constant Product (x * y = k)</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Liquidity Simulator · Price Impact & Slippage
        </h1>
        <p className="text-[#8a93a8] mt-1 text-sm font-sans">
          Simulate how pool liquidity depth directly dampens price volatility and protects against sniper dumps.
        </p>
      </div>

      {/* Simulator Inputs */}
      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white uppercase">
          Seed Parameters
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-[#8a93a8] block mb-1">Base Token Liquidity Amount</label>
            <input
              type="number"
              value={baseTokens}
              onChange={(e) => setBaseTokens(parseFloat(e.target.value) || 0)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1">Quote SOL Liquidity Amount</label>
            <input
              type="number"
              step="0.5"
              value={solLiquidity}
              onChange={(e) => setSolLiquidity(parseFloat(e.target.value) || 0)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
            />
          </div>
        </div>

        {/* Calculated Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#111624] p-3.5 rounded-lg border border-[#1f283d]">
          <div>
            <span className="text-[#8a93a8] text-[10px]">INITIAL PRICE (SOL)</span>
            <div className="text-white font-bold mt-0.5">{initialPriceSol.toFixed(10)} SOL</div>
          </div>
          <div>
            <span className="text-[#8a93a8] text-[10px]">INITIAL PRICE (USD)</span>
            <div className="text-emerald-400 font-bold mt-0.5">${initialPriceUsd.toFixed(8)}</div>
          </div>
          <div>
            <span className="text-[#8a93a8] text-[10px]">INITIAL MARKET CAP</span>
            <div className="text-cyan-300 font-bold mt-0.5">${Math.round(initialMarketCap).toLocaleString()}</div>
          </div>
          <div>
            <span className="text-[#8a93a8] text-[10px]">TOTAL POOL DEPTH</span>
            <div className="text-white font-bold mt-0.5">${Math.round(poolDepthUsd).toLocaleString()}</div>
          </div>
        </div>
      </div>

      {/* Price Impact Table */}
      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-3">
        <h3 className="text-sm font-bold text-white uppercase">
          Simulated Buy Orders vs Price Impact
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-[#1b2234] text-[#8a93a8]">
                <th className="pb-3">BUY SIZE (SOL)</th>
                <th className="pb-3">USD VALUE</th>
                <th className="pb-3">TOKENS RECEIVED</th>
                <th className="pb-3">NEW PRICE (USD)</th>
                <th className="pb-3 text-right">PRICE IMPACT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161c2b]">
              {scenarios.map((buySol) => {
                const k = solLiquidity * baseTokens;
                const newSol = solLiquidity + buySol;
                const newBase = k / newSol;
                const tokensRec = baseTokens - newBase;
                const newPriceSol = newSol / newBase;
                const newPriceUsd = newPriceSol * solPriceUsd;
                const impactPct = ((newPriceSol - initialPriceSol) / (initialPriceSol || 1)) * 100;

                return (
                  <tr key={buySol} className="hover:bg-[#111624] transition-colors">
                    <td className="py-2.5 font-bold text-white">{buySol} SOL</td>
                    <td className="py-2.5 text-[#8a93a8]">${(buySol * solPriceUsd).toFixed(2)}</td>
                    <td className="py-2.5 text-cyan-300">{Math.round(tokensRec).toLocaleString()}</td>
                    <td className="py-2.5 text-emerald-400">${newPriceUsd.toFixed(8)}</td>
                    <td className={`py-2.5 text-right font-bold ${impactPct > 20 ? 'text-amber-400' : 'text-emerald-400'}`}>
                      +{impactPct.toFixed(2)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
