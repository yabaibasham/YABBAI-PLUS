import React, { useState } from 'react';
import { TokenMetadata } from '../../types';
import {
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  Droplets,
  Play,
  ArrowRight,
  Globe,
  Send,
  Lock,
  Layers,
  Zap,
  Check,
  Wallet,
} from 'lucide-react';
import { MintAllTokensModal } from './MintAllTokensModal';
import {
  createAndSignSplTokenWithPhantom,
  TokenCreationFeeBreakdown,
} from '../../utils/solanaTokenCreator';

interface CreateTokenProViewProps {
  onTokenCreated: () => void;
  onNavigateToPool: () => void;
  tokens?: TokenMetadata[];
  recipientAddress?: string;
}

const PRESET_TOKENS = [
  {
    name: 'BLANK NETWORK MEME COIN',
    symbol: 'BLANK',
    supply: 1_000_000_000,
    decimals: 6,
    logo: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=128&q=80',
    desc: 'BLANK NETWORK MEME COIN ($BLANK) - The adorable golden alpaca meme coin with autonomous flywheel on Solana Mainnet-Beta.',
    website: 'https://blanknetwork.vip',
    twitter: 'https://x.com/BlankNetworkSol',
    telegram: 'https://t.me/BlankNetworkSol',
  },
  {
    name: 'Ferrari Inu',
    symbol: 'RARINU',
    supply: 1_000_000_000,
    decimals: 6,
    logo: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=128&q=80',
    desc: 'Ferrari Inu - The fastest hypercar meme token on Solana Mainnet-Beta.',
    website: 'https://rarinu.io',
    twitter: 'https://x.com/rarinufast',
    telegram: 'https://t.me/rarinutoken',
  },
  {
    name: 'Omega Alien',
    symbol: 'OMEGA',
    supply: 1_000_000_000,
    decimals: 6,
    logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    desc: 'Omega Alien - Autonomous AI operator token with pump flywheel mechanics.',
    website: 'https://omega-alien.io',
    twitter: 'https://x.com/omegaalien',
    telegram: 'https://t.me/omegaalien',
  },
  {
    name: 'Pepe Solana',
    symbol: 'PEPESOL',
    supply: 420_690_000_000,
    decimals: 6,
    logo: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=128&q=80',
    desc: 'The original green frog on high-speed Solana blockchain.',
    website: 'https://pepesol.vip',
    twitter: 'https://x.com/pepesol',
    telegram: 'https://t.me/pepesol',
  },
  {
    name: 'Cyber Doge',
    symbol: 'CDOGE',
    supply: 100_000_000,
    decimals: 6,
    logo: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=128&q=80',
    desc: 'Next generation decentralized dog currency for AI micro-payments.',
    website: 'https://cyberdoge.xyz',
    twitter: 'https://x.com/cyberdoge',
    telegram: 'https://t.me/cyberdoge',
  },
];

export const CreateTokenProView: React.FC<CreateTokenProViewProps> = ({
  onTokenCreated,
  onNavigateToPool,
  tokens = [],
  recipientAddress = 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i',
}) => {
  const [showMintAllModal, setShowMintAllModal] = useState<boolean>(false);

  // Token Architecture / Standard
  const [tokenType, setTokenType] = useState<'SPL' | 'TOKEN_2022' | 'PUMP_FUN'>('SPL');

  // Token Identity & Metadata
  const [name, setName] = useState<string>('Ferrari Inu');
  const [symbol, setSymbol] = useState<string>('RARINU');
  const [decimals, setDecimals] = useState<number>(6);
  const [supply, setSupply] = useState<number>(1_000_000_000);
  const [description, setDescription] = useState<string>(
    'Ferrari Inu - The fastest meme coin on Solana with auto liquidity buybacks.'
  );
  const [logoUrl, setLogoUrl] = useState<string>(
    'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=128&q=80'
  );
  const [website, setWebsite] = useState<string>('https://rarinu.io');
  const [twitter, setTwitter] = useState<string>('https://x.com/rarinufast');
  const [telegram, setTelegram] = useState<string>('https://t.me/rarinutoken');

  // Token-2022 Transfer Fee Settings
  const [transferFeePct, setTransferFeePct] = useState<number>(2.0);

  // Security Checklist (DexScreener Audit Badge Guarantee)
  const [revokeFreeze, setRevokeFreeze] = useState<boolean>(true);
  const [revokeMint, setRevokeMint] = useState<boolean>(true);
  const [immutableMetadata, setImmutableMetadata] = useState<boolean>(true);

  // Minimal Fee Mode for Phantom Wallet
  const [minimalMode, setMinimalMode] = useState<'MINT_AND_ATA' | 'MINT_ONLY'>('MINT_AND_ATA');

  // UI state
  const [loading, setLoading] = useState<boolean>(false);
  const [statusStep, setStatusStep] = useState<string>('');
  const [isDemoActive, setIsDemoActive] = useState<boolean>(false);
  const [createdResult, setCreatedResult] = useState<{
    token: TokenMetadata;
    tx: string;
    recipientAta?: string;
    feeBreakdown?: TokenCreationFeeBreakdown;
    inHouseFeeSignature?: string;
    signedByPhantom?: boolean;
  } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Apply a preset
  const handleApplyPreset = (p: (typeof PRESET_TOKENS)[0]) => {
    setName(p.name);
    setSymbol(p.symbol);
    setSupply(p.supply);
    setDecimals(p.decimals);
    setLogoUrl(p.logo);
    setDescription(p.desc);
    setWebsite(p.website);
    setTwitter(p.twitter);
    setTelegram(p.telegram);
  };

  // Interactive Demo Toggle
  const handleToggleDemo = () => {
    setIsDemoActive(!isDemoActive);
    if (!isDemoActive) {
      handleApplyPreset(PRESET_TOKENS[0]);
      setTokenType('SPL');
      setRevokeFreeze(true);
      setRevokeMint(true);
      setImmutableMetadata(true);
    }
  };

  // Quick supply selectors
  const handleSetSupply = (amount: number) => {
    setSupply(amount);
  };

  // Creation handler with In-House Website Fee Waiver (0 SOL) + Phantom Minimal Rent Co-Signing
  const handleCreateToken = async () => {
    if (!name.trim() || !symbol.trim()) {
      setErrorMsg('Please enter a valid Token Name and Symbol.');
      return;
    }
    if (supply <= 0) {
      setErrorMsg('Token supply must be greater than 0.');
      return;
    }

    try {
      setLoading(true);
      setErrorMsg(null);
      setStatusStep('Initializing In-House Fee Waiver & Connecting Phantom...');

      const res = await createAndSignSplTokenWithPhantom({
        name: name.trim(),
        symbol: symbol.trim().toUpperCase(),
        decimals,
        supply,
        fallbackWallet: recipientAddress || 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i',
        logo:
          logoUrl ||
          'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png',
        description,
        website,
        twitter,
        telegram,
        tokenStandard: tokenType === 'TOKEN_2022' ? 'Token-2022' : 'SPL',
        transferFeeBasisPoints: tokenType === 'TOKEN_2022' ? transferFeePct * 100 : 0,
        revokeMint,
        revokeFreeze,
        minimalMode,
        cluster: 'mainnet-beta',
        onStatusUpdate: (step) => setStatusStep(step),
      });

      if (!res.ok) {
        setErrorMsg(res.error || 'Failed to sign or broadcast token creation transaction.');
        return;
      }

      const createdToken: TokenMetadata = res.token || {
        name: name.trim(),
        symbol: symbol.trim().toUpperCase(),
        mint: res.mint || '',
        supply,
        userBalance: supply,
        decimals,
        logo: logoUrl,
        recipientAta: res.recipientAta,
        txSignature: res.txSignature,
      };

      setCreatedResult({
        token: createdToken,
        tx: res.txSignature || res.mint || '',
        recipientAta: res.recipientAta,
        feeBreakdown: res.feeBreakdown,
        inHouseFeeSignature: res.inHouseFeeSignature,
        signedByPhantom: res.signedByPhantom,
      });
      onTokenCreated();
    } catch (e: any) {
      setErrorMsg(e?.message || 'Network error while deploying token on Solana Mainnet.');
    } finally {
      setLoading(false);
      setStatusStep('');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 font-sans">
      <MintAllTokensModal
        isOpen={showMintAllModal}
        onClose={() => setShowMintAllModal(false)}
        tokens={tokens.length > 0 ? tokens : PRESET_TOKENS.map((p) => ({
          name: p.name,
          symbol: p.symbol,
          decimals: p.decimals,
          mint: `Mint${p.symbol}11111111111111111111111111111111`,
          logo: p.logo,
          description: p.desc,
          supply: p.supply,
          userBalance: p.supply * 0.3,
          tokenStandard: 'SPL' as const,
        }))}
        recipientAddress={recipientAddress}
        onSuccess={() => {
          onTokenCreated();
        }}
      />

      {/* Title & Subtitle Matching Screenshot Design */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="rounded bg-[#0284c7]/20 border border-[#0284c7]/40 px-2 py-0.5 text-[11px] font-mono font-bold uppercase text-[#38bdf8]">
              STEP 0 · TOKEN FOUNDRY & FAIR LAUNCH
            </span>
            <span className="text-xs text-[#8a9bb4] font-mono">Solana Mainnet-Beta Engine</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Create Solana Token
          </h1>
          <p className="text-sm text-[#8a9bb4] mt-2 max-w-3xl leading-relaxed">
            Mint your verified Solana SPL or Token-2022 asset on <strong className="text-white font-semibold">Mainnet-Beta</strong> in two simple steps. Configure token name, ticker symbol, supply, decimals, and custom branding metadata. Revoke freeze and mint authorities to guarantee <strong className="text-emerald-400 font-semibold">DexScreener green badges</strong>, then immediately seed Raydium liquidity to enable public trading.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap self-start sm:self-auto shrink-0">
          <button
            type="button"
            onClick={() => setShowMintAllModal(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-xs font-mono font-bold text-white flex items-center gap-2 transition-all shadow-lg shadow-cyan-950/40"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Mint All & Airdrop 30%</span>
          </button>

          <button
            type="button"
            onClick={onNavigateToPool}
            className="px-4 py-2 rounded-xl bg-[#111827] border border-[#27374f] hover:border-[#38bdf8] text-xs font-mono font-bold text-[#38bdf8] flex items-center gap-2 transition-all"
          >
            <Droplets className="w-3.5 h-3.5 fill-current" />
            <span>Pool Creator →</span>
          </button>
        </div>
      </div>

      {/* Interactive Demo Banner Matching Screenshot */}
      <div
        onClick={handleToggleDemo}
        className="cursor-pointer group relative overflow-hidden rounded-xl border border-[#0284c7]/40 bg-gradient-to-r from-[#0369a1]/20 via-[#075985]/15 to-[#082f49]/20 p-4 transition-all hover:border-[#38bdf8]/60 hover:shadow-lg hover:shadow-cyan-950/30"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0284c7] text-white shadow-md shadow-cyan-900/50 group-hover:scale-105 transition-transform">
              <Play className="h-4 w-4 fill-white" />
            </div>
            <div>
              <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#38bdf8]">
                INTERACTIVE DEMO
              </div>
              <div className="text-sm font-semibold text-white">
                {isDemoActive ? 'Demo Active: Realistic Ferrari Inu (RARINU) Token Minting' : 'View Live Example'}
              </div>
            </div>
          </div>
          <ArrowRight className="h-5 w-5 text-[#38bdf8] group-hover:translate-x-1 transition-transform" />
        </div>
      </div>

      {/* Preset Token Quick Bar */}
      <div className="flex flex-wrap items-center gap-2 pt-1 pb-1">
        <span className="text-xs font-mono text-[#8a9bb4] uppercase font-bold mr-1">
          Quick Presets:
        </span>
        {PRESET_TOKENS.map((p, idx) => (
          <button
            key={`${p.symbol}-${idx}`}
            type="button"
            onClick={() => handleApplyPreset(p)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-mono transition-all flex items-center gap-2 ${
              symbol === p.symbol
                ? 'bg-[#0284c7]/20 border-[#38bdf8] text-white font-bold shadow-sm'
                : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4] hover:text-white hover:border-[#27374f]'
            }`}
          >
            <img src={p.logo} alt={p.symbol} className="w-4 h-4 rounded-full object-cover" />
            <span>{p.name} ({p.symbol})</span>
          </button>
        ))}
      </div>

      {/* STEP 1: TOKEN ARCHITECTURE & STANDARD */}
      <div className="rounded-xl border border-[#1f2a3a] bg-[#0b1018] p-5 sm:p-6 shadow-xl space-y-4">
        <div>
          <span className="inline-block rounded bg-[#0284c7]/20 border border-[#0284c7]/40 px-2 py-0.5 text-[11px] font-mono font-bold uppercase text-[#38bdf8]">
            STEP 1
          </span>
          <span className="ml-2 text-xs font-mono font-bold tracking-wide text-white uppercase">
            TOKEN ARCHITECTURE & STANDARD
          </span>
          <p className="text-xs text-[#8a9bb4] mt-1">
            Choose your token standard, tax mechanics, and DEX router compatibility
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
          {[
            {
              id: 'SPL' as const,
              title: 'Standard SPL Token',
              badge: 'Raydium & Jupiter 100%',
              desc: 'Standard Solana SPL token with zero transfer taxes. Optimal for Raydium AMM / CPMM pools, Orca, and DexScreener trading.',
              icon: Sparkles,
              tagColor: 'text-[#38bdf8] border-cyan-500/40 bg-cyan-500/10',
            },
            {
              id: 'TOKEN_2022' as const,
              title: 'Token-2022 Tax Token',
              badge: 'Creator Buyback Tax',
              desc: 'Solana Token Extensions program. Enforces programmable transfer fee (0.5%–5%) automatically routed to your flywheel treasury.',
              icon: Layers,
              tagColor: 'text-amber-400 border-amber-500/40 bg-amber-500/10',
            },
            {
              id: 'PUMP_FUN' as const,
              title: 'Pump.fun Fair Launch',
              badge: 'Bonding Curve Hook',
              desc: 'Instant bonding curve deployment on pump.fun with automated Raydium migration hook once the bonding curve target is filled.',
              icon: Zap,
              tagColor: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10',
            },
          ].map((item) => {
            const Icon = item.icon;
            const isSelected = tokenType === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTokenType(item.id)}
                className={`p-4 rounded-xl border text-left transition-all relative flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#111f33] border-[#38bdf8] text-white shadow-lg shadow-cyan-950/40'
                    : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4] hover:border-[#27374f] hover:text-white'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase border ${item.tagColor}`}>
                      {item.badge}
                    </span>
                    {isSelected && <Check className="w-4 h-4 text-[#38bdf8]" />}
                  </div>
                  <div className="text-sm font-bold text-white font-mono flex items-center gap-2">
                    <Icon className="w-4 h-4 text-[#38bdf8]" />
                    <span>{item.title}</span>
                  </div>
                  <p className="text-xs text-[#8a9bb4] mt-2 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Transfer Fee Slider for Token-2022 */}
        {tokenType === 'TOKEN_2022' && (
          <div className="p-4 rounded-xl bg-[#111827] border border-[#27374f] space-y-2 mt-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-white font-bold">Transfer Fee Percentage</span>
              <span className="text-cyan-400 font-bold px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800">
                {transferFeePct}%
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="5.0"
              step="0.5"
              value={transferFeePct}
              onChange={(e) => setTransferFeePct(parseFloat(e.target.value))}
              className="w-full accent-[#0284c7]"
            />
            <p className="text-[11px] text-[#8a9bb4]">
              Each transfer automatically sends {transferFeePct}% of tokens to the creator treasury for buybacks and liquidity compounding.
            </p>
          </div>
        )}
      </div>

      {/* STEP 2: METADATA & SUPPLY CONFIGURATION */}
      <div className="rounded-xl border border-[#1f2a3a] bg-[#0b1018] p-5 sm:p-6 shadow-xl space-y-5">
        <div>
          <span className="inline-block rounded bg-[#0284c7]/20 border border-[#0284c7]/40 px-2 py-0.5 text-[11px] font-mono font-bold uppercase text-[#38bdf8]">
            STEP 2
          </span>
          <span className="ml-2 text-xs font-mono font-bold tracking-wide text-white uppercase">
            METADATA & SUPPLY CONFIGURATION
          </span>
          <p className="text-xs text-[#8a9bb4] mt-1">
            Specify token identity, ticker symbol, supply cap, and on-chain visual branding
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Token Name */}
          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <label className="block text-xs font-medium text-[#8a9bb4] mb-1 font-mono">
              Token Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Ferrari Inu"
              className="w-full bg-transparent text-base font-bold text-white focus:outline-none font-mono"
            />
          </div>

          {/* Token Symbol */}
          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <label className="block text-xs font-medium text-[#8a9bb4] mb-1 font-mono">
              Ticker Symbol
            </label>
            <input
              type="text"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              placeholder="e.g. RARINU"
              className="w-full bg-transparent text-base font-bold text-white focus:outline-none font-mono uppercase"
            />
          </div>

          {/* Total Supply */}
          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <div className="flex items-center justify-between text-xs text-[#8a9bb4] mb-1 font-mono">
              <span>Total Supply</span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleSetSupply(1_000_000_000)}
                  className="px-1.5 py-0.5 rounded bg-[#1c2539] hover:bg-[#27374f] text-[10px] text-[#8a9bb4] hover:text-white"
                >
                  1B
                </button>
                <button
                  type="button"
                  onClick={() => handleSetSupply(100_000_000)}
                  className="px-1.5 py-0.5 rounded bg-[#1c2539] hover:bg-[#27374f] text-[10px] text-[#8a9bb4] hover:text-white"
                >
                  100M
                </button>
                <button
                  type="button"
                  onClick={() => handleSetSupply(10_000_000)}
                  className="px-1.5 py-0.5 rounded bg-[#1c2539] hover:bg-[#27374f] text-[10px] text-[#8a9bb4] hover:text-white"
                >
                  10M
                </button>
              </div>
            </div>
            <input
              type="number"
              value={supply}
              onChange={(e) => setSupply(parseFloat(e.target.value) || 0)}
              placeholder="1000000000"
              className="w-full bg-transparent text-base font-bold text-white focus:outline-none font-mono"
            />
          </div>

          {/* Decimals */}
          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <label className="block text-xs font-medium text-[#8a9bb4] mb-1 font-mono">
              Decimals
            </label>
            <select
              value={decimals}
              onChange={(e) => setDecimals(parseInt(e.target.value, 10))}
              className="w-full bg-[#111827] text-sm font-bold text-white focus:outline-none font-mono"
            >
              <option value="6">6 Decimals (Standard for Solana Meme & Utility Coins)</option>
              <option value="9">9 Decimals (Standard for SOL / Wrapped assets)</option>
            </select>
          </div>

          {/* Logo URL with Live Thumbnail */}
          <div className="md:col-span-2 rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <label className="block text-xs font-medium text-[#8a9bb4] mb-1 font-mono">
              Logo Image URL (Square PNG / WEBP / JPEG)
            </label>
            <div className="flex items-center gap-3">
              <img
                src={logoUrl || 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png'}
                alt="Logo Preview"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png';
                }}
                className="w-10 h-10 rounded-full object-cover border-2 border-[#27374f] shrink-0"
              />
              <input
                type="text"
                value={logoUrl}
                onChange={(e) => setLogoUrl(e.target.value)}
                placeholder="https://.../logo.png"
                className="w-full bg-transparent text-xs text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Description */}
          <div className="md:col-span-2 rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <label className="block text-xs font-medium text-[#8a9bb4] mb-1 font-mono">
              Token Description (On-Chain Metaplex Metadata)
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description for DexScreener, Raydium, and Birdeye..."
              className="w-full bg-transparent text-xs text-white focus:outline-none font-mono"
            />
          </div>

          {/* Social Links */}
          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <label className="flex items-center gap-1.5 text-xs font-medium text-[#8a9bb4] mb-1 font-mono">
              <Globe className="w-3.5 h-3.5" />
              <span>Project Website</span>
            </label>
            <input
              type="text"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              placeholder="https://yourtoken.io"
              className="w-full bg-transparent text-xs text-white focus:outline-none font-mono"
            />
          </div>

          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <label className="flex items-center gap-1.5 text-xs font-medium text-[#8a9bb4] mb-1 font-mono">
              <Send className="w-3.5 h-3.5" />
              <span>Telegram Group</span>
            </label>
            <input
              type="text"
              value={telegram}
              onChange={(e) => setTelegram(e.target.value)}
              placeholder="https://t.me/yourtoken"
              className="w-full bg-transparent text-xs text-white focus:outline-none font-mono"
            />
          </div>
        </div>
      </div>

      {/* STEP 3: SECURITY AUDIT & DEXSCREENER TRUST CHECKLIST */}
      <div className="rounded-xl border border-[#1f2a3a] bg-[#0b1018] p-5 sm:p-6 shadow-xl space-y-4">
        <div>
          <span className="inline-block rounded bg-[#0284c7]/20 border border-[#0284c7]/40 px-2 py-0.5 text-[11px] font-mono font-bold uppercase text-[#38bdf8]">
            STEP 3
          </span>
          <span className="ml-2 text-xs font-mono font-bold tracking-wide text-white uppercase">
            SECURITY AUDIT & DEXSCREENER TRUST CHECKLIST
          </span>
          <p className="text-xs text-[#8a9bb4] mt-1">
            Enforce authority revocations to guarantee 100% green checkmarks on DexScreener, Birdeye, and RugCheck
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          {/* Revoke Freeze */}
          <label className={`p-4 rounded-xl border cursor-pointer transition-all ${
            revokeFreeze
              ? 'bg-[#0d1e18] border-emerald-500/50 text-white'
              : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4]'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <ShieldCheck className={`w-5 h-5 ${revokeFreeze ? 'text-emerald-400' : 'text-[#8a9bb4]'}`} />
              <input
                type="checkbox"
                checked={revokeFreeze}
                onChange={(e) => setRevokeFreeze(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </div>
            <div className="text-xs font-bold font-mono text-white">Revoke Freeze Authority</div>
            <div className="text-[11px] text-[#8a9bb4] mt-1">
              Prevents creator from blacklisting wallets or locking token transfers.
            </div>
          </label>

          {/* Revoke Mint */}
          <label className={`p-4 rounded-xl border cursor-pointer transition-all ${
            revokeMint
              ? 'bg-[#0d1e18] border-emerald-500/50 text-white'
              : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4]'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <Lock className={`w-5 h-5 ${revokeMint ? 'text-emerald-400' : 'text-[#8a9bb4]'}`} />
              <input
                type="checkbox"
                checked={revokeMint}
                onChange={(e) => setRevokeMint(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </div>
            <div className="text-xs font-bold font-mono text-white">Revoke Mint Authority</div>
            <div className="text-[11px] text-[#8a9bb4] mt-1">
              Strictly caps total supply. Guarantees no additional tokens can ever be minted.
            </div>
          </label>

          {/* Immutability */}
          <label className={`p-4 rounded-xl border cursor-pointer transition-all ${
            immutableMetadata
              ? 'bg-[#0d1e18] border-emerald-500/50 text-white'
              : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4]'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <CheckCircle2 className={`w-5 h-5 ${immutableMetadata ? 'text-emerald-400' : 'text-[#8a9bb4]'}`} />
              <input
                type="checkbox"
                checked={immutableMetadata}
                onChange={(e) => setImmutableMetadata(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </div>
            <div className="text-xs font-bold font-mono text-white">Immutable Metadata</div>
            <div className="text-[11px] text-[#8a9bb4] mt-1">
              Permanently locks token name, symbol, and logo URL on the Solana blockchain.
            </div>
          </label>
        </div>

        {/* IN-HOUSE WEBSITE FEE WAIVER & MINIMAL PHANTOM CREATION FEE PANEL */}
        <div className="rounded-xl border border-emerald-500/40 bg-gradient-to-r from-[#091815] via-[#0c1b24] to-[#091815] p-4 space-y-3 text-xs font-mono">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-500/20 pb-3">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-[10px] uppercase">
                IN-HOUSE FEE SIGNED & WAIVED (0 SOL)
              </span>
              <span className="text-white font-bold">
                Minimal Phantom Wallet On-Chain Creation Fee
              </span>
            </div>
            <div className="text-emerald-400 font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>Website Fee: 0.00000 SOL ($0.00)</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setMinimalMode('MINT_AND_ATA')}
              className={`p-3 rounded-xl border text-left transition-all ${
                minimalMode === 'MINT_AND_ATA'
                  ? 'bg-emerald-500/15 border-emerald-400 text-white shadow-md'
                  : 'bg-[#0b1018] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white">
                  Standard Minimal (Mint + ATA + Full Supply)
                </span>
                <span className="text-emerald-300 font-extrabold">~0.00351 SOL</span>
              </div>
              <div className="text-[11px] text-[#8a9bb4] mt-1">
                Creates SPL Mint (0.00146 SOL) + Associated Token Account (0.00204 SOL) + Mints {supply.toLocaleString()} ${symbol} to Phantom + 0 SOL Website Fee.
              </div>
            </button>

            <button
              type="button"
              onClick={() => setMinimalMode('MINT_ONLY')}
              className={`p-3 rounded-xl border text-left transition-all ${
                minimalMode === 'MINT_ONLY'
                  ? 'bg-cyan-500/15 border-cyan-400 text-white shadow-md'
                  : 'bg-[#0b1018] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white">
                  Ultra-Minimal Bare Mint Only (Lowest Possible)
                </span>
                <span className="text-cyan-300 font-extrabold">~0.00147 SOL</span>
              </div>
              <div className="text-[11px] text-[#8a9bb4] mt-1">
                Only pays Solana 82-byte Mint rent-exemption (0.0014616 SOL) + 0.00001 SOL network fee + 0 SOL Website Fee.
              </div>
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] text-[#8a9bb4]">
            <span>
              In-House Website Fee: <strong className="line-through text-slate-500">0.15 SOL</strong>{' '}
              <strong className="text-emerald-400">0.00000 SOL (Signed In-House)</strong>
            </span>
            <span>
              Revoke Mint + Freeze Fee: <strong className="line-through text-slate-500">0.05 SOL</strong>{' '}
              <strong className="text-emerald-400">0.00000 SOL (Signed In-House)</strong>
            </span>
            <span>
              Total Phantom Rent: <strong className="text-white">{minimalMode === 'MINT_ONLY' ? '~0.00147 SOL' : '~0.00351 SOL'}</strong>
            </span>
          </div>
        </div>

        {/* Audit Status Bar */}
        <div className="rounded-xl bg-[#090c14] border border-[#192133] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-white font-bold">Audit Score:</span>
            <span className="text-emerald-400 font-bold">100% SAFE / ANTI-RUG VERIFIED</span>
          </div>
          <div className="text-[#8a9bb4] flex items-center gap-3">
            <span>Mint Revoked: {revokeMint ? 'YES' : 'NO'}</span>
            <span>Freeze Revoked: {revokeFreeze ? 'YES' : 'NO'}</span>
            <span>Standard: {tokenType}</span>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-mono">
            {errorMsg}
          </div>
        )}

        {/* Primary Action Button */}
        <div className="pt-2">
          <button
            type="button"
            disabled={loading}
            onClick={handleCreateToken}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-600 via-[#0284c7] to-purple-600 hover:from-emerald-500 hover:via-[#38bdf8] hover:to-purple-500 text-white font-bold text-sm font-mono tracking-wide shadow-xl shadow-cyan-950/60 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>{statusStep || 'Signing In-House & Broadcasting to Solana Mainnet...'}</span>
              </>
            ) : (
              <>
                <Wallet className="w-4 h-4" />
                <span>
                  Sign in Phantom & Create Token On-Chain ({symbol} · {minimalMode === 'MINT_ONLY' ? '~0.00147 SOL' : '~0.00351 SOL'} Rent · 0 SOL Site Fee)
                </span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Token Deployed Success Modal / Banner */}
      {createdResult && (
        <div className="rounded-xl border border-emerald-500/40 bg-[#091512] p-5 sm:p-6 shadow-2xl space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-full bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-mono">
                  Solana Token Created & Co-Signed On-Chain!
                </h3>
                <p className="text-xs text-[#8a9bb4] mt-0.5">
                  Mint Address: <span className="text-cyan-300 font-mono font-bold">{createdResult.token.mint}</span>
                </p>
                {createdResult.tx && (
                  <p className="text-xs text-emerald-300 font-mono mt-0.5">
                    Tx Signature: <span className="font-bold">{createdResult.tx.slice(0, 20)}...</span>
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={() => setCreatedResult(null)}
              className="text-[#8a9bb4] hover:text-white text-xs font-mono"
            >
              Dismiss
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0d1f1a] p-3.5 rounded-xl text-xs font-mono">
            <div>
              <span className="text-[#8a9bb4]">TOKEN NAME</span>
              <div className="text-white font-bold mt-0.5">{createdResult.token.name}</div>
            </div>
            <div>
              <span className="text-[#8a9bb4]">TICKER</span>
              <div className="text-emerald-400 font-bold mt-0.5">{createdResult.token.symbol}</div>
            </div>
            <div>
              <span className="text-[#8a9bb4]">WEBSITE FEE</span>
              <div className="text-emerald-400 font-bold mt-0.5">0.00000 SOL (Signed In-House)</div>
            </div>
            <div>
              <span className="text-[#8a9bb4]">STATUS</span>
              <div className="text-cyan-400 font-bold mt-0.5">
                {createdResult.signedByPhantom ? 'Phantom + In-House Signed' : 'In-House Co-Signed'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <a
              href={`https://solscan.io/token/${createdResult.token.mint}`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#142922] hover:bg-[#1a382e] border border-emerald-500/30 text-xs font-mono text-emerald-300 flex items-center gap-1.5 transition-colors"
            >
              <span>View Token on Solscan</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            {createdResult.tx && createdResult.tx !== createdResult.token.mint && (
              <a
                href={`https://solscan.io/tx/${createdResult.tx}`}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-lg bg-[#142922] hover:bg-[#1a382e] border border-cyan-500/30 text-xs font-mono text-cyan-300 flex items-center gap-1.5 transition-colors"
              >
                <span>View Tx on Solscan</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
            <a
              href={`https://dexscreener.com/solana/${createdResult.token.mint}`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#142922] hover:bg-[#1a382e] border border-emerald-500/30 text-xs font-mono text-emerald-300 flex items-center gap-1.5 transition-colors"
            >
              <span>DexScreener</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={onNavigateToPool}
              className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs font-mono transition-colors ml-auto flex items-center gap-2"
            >
              <Droplets className="w-3.5 h-3.5" />
              <span>Proceed to Step 2: Create Liquidity Pool →</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
