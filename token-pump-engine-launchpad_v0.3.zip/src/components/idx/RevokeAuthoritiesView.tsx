import React, { useState } from 'react';
import { TokenMetadata } from '../../types';
import { ShieldCheck, ShieldAlert, CheckCircle2, RefreshCw, Lock, AlertTriangle } from 'lucide-react';

interface RevokeAuthoritiesViewProps {
  tokens: TokenMetadata[];
  onRefresh: () => void;
}

export const RevokeAuthoritiesView: React.FC<RevokeAuthoritiesViewProps> = ({ tokens, onRefresh }) => {
  const [selectedMint, setSelectedMint] = useState<string>(tokens[0]?.mint || '');
  const [loading, setLoading] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const token = tokens.find((t) => t.mint === selectedMint) || tokens[0];

  const handleRevoke = async (authorityType: 'MINT' | 'FREEZE' | 'UPDATE') => {
    if (!token) return;
    try {
      setLoading(authorityType);
      setFeedback(null);
      const res = await fetch('/api/tokens/revoke-authority', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mint: token.mint, authorityType }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setFeedback(`Revoked ${authorityType} authority for ${token.symbol}! Tx: ${data.txSignature}`);
        onRefresh();
      } else {
        setFeedback(data.error || 'Failed to revoke authority.');
      }
    } catch (e: any) {
      setFeedback('Error during revocation.');
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 font-mono text-xs">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-[10px] text-emerald-400 font-bold uppercase">
            Security & Audit Hardening
          </span>
          <span className="text-[#8a93a8]">DexScreener & RugCheck Compliance</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Revoke Authorities · Solana Immutable Shield
        </h1>
        <p className="text-[#8a93a8] mt-1 text-sm font-sans">
          Revoking token authorities is the #1 requirement for retail confidence on DEXScreener. Prove your token cannot be minted or frozen.
        </p>
      </div>

      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <div>
          <label className="text-[#8a93a8] block mb-1">Select Token</label>
          <select
            value={selectedMint}
            onChange={(e) => setSelectedMint(e.target.value)}
            className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none"
          >
            {tokens.map((t, idx) => (
              <option key={`${t.mint}-${idx}`} value={t.mint}>
                {t.symbol} - {t.name}
              </option>
            ))}
          </select>
        </div>

        {feedback && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {/* Freeze Authority */}
          <div className="p-4 rounded-xl bg-[#111624] border border-[#1f283d] flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-white font-bold">Freeze Authority</span>
                {token?.freezeAuthorityRevoked ? (
                  <span className="text-emerald-400">✅ Revoked</span>
                ) : (
                  <span className="text-amber-400">⚠️ Active</span>
                )}
              </div>
              <p className="text-[#8a93a8] text-[11px] leading-relaxed">
                Prevents creator from blacklisting buyer token accounts. Essential for RugCheck green badge.
              </p>
            </div>
            <button
              onClick={() => handleRevoke('FREEZE')}
              disabled={loading === 'FREEZE' || token?.freezeAuthorityRevoked}
              className="w-full py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold disabled:opacity-40 transition-colors"
            >
              {token?.freezeAuthorityRevoked ? 'Already Revoked' : 'Revoke Freeze'}
            </button>
          </div>

          {/* Mint Authority */}
          <div className="p-4 rounded-xl bg-[#111624] border border-[#1f283d] flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-white font-bold">Mint Authority</span>
                {token?.mintAuthorityRevoked ? (
                  <span className="text-emerald-400">✅ Revoked</span>
                ) : (
                  <span className="text-amber-400">⚠️ Active</span>
                )}
              </div>
              <p className="text-[#8a93a8] text-[11px] leading-relaxed">
                Locks supply permanently. Eliminates any risk of dilution or unauthorized printing.
              </p>
            </div>
            <button
              onClick={() => handleRevoke('MINT')}
              disabled={loading === 'MINT' || token?.mintAuthorityRevoked}
              className="w-full py-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold disabled:opacity-40 transition-colors"
            >
              {token?.mintAuthorityRevoked ? 'Already Revoked' : 'Revoke Mint'}
            </button>
          </div>

          {/* Update Authority */}
          <div className="p-4 rounded-xl bg-[#111624] border border-[#1f283d] flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-white font-bold">Update Authority</span>
                {token?.updateAuthorityRevoked ? (
                  <span className="text-emerald-400">✅ Revoked</span>
                ) : (
                  <span className="text-cyan-400">ℹ️ Active</span>
                )}
              </div>
              <p className="text-[#8a93a8] text-[11px] leading-relaxed">
                Locks Metaplex metadata (name, logo, symbol) forever. Makes token 100% immutable.
              </p>
            </div>
            <button
              onClick={() => handleRevoke('UPDATE')}
              disabled={loading === 'UPDATE' || token?.updateAuthorityRevoked}
              className="w-full py-2 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-bold disabled:opacity-40 transition-colors"
            >
              {token?.updateAuthorityRevoked ? 'Already Revoked' : 'Revoke Update'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
