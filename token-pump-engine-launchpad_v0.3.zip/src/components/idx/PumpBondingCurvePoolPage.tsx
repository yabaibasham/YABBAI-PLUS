import React, { useState, useEffect, useRef } from 'react';
import {
  Flame,
  ArrowRightLeft,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  CheckCircle2,
  ExternalLink,
  Copy,
  Zap,
  Lock,
  Layers,
  AlertCircle,
  Coins,
  DollarSign,
  BarChart3,
  Users,
  Award,
  RefreshCw,
  Gift,
  ArrowUpRight,
  ArrowDownRight,
  Code2,
} from 'lucide-react';
import { usePumpEngine } from '../../hooks/usePumpEngine';

interface PumpBondingCurvePoolPageProps {
  onNavigateTab?: (tab: string) => void;
  walletSolBalance?: number;
}

export const PumpBondingCurvePoolPage: React.FC<PumpBondingCurvePoolPageProps> = ({
  onNavigateTab,
  walletSolBalance = 8.45,
}) => {
  const { executeSwap, loading: swapLoading, error: swapError } = usePumpEngine();

  // Mode & Inputs
  const [tradeMode, setTradeMode] = useState<'BUY' | 'SELL'>('BUY');
  const [solAmountInput, setSolAmountInput] = useState<string>('1.0');
  const [slippage, setSlippage] = useState<string>('1%');
  const [customSlippage, setCustomSlippage] = useState<string>('');
  const [bottomTab, setBottomTab] = useState<'trades' | 'holders' | 'engine_json' | 'anchor_code'>('trades');
  const [claimLoading, setClaimLoading] = useState<boolean>(false);
  const [claimSuccess, setClaimSuccess] = useState<boolean>(false);
  const [claimedTotalSol, setClaimedTotalSol] = useState<number>(0);
  const [statusNotification, setStatusNotification] = useState<string | null>(null);

  // Bonding Curve State
  const [curveData, setCurveData] = useState({
    tokenSymbol: 'EXCEL',
    tokenName: 'Excel Inu',
    mint: 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3',
    currentPriceSol: 0.0000000784,
    currentPriceUsd: 0.0000148,
    change24hPct: 420.69,
    volumeSol24h: 1420.5,
    marketCapUsd: 69420,
    targetThresholdSol: 86.0,
    currentCollectedSol: 55.18,
    virtualSolReserves: 30.0,
    virtualTokenReserves: 1_073_000_000,
    totalSupply: 1_000_000_000,
    claimableCreatorSol: 0.45,
    lpStatus: 'Bonding Curve Active',
    isGraduated: false,
    raydiumPoolAddress: 'RaydiumEXCELPool1111111111111111111111111',
  });

  // Recent Live Transactions Feed
  const [transactions, setTransactions] = useState<
    Array<{
      id: string;
      wallet: string;
      action: 'BUY' | 'SELL';
      tokenAmount: number;
      solAmount: number;
      timestamp: number;
      txHash: string;
    }>
  >([
    {
      id: 'tx-1',
      wallet: '7xKX...9m2p',
      action: 'BUY',
      tokenAmount: 14200,
      solAmount: 0.05,
      timestamp: Date.now() - 1000 * 12,
      txHash: '5eH...38z',
    },
    {
      id: 'tx-2',
      wallet: '3vRt...1kL9',
      action: 'SELL',
      tokenAmount: 50000,
      solAmount: 0.18,
      timestamp: Date.now() - 1000 * 45,
      txHash: '4aQ...89y',
    },
    {
      id: 'tx-3',
      wallet: 'HTN1...ZV5i',
      action: 'BUY',
      tokenAmount: 285000,
      solAmount: 1.0,
      timestamp: Date.now() - 1000 * 120,
      txHash: '9vK...14b',
    },
    {
      id: 'tx-4',
      wallet: '2wPo...5rTy',
      action: 'BUY',
      tokenAmount: 142500,
      solAmount: 0.5,
      timestamp: Date.now() - 1000 * 240,
      txHash: '3dF...71m',
    },
    {
      id: 'tx-5',
      wallet: '9kLm...4qWz',
      action: 'SELL',
      tokenAmount: 85000,
      solAmount: 0.31,
      timestamp: Date.now() - 1000 * 360,
      txHash: '7yH...22n',
    },
  ]);

  // Top Holders Distribution
  const holders = [
    { rank: 1, wallet: 'Bonding Curve Vault (Auto-Lock)', balance: 412_500_000, pct: 41.25, isVault: true },
    { rank: 2, wallet: 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i', balance: 284_100_000, pct: 28.41, isCreator: true },
    { rank: 3, wallet: '7xKXa82mPoqLz9m2pQwsxCdEvfRtbYhnUjmKlO982', balance: 84_500_000, pct: 8.45 },
    { rank: 4, wallet: '3vRtMn98QxLp1kL9JhgFdSaZxCvBnMkiUytReW432', balance: 52_000_000, pct: 5.2 },
    { rank: 5, wallet: '8fGnTq11vVxW9p31aKmBvdEsLoXnmCqWpYrtZ8901', balance: 41_200_000, pct: 4.12 },
    { rank: 6, wallet: '9kLmAq55zZtO4qWzrYuIoPplKjhGfdSaQwErTy765', balance: 35_800_000, pct: 3.58 },
  ];

  // Canvas for Live Bonding Curve Chart
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let t = 0;

    const render = () => {
      t += 0.02;
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      // Background grid
      ctx.strokeStyle = '#151e33';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw Bonding Curve (P = m * S^k + c)
      const gradient = ctx.createLinearGradient(0, height, width, 0);
      gradient.addColorStop(0, '#06b6d4');
      gradient.addColorStop(0.5, '#10b981');
      gradient.addColorStop(1, '#a855f7');

      ctx.beginPath();
      const points: [number, number][] = [];
      const numPoints = 80;

      for (let i = 0; i <= numPoints; i++) {
        const xNorm = i / numPoints;
        // Exponential curve with subtle live pulse
        const yNorm = Math.pow(xNorm, 2.2) + Math.sin(xNorm * 8 + t) * 0.015;
        const x = 50 + xNorm * (width - 100);
        const y = height - 50 - yNorm * (height - 100);
        points.push([x, y]);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }

      ctx.strokeStyle = gradient;
      ctx.lineWidth = 3;
      ctx.shadowColor = '#10b981';
      ctx.shadowBlur = 12;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Area under curve fill
      const areaGradient = ctx.createLinearGradient(0, 0, 0, height);
      areaGradient.addColorStop(0, 'rgba(16, 185, 129, 0.25)');
      areaGradient.addColorStop(1, 'rgba(6, 182, 212, 0.0)');

      ctx.lineTo(points[points.length - 1][0], height - 50);
      ctx.lineTo(points[0][0], height - 50);
      ctx.closePath();
      ctx.fillStyle = areaGradient;
      ctx.fill();

      // Current Price Point Marker (at ~64% progress)
      const progressNorm = curveData.currentCollectedSol / curveData.targetThresholdSol;
      const markerIndex = Math.min(points.length - 1, Math.floor(progressNorm * numPoints));
      const [markerX, markerY] = points[markerIndex] || [width * 0.64, height * 0.4];

      // Outer glow pulse
      const pulseRadius = 7 + Math.sin(t * 3) * 3;
      ctx.beginPath();
      ctx.arc(markerX, markerY, pulseRadius, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(16, 185, 129, 0.4)';
      ctx.fill();

      // Center dot
      ctx.beginPath();
      ctx.arc(markerX, markerY, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      // Graduation Cap Target Line (86 SOL)
      const targetX = width - 50;
      ctx.strokeStyle = '#a855f7';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(targetX, 30);
      ctx.lineTo(targetX, height - 50);
      ctx.stroke();
      ctx.setLineDash([]);

      // Label text
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.fillText('0 SOL', 40, height - 32);
      ctx.fillText('Target: 86 SOL (Raydium Migration)', targetX - 160, 45);
      ctx.fillStyle = '#10b981';
      ctx.fillText(`Current: ${curveData.currentCollectedSol.toFixed(1)} SOL`, markerX - 35, markerY - 14);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [curveData.currentCollectedSol, curveData.targetThresholdSol]);

  // Bonding Curve Math
  const parsedSolAmount = parseFloat(solAmountInput) || 0;
  const estimatedTokenOutput = (() => {
    if (parsedSolAmount <= 0) return 0;
    // k = vSol * vToken
    const k = BigInt(Math.floor(curveData.virtualSolReserves * 1e9)) * BigInt(Math.floor(curveData.virtualTokenReserves * 1e6));
    const newVirtualSol = BigInt(Math.floor(curveData.virtualSolReserves * 1e9)) + BigInt(Math.floor(parsedSolAmount * 1e9));
    const newVirtualToken = k / newVirtualSol;
    const tokensOut = BigInt(Math.floor(curveData.virtualTokenReserves * 1e6)) - newVirtualToken;
    return Number(tokensOut) / 1e6;
  })();

  const graduationPct = (curveData.currentCollectedSol / curveData.targetThresholdSol) * 100;

  // Handle Trade Execution
  const handleExecuteTrade = async () => {
    if (parsedSolAmount <= 0) {
      setStatusNotification('Please specify an amount greater than 0.');
      return;
    }

    const slippageVal = slippage === 'Auto' ? 1.0 : parseFloat(slippage.replace('%', '')) || 1.0;
    const isBuy = tradeMode === 'BUY';

    setStatusNotification(`Initiating ${tradeMode} for ${parsedSolAmount} SOL on Bonding Curve...`);

    const result = await executeSwap(curveData.mint, parsedSolAmount, isBuy, slippageVal);

    if (result.ok) {
      const solDelta = isBuy ? parsedSolAmount : -parsedSolAmount;
      const newCollectedSol = Math.max(0, curveData.currentCollectedSol + solDelta);
      const isGraduatedNow = newCollectedSol >= curveData.targetThresholdSol;

      setCurveData((prev) => ({
        ...prev,
        currentCollectedSol: newCollectedSol,
        volumeSol24h: prev.volumeSol24h + parsedSolAmount,
        marketCapUsd: prev.marketCapUsd + (isBuy ? parsedSolAmount * 180 : -parsedSolAmount * 150),
        claimableCreatorSol: prev.claimableCreatorSol + parsedSolAmount * 0.005, // 0.5% creator fee split
        isGraduated: isGraduatedNow,
        lpStatus: isGraduatedNow ? 'Migrated to Raydium (LP Burned)' : prev.lpStatus,
      }));

      // Add to feed
      setTransactions((prev) => [
        {
          id: `tx-${Date.now()}`,
          wallet: 'HTN1...ZV5i',
          action: isBuy ? 'BUY' : 'SELL',
          tokenAmount: Math.round(estimatedTokenOutput || 14200),
          solAmount: parsedSolAmount,
          timestamp: Date.now(),
          txHash: result.signature ? `${result.signature.slice(0, 4)}...${result.signature.slice(-4)}` : '5eH...91a',
        },
        ...prev.slice(0, 9),
      ]);

      if (isGraduatedNow) {
        setStatusNotification(
          `🎉 GRADUATION TRIGGERED! 86 SOL cap crossed. Liquidity deposited to Raydium AMM with LP tokens permanently burned!`
        );
      } else {
        setStatusNotification(
          `✓ ${tradeMode} successful! Broadcasted signature: ${result.signature || 'Tx confirmed on-chain'}`
        );
      }
    } else {
      setStatusNotification(`Trade note: ${result.error || 'Processed in sandbox mode'}`);
    }
  };

  // Claim Creator Rewards (0.5% fee split)
  const handleClaimCreatorRewards = async () => {
    if (curveData.claimableCreatorSol <= 0) return;
    setClaimLoading(true);
    try {
      await new Promise((res) => setTimeout(res, 800));
      setClaimedTotalSol((prev) => prev + curveData.claimableCreatorSol);
      setStatusNotification(`Successfully claimed ${curveData.claimableCreatorSol.toFixed(4)} SOL creator fee rewards!`);
      setCurveData((prev) => ({ ...prev, claimableCreatorSol: 0 }));
      setClaimSuccess(true);
      setTimeout(() => setClaimSuccess(false), 3000);
    } finally {
      setClaimLoading(false);
    }
  };

  // Smart contract engine parameters specification matching user prompt
  const engineJsonSpec = {
    token_config: {
      standard: 'SPL-Token',
      decimals: 6,
      total_supply: '1,000,000,000',
      mint_authority: 'Revoked upon creation',
      freeze_authority: 'Revoked upon creation',
      transfer_fee_basis_points: 50,
    },
    bonding_curve_params: {
      virtual_sol_reserves: '30.0 SOL',
      real_sol_reserves: `${curveData.currentCollectedSol.toFixed(1)} SOL`,
      virtual_token_reserves: '1,073,000,000',
      migration_threshold_sol: '86.0 SOL',
      target_dex: 'Raydium CPMM / CLMM',
      anti_bot_fair_launch: 'Zero pre-mint allocation for deployer',
      liquidity_lock: 'Permanent LP token burn (Burn Address 11111111111111111111111111111111)',
      creator_fee_split: '0.5% automated bonding curve fee',
    },
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 text-white font-sans">
      {/* 1. Header Bar: Logo | Dashboard | Create Token | Trade | Leaderboard | Wallet: Connected */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-[#090e1c] border border-[#1b263f] shadow-xl">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-emerald-500 to-purple-500 flex items-center justify-center shadow-md shadow-emerald-950">
              <Flame className="w-5 h-5 text-black" />
            </div>
            <div>
              <span className="text-base font-black tracking-tight bg-gradient-to-r from-white via-cyan-200 to-emerald-400 bg-clip-text text-transparent">
                PUMP ENGINE
              </span>
              <span className="text-[10px] font-mono text-cyan-400 block -mt-1 font-bold">SOLANA AMM BONDING CURVE</span>
            </div>
          </div>

          <nav className="hidden sm:flex items-center gap-1 text-xs font-mono">
            <button
              onClick={() => onNavigateTab && onNavigateTab('dashboard')}
              className="px-3 py-1.5 rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#131c31] transition-all"
            >
              Dashboard
            </button>
            <button
              onClick={() => onNavigateTab && onNavigateTab('create_token')}
              className="px-3 py-1.5 rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#131c31] transition-all"
            >
              Create Token
            </button>
            <button
              onClick={() => onNavigateTab && onNavigateTab('pump_engine')}
              className="px-3 py-1.5 rounded-lg text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 font-bold"
            >
              Trade (Curve)
            </button>
            <button
              onClick={() => onNavigateTab && onNavigateTab('meme_launch')}
              className="px-3 py-1.5 rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#131c31] transition-all"
            >
              Leaderboard
            </button>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-[#11192e] border border-emerald-500/30 flex items-center gap-2 text-xs font-mono">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[#94a3b8]">Wallet:</span>
            <span className="text-emerald-300 font-bold">Connected (HTN1...ZV5i)</span>
            <span className="text-[#64748b]">| {walletSolBalance.toFixed(2)} SOL</span>
          </div>
        </div>
      </div>

      {/* Token Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-[#0c1324] border border-[#1b263f]">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-mono text-[#8a9bb4] uppercase font-bold mr-1">Select Token Curve / Pool:</span>
          <button
            type="button"
            onClick={() => {
              setCurveData({
                tokenSymbol: 'EXCEL',
                tokenName: 'Excel Inu',
                mint: 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3',
                currentPriceSol: 0.0000000784,
                currentPriceUsd: 0.0000148,
                change24hPct: 420.69,
                volumeSol24h: 1420.5,
                marketCapUsd: 69420,
                targetThresholdSol: 86.0,
                currentCollectedSol: 55.18,
                virtualSolReserves: 30.0,
                virtualTokenReserves: 1_073_000_000,
                totalSupply: 1_000_000_000,
                claimableCreatorSol: 0.45,
                lpStatus: 'Bonding Curve Active',
                isGraduated: false,
                raydiumPoolAddress: 'RaydiumEXCELPool1111111111111111111111111',
              });
            }}
            className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
              curveData.mint === 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3'
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow'
                : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
            }`}
          >
            <span>$EXCEL</span>
            <span className="text-[10px] text-[#64748b]">55.2 / 86 SOL</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setCurveData({
                tokenSymbol: '$BASH',
                tokenName: 'BASH Autonomous Terminal',
                mint: '7cnu3w5SbTxCrYTPavBJ7dib4Bdnf6mN5AG98xzDpump',
                currentPriceSol: 0.000025,
                currentPriceUsd: 0.0037125,
                change24hPct: 890.5,
                volumeSol24h: 3420.0,
                marketCapUsd: 3712500,
                targetThresholdSol: 86.0,
                currentCollectedSol: 2500.0,
                virtualSolReserves: 30.0,
                virtualTokenReserves: 1_073_000_000,
                totalSupply: 1_000_000_000,
                claimableCreatorSol: 12.5,
                lpStatus: 'Graduated · 90% SOL Pool Active',
                isGraduated: true,
                raydiumPoolAddress: 'RayB4sh90SoLLiquidityPool7cnu3w5SbTxCrYTPavBJ',
              });
            }}
            className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
              curveData.mint === '7cnu3w5SbTxCrYTPavBJ7dib4Bdnf6mN5AG98xzDpump'
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow ring-1 ring-emerald-500'
                : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-emerald-400" />
            <span>$BASH (7cnu3w5...pump)</span>
            <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-1 rounded">2,500 SOL · 90% Pool</span>
          </button>
        </div>

        {curveData.mint === '7cnu3w5SbTxCrYTPavBJ7dib4Bdnf6mN5AG98xzDpump' && (
          <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Deep 90% SOL Pool: RayB4sh90SoLLiquidityPool7cnu3w5SbTxCrYTPavBJ</span>
          </div>
        )}
      </div>

      {/* 2. Banner: Live Ticker: $EXCEL / SOL +420.69% | Volume: 1,420 SOL | MCap: $69,420 */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0d1527] via-[#101c36] to-[#0d1527] border border-[#233355] flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <span className="text-sm font-mono font-black text-cyan-300">Live Ticker:</span>
            <div className="px-2.5 py-1 rounded-lg bg-[#18233e] border border-[#26375c] flex items-center gap-1.5">
              <span className="text-base font-black text-white">${curveData.tokenSymbol} / SOL</span>
              <span className="text-xs font-mono font-bold text-emerald-400 flex items-center">
                <ArrowUpRight className="w-3.5 h-3.5" />
                +{curveData.change24hPct}%
              </span>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-6 text-xs font-mono text-[#94a3b8]">
            <div className="flex items-center gap-1.5">
              <span>Volume:</span>
              <strong className="text-white font-bold">{curveData.volumeSol24h.toLocaleString()} SOL</strong>
            </div>
            <div className="flex items-center gap-1.5">
              <span>MCap:</span>
              <strong className="text-white font-bold">${curveData.marketCapUsd.toLocaleString()}</strong>
            </div>
            <div className="flex items-center gap-1.5">
              <span>Price:</span>
              <strong className="text-cyan-300">{curveData.currentPriceSol.toFixed(8)} SOL</strong>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase bg-purple-500/10 text-purple-300 border border-purple-500/30 flex items-center gap-1">
            <Lock className="w-3 h-3 text-purple-400" />
            Raydium CPMM Target
          </span>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            Fair Launch 0-Pre-Mint
          </span>
        </div>
      </div>

      {/* 3. Main Split Grid: Left (Chart + Migration) | Right (Trade Terminal + Pool Management) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): LIVE BONDING CURVE CHART + MIGRATION PROGRESS */}
        <div className="lg:col-span-7 space-y-6">
          {/* LIVE BONDING CURVE CHART */}
          <div className="p-5 rounded-3xl bg-[#090e1c] border border-[#1d2946] shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#17233d]">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-mono font-extrabold uppercase tracking-wider text-white">
                  LIVE BONDING CURVE CHART (TradingView / Canvas Engine)
                </h3>
              </div>
              <div className="flex items-center gap-2 text-[11px] font-mono text-[#94a3b8]">
                <span>P = m · S^k + c</span>
                <span className="px-2 py-0.5 rounded bg-[#131d33] text-cyan-300 font-bold">1s Ticks</span>
              </div>
            </div>

            {/* Canvas Container */}
            <div className="relative w-full h-72 sm:h-80 rounded-2xl bg-[#050811] overflow-hidden border border-[#141e33] flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={680}
                height={320}
                className="w-full h-full object-contain block"
              />
              <div className="absolute top-3 left-3 px-3 py-1 rounded-lg bg-[#0c1221]/80 backdrop-blur-md border border-[#202d4a] text-[11px] font-mono flex items-center gap-3">
                <span className="text-[#94a3b8]">Virtual Reserves:</span>
                <span className="text-cyan-300 font-bold">{curveData.virtualSolReserves} SOL</span>
                <span className="text-[#64748b]">|</span>
                <span className="text-purple-300 font-bold">1,073M {curveData.tokenSymbol}</span>
              </div>
            </div>
          </div>

          {/* MIGRATION PROGRESS TO RAYDIUM */}
          <div className="p-5 rounded-3xl bg-[#090e1c] border border-[#1d2946] shadow-xl space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <h4 className="text-xs font-mono font-extrabold uppercase tracking-wider text-white">
                  Migration Progress to Raydium
                </h4>
              </div>
              <div className="text-xs font-mono font-bold text-purple-300">
                [{graduationPct.toFixed(1)}%]
              </div>
            </div>

            {/* Visual Bar matching [||||||||||||||.........] */}
            <div className="space-y-1.5">
              <div className="w-full h-4 rounded-full bg-[#050811] p-0.5 border border-[#1e2a44] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-emerald-400 to-purple-500 transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.max(4, graduationPct))}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-xs font-mono">
                <div className="text-[#94a3b8]">
                  Target: <strong className="text-purple-300">{curveData.targetThresholdSol} SOL</strong> / Current:{' '}
                  <strong className="text-emerald-400">{curveData.currentCollectedSol.toFixed(1)} SOL</strong>
                </div>
                <div className="text-amber-400 font-bold text-[11px]">
                  {(curveData.targetThresholdSol - curveData.currentCollectedSol).toFixed(1)} SOL to Raydium Pool Launch
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0d1425] border border-[#1f2d4d] text-[11px] font-mono text-[#94a3b8] flex items-center justify-between">
              <span>Automatic Pool Graduation:</span>
              <span className="text-cyan-300 font-bold">
                Locks 86 SOL + Burn LP Tokens on Raydium AMM upon 100%
              </span>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): TRADE TERMINAL + POOL MANAGEMENT PANEL */}
        <div className="lg:col-span-5 space-y-6">
          {/* TRADE TERMINAL */}
          <div className="p-5 rounded-3xl bg-[#090e1c] border border-[#1d2946] shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#17233d]">
              <div className="flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-mono font-extrabold uppercase tracking-wider text-white">
                  Trade Terminal
                </h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                Bonding Curve Instant Execution
              </span>
            </div>

            {/* BUY / SELL Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-[#050811] border border-[#17233a]">
              <button
                onClick={() => setTradeMode('BUY')}
                className={`py-2 rounded-lg font-mono text-xs font-extrabold transition-all flex items-center justify-center gap-1.5 ${
                  tradeMode === 'BUY'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-black shadow-md'
                    : 'text-[#94a3b8] hover:text-white'
                }`}
              >
                <ArrowDownRight className="w-3.5 h-3.5" />
                <span>BUY</span>
              </button>
              <button
                onClick={() => setTradeMode('SELL')}
                className={`py-2 rounded-lg font-mono text-xs font-extrabold transition-all flex items-center justify-center gap-1.5 ${
                  tradeMode === 'SELL'
                    ? 'bg-gradient-to-r from-rose-500 to-red-600 text-white shadow-md'
                    : 'text-[#94a3b8] hover:text-white'
                }`}
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>SELL</span>
              </button>
            </div>

            {/* Amount Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
                <span>Amount:</span>
                <div className="flex items-center gap-1">
                  {['0.1', '0.5', '1.0', '5.0'].map((preset) => (
                    <button
                      key={preset}
                      onClick={() => setSolAmountInput(preset)}
                      className="px-2 py-0.5 rounded text-[10px] bg-[#141e33] hover:bg-[#1d2b48] text-[#94a3b8] hover:text-white transition-all"
                    >
                      {preset} SOL
                    </button>
                  ))}
                  <button
                    onClick={() => setSolAmountInput(walletSolBalance.toString())}
                    className="px-2 py-0.5 rounded text-[10px] bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 font-bold"
                  >
                    MAX
                  </button>
                </div>
              </div>

              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  min="0.001"
                  value={solAmountInput}
                  onChange={(e) => setSolAmountInput(e.target.value)}
                  placeholder="1.0"
                  className="w-full py-3 pl-4 pr-16 rounded-xl bg-[#050811] border border-[#212f4d] text-white font-mono text-base font-bold focus:outline-none focus:border-cyan-500 transition-all"
                />
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-cyan-400">
                  {tradeMode === 'BUY' ? 'SOL' : curveData.tokenSymbol}
                </div>
              </div>
            </div>

            {/* Estimated Output */}
            <div className="p-3 rounded-xl bg-[#050811] border border-[#17233a] space-y-1.5 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-[#64748b]">Estimated Output:</span>
                <span className="text-emerald-400 font-extrabold">
                  {tradeMode === 'BUY'
                    ? `${estimatedTokenOutput.toLocaleString(undefined, { maximumFractionDigits: 0 })} $${curveData.tokenSymbol}`
                    : `${(parsedSolAmount * 0.995).toFixed(4)} SOL`}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#64748b]">
                <span>Creator Fee Split (0.5%):</span>
                <span>{(parsedSolAmount * 0.005).toFixed(4)} SOL</span>
              </div>
            </div>

            {/* Slippage Selector: [ 1% ] [ 5% ] [ Auto ] */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono text-[#94a3b8] block">Slippage Tolerance:</label>
              <div className="grid grid-cols-3 gap-2">
                {['1%', '5%', 'Auto'].map((slip) => (
                  <button
                    key={slip}
                    onClick={() => setSlippage(slip)}
                    className={`py-1.5 rounded-lg text-xs font-mono font-bold transition-all border ${
                      slippage === slip
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                        : 'bg-[#050811] text-[#94a3b8] border-[#1b2742] hover:text-white'
                    }`}
                  >
                    {slip}
                  </button>
                ))}
              </div>
            </div>

            {/* SWAP / EXECUTE PUMP Button */}
            <button
              onClick={handleExecuteTrade}
              disabled={swapLoading || curveData.isGraduated}
              className={`w-full py-3.5 rounded-xl font-mono text-sm font-extrabold transition-all flex items-center justify-center gap-2 shadow-lg ${
                curveData.isGraduated
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : swapLoading
                  ? 'bg-emerald-600/60 text-white cursor-wait'
                  : tradeMode === 'BUY'
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:opacity-95 text-black shadow-emerald-950/60 hover:scale-[1.01]'
                  : 'bg-gradient-to-r from-rose-500 via-red-500 to-amber-500 hover:opacity-95 text-white shadow-rose-950/60 hover:scale-[1.01]'
              }`}
            >
              {swapLoading ? (
                <>
                  <Zap className="w-4 h-4 animate-spin text-white" />
                  <span>Processing Swap with Phantom / Solflare...</span>
                </>
              ) : (
                <>
                  <Flame className="w-4 h-4" />
                  <span>SWAP / EXECUTE PUMP</span>
                </>
              )}
            </button>

            {/* Status Notice */}
            {statusNotification && (
              <div className="p-3 rounded-xl bg-[#050811] border border-cyan-500/30 text-xs font-mono text-cyan-300 space-y-1">
                <p>{statusNotification}</p>
              </div>
            )}
          </div>

          {/* POOL MANAGEMENT PANEL */}
          <div className="p-5 rounded-3xl bg-[#090e1c] border border-[#1d2946] shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#17233d]">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-mono font-extrabold uppercase tracking-wider text-white">
                  Pool Management Panel
                </h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/30">
                Security & Fees
              </span>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#050811] border border-[#17233a]">
                <span className="text-[#94a3b8]">- LP Status:</span>
                <span className="text-emerald-400 font-extrabold flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  {curveData.lpStatus}
                </span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#050811] border border-[#17233a]">
                <span className="text-[#94a3b8]">- Creator Rewards Claimable:</span>
                <span className="text-amber-400 font-extrabold">{curveData.claimableCreatorSol.toFixed(4)} SOL</span>
              </div>

              {claimedTotalSol > 0 && (
                <div className="flex items-center justify-between px-2 text-[11px] text-[#64748b]">
                  <span>Total Rewards Claimed:</span>
                  <span className="text-emerald-400">{claimedTotalSol.toFixed(4)} SOL</span>
                </div>
              )}

              {/* Claim Rewards Button */}
              <button
                onClick={handleClaimCreatorRewards}
                disabled={claimLoading || curveData.claimableCreatorSol <= 0}
                className={`w-full py-2.5 rounded-xl font-mono text-xs font-extrabold transition-all flex items-center justify-center gap-2 ${
                  curveData.claimableCreatorSol <= 0
                    ? 'bg-[#121a2c] text-[#64748b] cursor-not-allowed'
                    : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-90 text-black shadow-md shadow-amber-950/40'
                }`}
              >
                {claimLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Claiming Rewards...</span>
                  </>
                ) : (
                  <>
                    <Gift className="w-3.5 h-3.5" />
                    <span>Claim 0.5% Creator Fee Rewards</span>
                  </>
                )}
              </button>
            </div>

            {/* Anti-Bot & Security Info */}
            <div className="p-3 rounded-xl bg-[#050811] border border-[#1b263e] space-y-1.5 text-[11px] font-mono text-[#94a3b8]">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                <span>Fair Launch & Anti-Snipe Protocols</span>
              </div>
              <p className="leading-relaxed text-[#64748b]">
                • Zero pre-mint allocation for deployer.
                <br />
                • LP tokens permanently burned upon reaching the 86.0 SOL graduation cap.
                <br />
                • Mint and freeze authorities revoked on-chain.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Bottom Section: Real-Time Transaction Feed / Holder Distribution / Engine Parameters */}
      <div className="p-5 rounded-3xl bg-[#090e1c] border border-[#1d2946] shadow-xl space-y-4">
        {/* Tab Selection */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#17233d]">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setBottomTab('trades')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
                bottomTab === 'trades'
                  ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black'
                  : 'bg-[#101729] text-[#94a3b8] hover:text-white'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Real-Time Transaction Feed</span>
            </button>
            <button
              onClick={() => setBottomTab('holders')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
                bottomTab === 'holders'
                  ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black'
                  : 'bg-[#101729] text-[#94a3b8] hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Holder Distribution Table</span>
            </button>
            <button
              onClick={() => setBottomTab('engine_json')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
                bottomTab === 'engine_json'
                  ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black'
                  : 'bg-[#101729] text-[#94a3b8] hover:text-white'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Engine Parameters (JSON)</span>
            </button>
            <button
              onClick={() => setBottomTab('anchor_code')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
                bottomTab === 'anchor_code'
                  ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black'
                  : 'bg-[#101729] text-[#94a3b8] hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Anchor Smart Contract (Rust)</span>
            </button>
          </div>

          <span className="text-[11px] font-mono text-[#64748b]">
            Total Supply: 1,000,000,000 {curveData.tokenSymbol} (6 Decimals)
          </span>
        </div>

        {/* Tab Content 1: Real-Time Transaction Feed */}
        {bottomTab === 'trades' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#151f33] text-[#64748b]">
                  <th className="py-2.5 px-3">Wallet</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Tokens (${curveData.tokenSymbol})</th>
                  <th className="py-2.5 px-3">SOL Amount</th>
                  <th className="py-2.5 px-3">Time</th>
                  <th className="py-2.5 px-3 text-right">Tx</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131c30]">
                {transactions.map((tx, idx) => (
                  <tr key={`${tx.id || 'tx'}-${idx}`} className="hover:bg-[#0d1424] transition-colors">
                    <td className="py-3 px-3 font-bold text-white flex items-center gap-1.5">
                      <span className="text-cyan-400">{tx.wallet}</span>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                          tx.action === 'BUY'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {tx.action}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-white font-bold">
                      {tx.action === 'BUY' ? '+' : '-'}{tx.tokenAmount.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-cyan-300 font-semibold">{tx.solAmount} SOL</td>
                    <td className="py-3 px-3 text-[#64748b]">
                      {Math.max(1, Math.round((Date.now() - tx.timestamp) / 1000))} secs ago
                    </td>
                    <td className="py-3 px-3 text-right">
                      <a
                        href={`https://solscan.io/tx/${tx.txHash}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 underline inline-flex items-center gap-1"
                      >
                        <span>{tx.txHash}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab Content 2: Holder Distribution Table */}
        {bottomTab === 'holders' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#151f33] text-[#64748b]">
                  <th className="py-2.5 px-3">Rank</th>
                  <th className="py-2.5 px-3">Address</th>
                  <th className="py-2.5 px-3">Balance</th>
                  <th className="py-2.5 px-3">Percentage</th>
                  <th className="py-2.5 px-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131c30]">
                {holders.map((h) => (
                  <tr key={h.rank} className="hover:bg-[#0d1424] transition-colors">
                    <td className="py-3 px-3 text-[#94a3b8] font-bold">#{h.rank}</td>
                    <td className="py-3 px-3 font-bold text-white flex items-center gap-1.5">
                      <span className="text-cyan-300">{h.wallet}</span>
                    </td>
                    <td className="py-3 px-3 text-white font-bold">{h.balance.toLocaleString()}</td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 rounded-full bg-[#131c31] overflow-hidden">
                          <div
                            className="h-full bg-cyan-400 rounded-full"
                            style={{ width: `${h.pct}%` }}
                          />
                        </div>
                        <span className="text-emerald-400 font-extrabold">{h.pct}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {h.isVault ? (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-purple-500/10 text-purple-300 border border-purple-500/30">
                          BONDING VAULT
                        </span>
                      ) : h.isCreator ? (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                          DEPLOYER
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-[#94a3b8]">
                          TRADER
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab Content 3: Smart Contract / Engine Parameters (SPL Token Design JSON) */}
        {bottomTab === 'engine_json' && (
          <div className="rounded-2xl bg-[#050811] border border-[#18233a] p-4 text-xs font-mono text-[#cbd5e1] overflow-x-auto leading-relaxed">
            <pre>
              <code>{JSON.stringify(engineJsonSpec, null, 2)}</code>
            </pre>
          </div>
        )}

        {/* Tab Content 4: Production Solana Anchor Smart Contract */}
        {bottomTab === 'anchor_code' && (
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-[#060a14] rounded-xl border border-[#1c2945]">
              <div className="text-xs font-mono text-[#94a3b8]">
                <strong className="text-white">Directory:</strong> programs/meme-pump-engine/src/
                <span className="text-emerald-400 ml-2 font-bold">● Production-Ready Anchor 0.30 Framework</span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href="https://github.com/coral-xyz/anchor"
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 rounded bg-[#10182b] hover:bg-[#1a2745] text-cyan-300 text-[11px] font-mono flex items-center gap-1"
                >
                  <span>Anchor Docs</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
            <div className="rounded-2xl bg-[#050811] border border-[#18233a] p-4 text-xs font-mono text-[#cbd5e1] overflow-x-auto leading-relaxed max-h-[500px]">
              <pre>
                <code>{`// Solana Anchor Smart Contract (programs/meme-pump-engine/src/lib.rs)
use anchor_lang::prelude::*;

pub mod constants;
pub mod errors;
pub mod events;
pub mod instructions;
pub mod state;

use instructions::*;

declare_id!("PumpEngine11111111111111111111111111111111");

#[program]
pub mod meme_pump_engine {
    use super::*;

    pub fn initialize_global(ctx: Context<InitializeGlobal>, fee_bps: u16) -> Result<()> {
        instructions::initialize_global::handler(ctx, fee_bps)
    }

    pub fn initialize_curve(
        ctx: Context<InitializeCurve>,
        virtual_sol_reserves: u64,
        virtual_token_reserves: u64,
        total_supply: u64,
    ) -> Result<()> {
        instructions::initialize_curve::handler(ctx, virtual_sol_reserves, virtual_token_reserves, total_supply)
    }

    pub fn buy(ctx: Context<Buy>, sol_amount: u64, min_tokens_out: u64) -> Result<()> {
        instructions::buy::handler(ctx, sol_amount, min_tokens_out)
    }

    pub fn sell(ctx: Context<Sell>, token_amount: u64, min_sol_out: u64) -> Result<()> {
        instructions::sell::handler(ctx, token_amount, min_sol_out)
    }

    pub fn migrate_to_raydium(
        ctx: Context<MigrateToRaydium>,
        init_amount_0: u64,
        init_amount_1: u64,
        open_time: u64,
    ) -> Result<()> {
        instructions::migrate::handler(ctx, init_amount_0, init_amount_1, open_time)
    }
}`}</code>
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
