import React, { useState } from 'react';
import * as L from '../../lib/launchpad/client';

/** Shared types, formatting and small UI pieces for the Launchpad screens. */

export interface LaunchItem {
  index: string;
  mint: string;
  creator: string;
  createdAt: string;
  name: string;
  symbol: string;
  uri: string;
  image: string | null;
  description: string | null;
  curve: Record<string, any> | null;
}

export interface LpState {
  ok: boolean;
  error?: string;
  cluster: string;
  programId: string;
  fetchedAt: number;
  status: 'NOT_DEPLOYED' | 'NOT_INITIALIZED' | 'LIVE';
  upgradeAuthority: string | null;
  global: Record<string, any> | null;
  launches: LaunchItem[];
  totals: Record<string, any> | null;
}

// ---------- parsing & formatting ----------

export const B = (v: unknown) => BigInt((v as any) ?? 0);

export function toCurve(c: Record<string, any>): L.CurveAccount {
  return {
    mint: c.mint,
    creator: c.creator,
    launchIndex: B(c.launchIndex),
    createdAt: B(c.createdAt),
    virtualSolReserves: B(c.virtualSolReserves),
    virtualTokenReserves: B(c.virtualTokenReserves),
    realSolReserves: B(c.realSolReserves),
    realTokenReserves: B(c.realTokenReserves),
    initialRealTokenReserves: B(c.initialRealTokenReserves),
    tokenTotalSupply: B(c.tokenTotalSupply),
    volumeLamports: B(c.volumeLamports),
    feesLamports: B(c.feesLamports),
    creatorFeesLamports: B(c.creatorFeesLamports),
    creatorFeesClaimed: B(c.creatorFeesClaimed),
    tradeCount: B(c.tradeCount),
    complete: Boolean(c.complete),
    migrated: Boolean(c.migrated),
    migrationSol: B(c.migrationSol),
    migrationTokens: B(c.migrationTokens),
    migrationPool: c.migrationPool ?? null,
    bump: Number(c.bump),
  };
}

export const short = (a?: string | null) => (a ? `${a.slice(0, 4)}…${a.slice(-4)}` : '—');

export function fmtSol(lamports: unknown, digits = 4) {
  if (lamports === null || lamports === undefined) return '—';
  const n = Number(B(lamports)) / 1e9;
  if (n === 0) return '0 SOL';
  if (Math.abs(n) < 0.0001) return '<0.0001 SOL';
  return `${n.toLocaleString(undefined, { maximumFractionDigits: digits })} SOL`;
}

export function fmtTokens(base: unknown) {
  const n = Number(B(base)) / 10 ** L.TOKEN_DECIMALS;
  if (n >= 1e9) return `${(n / 1e9).toLocaleString(undefined, { maximumFractionDigits: 2 })}B`;
  if (n >= 1e6) return `${(n / 1e6).toLocaleString(undefined, { maximumFractionDigits: 2 })}M`;
  return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

export function fmtPrice(sol: number) {
  if (!Number.isFinite(sol) || sol <= 0) return '—';
  return sol < 0.000001 ? `${sol.toExponential(3)} SOL` : `${sol.toLocaleString(undefined, { maximumSignificantDigits: 4 })} SOL`;
}

/** "1.25" -> lamports / base units, or null if not a valid positive amount. */
export function parseUnits(s: string, decimals: number): bigint | null {
  const t = s.trim();
  if (!/^\d*\.?\d*$/.test(t) || t === '' || t === '.') return null;
  const [whole, frac = ''] = t.split('.');
  if (frac.length > decimals) return null;
  const v = BigInt(whole || '0') * 10n ** BigInt(decimals) + BigInt((frac + '0'.repeat(decimals)).slice(0, decimals) || '0');
  return v > 0n ? v : null;
}

export const utf8Len = (s: string) => new TextEncoder().encode(s).length;

// ---------- small UI pieces ----------

export const Card: React.FC<{ className?: string; children: React.ReactNode }> = ({ className = '', children }) => (
  <div className={`rounded-xl border border-[#1b2436] bg-[#090d16] p-5 shadow-xl ${className}`}>{children}</div>
);

export const Stat: React.FC<{ label: string; value: React.ReactNode; tone?: string; sub?: string }> = ({ label, value, tone = 'text-white', sub }) => (
  <div className="p-3.5 rounded-xl bg-[#060911] border border-[#162032] min-w-0">
    <div className="text-[10px] uppercase text-[#6b7c96] font-mono">{label}</div>
    <div className={`text-sm font-bold font-mono mt-1 truncate ${tone}`}>{value}</div>
    {sub && <div className="text-[10px] text-[#6b7c96] font-mono mt-0.5 truncate">{sub}</div>}
  </div>
);

export const TokenLogo: React.FC<{ src?: string | null; symbol: string; size?: string }> = ({ src, symbol, size = 'w-10 h-10' }) => {
  const [broken, setBroken] = useState(false);
  if (!src || broken) {
    return (
      <div className={`${size} rounded-full bg-[#1b2436] border border-[#232c45] flex items-center justify-center text-xs font-bold text-[#8a93a8] shrink-0`}>
        {(symbol || '?').slice(0, 2).toUpperCase()}
      </div>
    );
  }
  return <img src={src} alt={symbol} onError={() => setBroken(true)} className={`${size} rounded-full object-cover border border-[#232c45] shrink-0`} />;
};

export const inputCls =
  'w-full bg-[#060911] border border-[#1b263d] rounded-xl p-2.5 text-white text-sm font-mono focus:outline-none focus:border-cyan-400';
export const btnPrimary =
  'px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#0284c7] to-[#0369a1] hover:from-[#38bdf8] hover:to-[#0284c7] text-white text-xs font-mono font-bold flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed';
export const btnGhost =
  'px-3 py-2 rounded-lg bg-[#0e1422] border border-[#1b263d] text-[#a3b0c6] hover:text-white text-xs font-mono font-bold flex items-center gap-1.5 disabled:opacity-40';

