import React, { useEffect, useState } from 'react';
import { PublicKey } from '@solana/web3.js';
import { AlertCircle, Coins, RefreshCw, ShieldAlert, Sparkles } from 'lucide-react';
import * as L from '../../lib/launchpad/client';
import { explorerUrl, signAndRelay } from '../../lib/launchpad/wallet';
import { Card, Stat, TokenLogo, btnGhost, btnPrimary, fmtSol, short, toCurve } from './ui';
import type { LpState } from './ui';

/**
 * Discover, Creator earnings, Growth and the per-token risk report.
 * All numbers come from /api/launchpad/* which reads the chain; AI text is labelled with the model
 * that wrote it, and is simply absent when no model is configured.
 */

function useJson<T>(url: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const load = () => {
    if (!url) return;
    setLoading(true);
    fetch(url)
      .then((r) => r.json())
      .then((d) => {
        if (d?.ok === false) throw new Error(d.error || 'Request failed');
        setData(d);
        setError(null);
      })
      .catch((e) => setError(e?.message || 'Request failed'))
      .finally(() => setLoading(false));
  };
  useEffect(load, [url, ...deps]);
  return { data, error, loading, reload: load };
}

const AiBlock: React.FC<{ model: string | null; text: string | null }> = ({ model, text }) =>
  text ? (
    <div className="p-3 rounded-xl border border-cyan-500/20 bg-cyan-500/5 text-xs text-[#c9d4e6] leading-relaxed whitespace-pre-wrap">
      <div className="text-[10px] font-mono text-cyan-300 mb-1 flex items-center gap-1">
        <Sparkles className="w-3 h-3" /> AI summary · {model}
      </div>
      {text}
    </div>
  ) : (
    <div className="text-[11px] font-mono text-[#6b7c96]">AI summary off (set GEMINI_API_KEY on the server). Rule-based results shown.</div>
  );

// ------------------------------------------------------------------ Discover

type Row = {
  mint: string; name: string; symbol: string; image: string | null; ageHours: number; progressPct: number;
  volumeSol: number; trades: number; recentVolumeSol: number; recentTrades: number; recentWindow: string;
};

export const DiscoverTab: React.FC<{ onOpen: (mint: string) => void }> = ({ onOpen }) => {
  const { data, error, loading, reload } = useJson<any>('/api/launchpad/discovery');
  const [list, setList] = useState<'trending' | 'nearGraduation' | 'newest' | 'graduated'>('trending');
  const rows: Row[] = data?.lists?.[list] ?? [];
  const labels = { trending: 'Trending', nearGraduation: 'Near graduation', newest: 'New', graduated: 'Graduated' } as const;
  return (
    <Card className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-2">
          {(Object.keys(labels) as (keyof typeof labels)[]).map((k) => (
            <button key={k} type="button" onClick={() => setList(k)} className={`${btnGhost} ${list === k ? '!text-white !border-cyan-400' : ''}`}>
              {labels[k]}
            </button>
          ))}
        </div>
        <button type="button" className={btnGhost} onClick={reload}>
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>
      {error && <div className="text-xs font-mono text-rose-300">{error}</div>}
      {rows.length === 0 && !loading && <div className="text-xs font-mono text-[#8a93a8]">Nothing in this list yet. It fills from real trades.</div>}
      <div className="space-y-2">
        {rows.map((r, i) => (
          <button key={r.mint} type="button" onClick={() => onOpen(r.mint)} className="w-full text-left p-3 rounded-xl border border-[#1b2436] bg-[#060911] hover:border-[#2a3a55] flex items-center gap-3">
            <span className="w-6 text-xs font-mono text-[#6b7c96]">{i + 1}</span>
            <TokenLogo src={r.image} symbol={r.symbol} size="w-9 h-9" />
            <div className="min-w-0 flex-1">
              <div className="text-sm font-bold text-white truncate">
                {r.name} <span className="text-[11px] font-mono text-cyan-300">${r.symbol}</span>
              </div>
              <div className="text-[11px] font-mono text-[#6b7c96]">
                {r.recentVolumeSol.toFixed(3)} SOL · {r.recentTrades} trades ({r.recentWindow}) · {r.progressPct}% sold · {r.ageHours < 48 ? `${r.ageHours.toFixed(1)}h old` : `${(r.ageHours / 24).toFixed(1)}d old`}
              </div>
            </div>
          </button>
        ))}
      </div>
      {data?.method && <p className="text-[10px] font-mono text-[#6b7c96]">{data.method}</p>}
    </Card>
  );
};

// ------------------------------------------------------------------ Risk report (per token)

export const TokenRiskReport: React.FC<{ mint: string; refreshKey: number }> = ({ mint }) => {
  const [open, setOpen] = useState(false);
  const { data, error, loading, reload } = useJson<any>(open ? `/api/launchpad/report/${mint}` : null);
  if (!open) {
    return (
      <button type="button" className={btnGhost} onClick={() => setOpen(true)}>
        <ShieldAlert className="w-3.5 h-3.5" /> Holder &amp; risk check
      </button>
    );
  }
  const tone = { info: 'text-[#8a93a8]', warn: 'text-amber-300', high: 'text-rose-300' } as const;
  return (
    <div className="p-3 rounded-xl border border-[#1b2436] bg-[#060911] space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-xs font-mono font-bold text-white flex items-center gap-1.5"><ShieldAlert className="w-3.5 h-3.5" /> Holder &amp; risk check</div>
        <button type="button" className={btnGhost} onClick={reload}><RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} /></button>
      </div>
      {error && <div className="text-xs font-mono text-rose-300">{error}</div>}
      {data && (
        <>
          <ul className="space-y-1">
            {data.flags.map((f: any) => (
              <li key={f.text} className={`text-[11px] font-mono ${tone[f.level as keyof typeof tone]}`}>• {f.text}</li>
            ))}
          </ul>
          {data.holdersError && <div className="text-[11px] font-mono text-amber-300">{data.holdersError}</div>}
          {data.topHolders?.length > 0 && (
            <div className="text-[11px] font-mono text-[#8a93a8]">
              Top holders: {data.topHolders.slice(0, 5).map((h: any) => `${h.pctOfBought}%${h.isCreator ? ' (creator)' : ''}`).join(' · ')}
            </div>
          )}
          <AiBlock model={data.model} text={data.summary} />
        </>
      )}
    </div>
  );
};

// ------------------------------------------------------------------ Creator earnings

export const CreatorsTab: React.FC<{
  state: LpState;
  wallet: PublicKey | null;
  busy: string | null;
  ensureWallet: () => Promise<PublicKey>;
  run: (label: string, fn: () => Promise<string>) => Promise<void>;
}> = ({ state, wallet, busy, ensureWallet, run }) => {
  const me = wallet?.toBase58();
  const mine = state.launches.filter((l) => l.creator === me && l.curve);
  const I = L.launchpadInstructions(state.programId);
  const unclaimed = mine.reduce((n, l) => n + L.unclaimedCreatorFees(toCurve(l.curve!)), 0n);
  const lifetime = mine.reduce((n, l) => n + toCurve(l.curve!).creatorFeesLamports, 0n);
  const g = state.global!;
  const claimable = mine.filter((l) => L.unclaimedCreatorFees(toCurve(l.curve!)) > 0n);

  return (
    <div className="space-y-4">
      <Card className="space-y-3">
        <div className="text-white font-bold text-sm">Creator earnings</div>
        <p className="text-xs font-mono text-[#8a93a8]">
          Creators earn {Number(g.creatorFeeShareBps ?? 0) / 100}% of every trading fee on their token, paid by the program and held in the
          token's curve account until claimed. Only the creator's wallet can claim.
        </p>
        {!me ? (
          <button type="button" className={btnPrimary} onClick={() => ensureWallet().catch(() => {})}>Connect wallet</button>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Stat label="Your tokens" value={String(mine.length)} />
            <Stat label="Unclaimed" value={fmtSol(unclaimed, 6)} tone="text-emerald-400" />
            <Stat label="Lifetime earned" value={fmtSol(lifetime, 6)} />
          </div>
        )}
        {claimable.length > 1 && (
          <button
            type="button"
            className={btnPrimary}
            disabled={!!busy}
            onClick={() =>
              run(`Claim from ${Math.min(claimable.length, 8)} tokens`, async () => {
                const w = await ensureWallet();
                // Up to 8 claims per transaction keeps it well under the size limit.
                return signAndRelay({ feePayer: w, instructions: claimable.slice(0, 8).map((l) => I.claimCreatorFees(w, l.mint)), computeUnits: 200_000 });
              })
            }
          >
            <Coins className="w-4 h-4" /> Claim all{claimable.length > 8 ? ' (first 8)' : ''}
          </button>
        )}
      </Card>
      {me && mine.length === 0 && <Card><div className="text-xs font-mono text-[#8a93a8]">This wallet hasn't launched a token here yet.</div></Card>}
      {mine.map((l) => {
        const c = toCurve(l.curve!);
        const u = L.unclaimedCreatorFees(c);
        return (
          <Card key={l.mint} className="flex flex-wrap items-center gap-3">
            <TokenLogo src={l.image} symbol={l.symbol} />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">{l.name} <span className="text-[11px] font-mono text-cyan-300">${l.symbol}</span></div>
              <div className="text-[11px] font-mono text-[#6b7c96]">
                {fmtSol(c.volumeLamports, 3)} volume · {String(c.tradeCount)} trades · earned {fmtSol(c.creatorFeesLamports, 6)} ·{' '}
                <a className="hover:text-white" href={explorerUrl('account', L.launchpadPdas(state.programId).curve(l.mint).toBase58(), state.cluster)} target="_blank" rel="noreferrer">curve {short(l.mint)}</a>
              </div>
            </div>
            <button
              type="button"
              className={btnPrimary}
              disabled={!!busy || u <= 0n}
              onClick={() =>
                run(`Claim ${l.symbol} creator fees`, async () => {
                  const w = await ensureWallet();
                  return signAndRelay({ feePayer: w, instructions: [I.claimCreatorFees(w, l.mint)], computeUnits: 40_000 });
                })
              }
            >
              Claim {fmtSol(u, 6)}
            </button>
          </Card>
        );
      })}
    </div>
  );
};

// ------------------------------------------------------------------ Growth

const Spark: React.FC<{ values: number[]; color: string }> = ({ values, color }) => {
  if (values.length < 2) return <div className="h-12 text-[10px] font-mono text-[#6b7c96] flex items-center">collecting history…</div>;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const pts = values.map((v, i) => `${(i / (values.length - 1)) * 100},${40 - ((v - min) / span) * 36 - 2}`).join(' ');
  return (
    <svg viewBox="0 0 100 40" preserveAspectRatio="none" className="w-full h-12">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
    </svg>
  );
};

export const GrowthTab: React.FC = () => {
  const { data, error, loading, reload } = useJson<any>('/api/launchpad/growth');
  const series: any[] = data?.series ?? [];
  const sol = (n: number | undefined) => (n == null ? '—' : `${n.toFixed(4)} SOL`);
  const pr = { now: 'text-rose-300', soon: 'text-amber-300', idea: 'text-cyan-300' } as const;
  return (
    <div className="space-y-4">
      <Card className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-white font-bold text-sm">Growth</div>
          <button type="button" className={btnGhost} onClick={reload}>
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
        </div>
        <p className="text-xs font-mono text-[#8a93a8]">
          The server snapshots on-chain totals every 10 minutes and keeps 90 days. Changes below are real differences between snapshots.
          {data?.firstSnapshotAt ? ` History since ${new Date(data.firstSnapshotAt).toLocaleString()} (${data.snapshots} snapshots).` : ''}
        </p>
        {error && <div className="text-xs font-mono text-rose-300 flex gap-1"><AlertCircle className="w-4 h-4" />{error}</div>}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          <Stat label="Platform fees · 24h" value={sol(data?.last24h?.platformFeesSol)} tone="text-amber-300" sub={data?.last24h ? `${data.last24h.hours}h window` : 'needs 2+ snapshots'} />
          <Stat label="Creator fees · 24h" value={sol(data?.last24h?.creatorFeesSol)} tone="text-emerald-400" />
          <Stat label="Volume · 24h" value={sol(data?.last24h?.volumeSol)} />
          <Stat label="Launches · 7d" value={data?.last7d ? String(data.last7d.launches) : '—'} />
          <Stat label="Platform fees · 7d" value={sol(data?.last7d?.platformFeesSol)} tone="text-amber-300" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { label: 'Cumulative platform fees (SOL)', key: 'platformFeesSol', color: '#fbbf24' },
            { label: 'Cumulative volume (SOL)', key: 'volumeSol', color: '#22d3ee' },
            { label: 'Launches', key: 'launches', color: '#34d399' },
          ].map((s) => (
            <div key={s.key} className="p-3 rounded-xl bg-[#060911] border border-[#162032]">
              <div className="text-[10px] uppercase font-mono text-[#6b7c96]">{s.label}</div>
              <Spark values={series.map((x) => x[s.key])} color={s.color} />
            </div>
          ))}
        </div>
      </Card>
      <Card className="space-y-3">
        <div className="text-white font-bold text-sm">Next actions</div>
        {(data?.actions ?? []).length === 0 && <div className="text-xs font-mono text-[#8a93a8]">Nothing urgent.</div>}
        <ul className="space-y-1.5">
          {(data?.actions ?? []).map((a: any) => (
            <li key={a.text} className="text-xs font-mono text-[#c9d4e6]">
              <span className={`font-bold uppercase mr-2 ${pr[a.priority as keyof typeof pr]}`}>{a.priority}</span>
              {a.text}
            </li>
          ))}
        </ul>
        {data && data.status === 'LIVE' && <AiBlock model={data.model} text={data.narrative} />}
      </Card>
    </div>
  );
};
