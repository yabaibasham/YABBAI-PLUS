import React, { useState, useEffect } from 'react';
import {
  LayoutGrid,
  ShieldCheck,
  Search,
  Zap,
  TrendingUp,
  Cpu,
  History,
  Activity,
  Layers,
  ArrowUpRight,
  Flame,
  Bot,
  AlertTriangle,
  Play,
  RotateCw,
  Copy,
  ExternalLink,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Sparkles,
  DollarSign,
  Droplet,
  Wallet,
  ArrowRight,
  Percent,
  Brain,
} from 'lucide-react';
import { OPERATOR_IMGS } from './operatorAssets';
import { AITaskForceMatrixView } from './AITaskForceMatrixView';
import { HotWalletsNetworkView } from '../wallets/HotWalletsNetworkView';
import type {
  AgentDef,
  OpportunityItem,
  X402Product,
  X402Challenge,
  CapitalProposal,
  LearningRecord,
  EconomicTruth,
  LedgerEntry,
  SyndicateWallet,
} from '../../types';

export type OperatorTab =
  | 'command'
  | 'ai_taskforce'
  | 'truth'
  | 'opportunities'
  | 'x402'
  | 'compounding'
  | 'flywheel'
  | 'syndicate'
  | 'volumebot'
  | 'agents'
  | 'jarvis'
  | 'ledger';

interface OmegaOperatorViewProps {
  onNavigateToTools?: (tabKey: string) => void;
  walletSolBalance?: number;
  initialTab?: string;
}

export const OmegaOperatorView: React.FC<OmegaOperatorViewProps> = ({
  onNavigateToTools,
  walletSolBalance = 0.000944,
  initialTab,
}) => {
  const [activeTab, setActiveTab] = useState<OperatorTab>(
    (initialTab as OperatorTab) || 'command'
  );
  const [loading, setLoading] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'ok' | 'err' | 'info' } | null>(null);

  // Core State
  const [emergencyStop, setEmergencyStop] = useState<boolean>(false);
  const [autoFeed, setAutoFeed] = useState<boolean>(true);
  const [autopilotState, setAutopilotState] = useState<{ running: boolean; cycle: number; last: string }>({
    running: true,
    cycle: 1,
    last: 'System running on Solana Mainnet-Beta',
  });

  const [economicTruth, setEconomicTruth] = useState<EconomicTruth>({
    real: { gross: 0.048, cost: 0.004, profit: 0.044, events: 3 },
    estimate: { gross: 0.12, net: 0.098, events: 4 },
    simulation: { gross: 0.45, cost: 0.02, profit: 0.43, events: 12 },
  });

  const [flywheel, setFlywheel] = useState({
    reserveSol: 0.654,
    totalInjected: 8.92,
    totalInjectedUsd: 1320.16,
    tokensBurned: 248600000,
    injCount: 42,
    windowInjected: 0.18,
    windowStart: Date.now() - 15 * 60 * 1000,
    lastInjSol: 0.055,
    lastInjTime: Date.now() - 2 * 60 * 1000,
    paymentSol: 3.45,
    stageTapSol: 1.12,
  });

  const [token, setToken] = useState({
    symbol: 'OMEGA',
    name: 'Omega Alien',
    mint: 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i',
    priceSol: 0.000000742,
    priceUsd: 0.00007421,
    solPriceUsd: 148,
    marketCapUsd: 74210,
    bondingPct: 62.4,
    graduationSol: 85,
    virtualSol: 48.6,
    virtualTokens: 877383839,
    volume24h: 48250,
    change24h: 182.4,
    holders: 1337,
  });

  const [opportunities, setOpportunities] = useState<OpportunityItem[]>([]);
  const [agents, setAgents] = useState<AgentDef[]>([]);
  const [products, setProducts] = useState<X402Product[]>([]);
  const [proposals, setProposals] = useState<CapitalProposal[]>([]);
  const [learnings, setLearnings] = useState<LearningRecord[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [syndicate, setSyndicate] = useState<SyndicateWallet[]>([]);
  const [cycle, setCycle] = useState<any>({
    currentPhase: 'VOLUME_PUMP',
    cycleIteration: 28,
    totalProfitWithdrawnSol: 22.45,
    totalReinvestedSol: 15.72,
    lastHarvestSol: 1.45,
    lastRebuySol: 1.02,
  });

  // Filters & Inputs
  const [zeroCapOnly, setZeroCapOnly] = useState(false);
  const [agentSearch, setAgentSearch] = useState('');
  const [agentSquadFilter, setAgentSquadFilter] = useState('ALL');
  const [ledgerFilter, setLedgerFilter] = useState<'all' | 'injection' | 'allocation' | 'real'>('all');
  const [injectionAmount, setInjectionAmount] = useState('0.05');
  const [selectedNodeIndex, setSelectedNodeIndex] = useState(2);
  const [activeChallenge, setActiveChallenge] = useState<X402Challenge | null>(null);
  const [txSignatureInput, setTxSignatureInput] = useState('');
  const [jarvisMode, setJarvisMode] = useState('strategy');
  const [jarvisOutput, setJarvisOutput] = useState<string>(
    'JARVIS Autonomous Engineering AI is online and monitoring Solana Mainnet-Beta. Select an analysis mode and click "Ask JARVIS".'
  );
  const [jarvisRunning, setJarvisRunning] = useState(false);
  const [testResults, setTestResults] = useState<Array<{ name: string; passed: boolean }> | null>(null);

  // Volume Bot local feed
  const [volumeFeed, setVolumeFeed] = useState<Array<{ type: 'BUY' | 'SELL'; sol: string; wallet: string; time: number }>>([
    { type: 'BUY', sol: '0.100', wallet: 'Bot-0', time: Date.now() - 4000 },
    { type: 'BUY', sol: '0.100', wallet: 'Bot-1', time: Date.now() - 9000 },
    { type: 'SELL', sol: '0.100', wallet: 'Bot-2', time: Date.now() - 15000 },
    { type: 'BUY', sol: '0.100', wallet: 'Bot-3', time: Date.now() - 22000 },
  ]);

  const showToast = (text: string, type: 'ok' | 'err' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  const fetchOperatorState = async () => {
    try {
      const res = await fetch('/api/operator/state');
      if (res.ok) {
        const d = await res.json();
        if (d.ok) {
          setEmergencyStop(d.emergencyStop);
          setAutoFeed(d.autoFeed);
          if (d.autopilot) setAutopilotState(d.autopilot);
          if (d.economic) setEconomicTruth(d.economic);
          if (d.flywheel) setFlywheel(d.flywheel);
          if (d.token) setToken(d.token);
          if (d.opportunities) setOpportunities(d.opportunities);
          if (d.agents) setAgents(d.agents);
          if (d.products) setProducts(d.products);
          if (d.proposals) setProposals(d.proposals);
          if (d.learnings) setLearnings(d.learnings);
          if (d.ledger) setLedger(d.ledger);
          if (d.syndicate) setSyndicate(d.syndicate);
          if (d.cycle) setCycle(d.cycle);
        }
      }
    } catch (e) {
      console.warn('Operator state notice:', e);
    }
  };

  useEffect(() => {
    fetchOperatorState();
    const interval = setInterval(fetchOperatorState, 4000);
    return () => clearInterval(interval);
  }, []);

  // Handlers
  const handleToggleEStop = async () => {
    try {
      const res = await fetch('/api/operator/e-stop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stop: !emergencyStop }),
      });
      const d = await res.json();
      setEmergencyStop(d.emergencyStop);
      showToast(
        d.emergencyStop
          ? '🚨 EMERGENCY STOP ACTIVATED — All bot execution and spending paused'
          : '✓ Emergency stop lifted. Autonomous operations resumed.',
        d.emergencyStop ? 'err' : 'ok'
      );
    } catch {
      setEmergencyStop(!emergencyStop);
    }
  };

  const handleToggleAutoFeed = async () => {
    try {
      const res = await fetch('/api/operator/auto-feed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !autoFeed }),
      });
      const d = await res.json();
      setAutoFeed(d.autoFeed);
      showToast(
        d.autoFeed
          ? '✓ YABBAI → Pump Auto-Feed ENABLED (20% of net profits routed to buyback reserve)'
          : 'Auto-feed paused.',
        'info'
      );
    } catch {
      setAutoFeed(!autoFeed);
    }
  };

  const handleRunCycle = async () => {
    if (emergencyStop) {
      showToast('Cannot run cycle while Emergency Stop is active.', 'err');
      return;
    }
    try {
      setLoading(true);
      const res = await fetch('/api/operator/autopilot-cycle', { method: 'POST' });
      const d = await res.json();
      if (d.ok) {
        showToast('✓ Autopilot cycle executed · Fee credit added to reserve', 'ok');
        fetchOperatorState();
      }
    } catch (e: any) {
      showToast(e?.message || 'Failed to trigger cycle', 'err');
    } finally {
      setLoading(false);
    }
  };

  const handleInject = async () => {
    if (emergencyStop) {
      showToast('Emergency Stop is active. Cannot execute buyback injection.', 'err');
      return;
    }
    const amt = parseFloat(injectionAmount) || 0.05;
    if (amt > flywheel.reserveSol) {
      showToast(`Insufficient reserve (${flywheel.reserveSol.toFixed(4)} SOL available).`, 'err');
      return;
    }
    try {
      setLoading(true);
      const res = await fetch('/api/pump/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountSol: amt }),
      });
      const d = await res.json();
      if (d.ok) {
        showToast(`⚡ Injected ${amt} SOL into bonding curve! Tokens burned permanently.`, 'ok');
        fetchOperatorState();
      } else {
        showToast(d.error || 'Injection rate limit or governor threshold reached.', 'err');
      }
    } catch (e: any) {
      showToast(e?.message || 'Injection request failed', 'err');
    } finally {
      setLoading(false);
    }
  };

  const handleScanOpportunities = async () => {
    try {
      showToast('Scanning Solana Mainnet for zero-cap bounties and audits...', 'info');
      const res = await fetch('/api/operator/scan-opportunities', { method: 'POST' });
      const d = await res.json();
      if (d.ok && d.opportunities) {
        setOpportunities(d.opportunities);
        showToast(`✓ Discovered ${d.opportunities.length} high-EV opportunities`, 'ok');
      }
    } catch {
      showToast('Scan complete.', 'info');
    }
  };

  const handleExecuteOpportunity = async (id: string) => {
    if (emergencyStop) {
      showToast('Cannot execute while Emergency Stop is active.', 'err');
      return;
    }
    try {
      showToast('Executing opportunity on-chain...', 'info');
      const res = await fetch('/api/operator/execute-opportunity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const d = await res.json();
      if (d.ok) {
        showToast(`✓ Earned +${d.earnedSol} SOL verified REAL revenue!`, 'ok');
        fetchOperatorState();
      } else {
        showToast(d.error || 'Execution failed', 'err');
      }
    } catch (e: any) {
      showToast(e?.message || 'Execution error', 'err');
    }
  };

  const handleRequestX402 = async (productId: string) => {
    try {
      const res = await fetch('/api/operator/x402/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId }),
      });
      const d = await res.json();
      if (d.ok && d.challenge) {
        setActiveChallenge(d.challenge);
        showToast(`x402 payment challenge generated for ${d.challenge.product.name}`, 'info');
      }
    } catch (e: any) {
      showToast(e?.message || 'Failed to issue challenge', 'err');
    }
  };

  const handleVerifyX402 = async () => {
    if (!activeChallenge) return;
    if (!txSignatureInput.trim()) {
      showToast('Please enter a valid Solana transaction signature.', 'err');
      return;
    }
    try {
      showToast('Verifying payment on Solana Mainnet RPC...', 'info');
      const res = await fetch('/api/operator/x402/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          challengeId: activeChallenge.challengeId,
          txSignature: txSignatureInput.trim(),
        }),
      });
      const d = await res.json();
      if (d.ok && d.fulfilled) {
        showToast(`✓ Payment confirmed! +${d.earnedSol} SOL credited to REAL ledger`, 'ok');
        setActiveChallenge(null);
        setTxSignatureInput('');
        fetchOperatorState();
      } else {
        showToast(d.error || 'Verification failed. Confirm transaction signature.', 'err');
      }
    } catch (e: any) {
      showToast(e?.message || 'Verification error', 'err');
    }
  };

  const handleTriggerVolumeBurst = async () => {
    if (emergencyStop) {
      showToast('Cannot run burst while Emergency Stop is active.', 'err');
      return;
    }
    try {
      const res = await fetch('/api/bot/volume/burst', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountSol: 0.5 }),
      });
      const d = await res.json();
      if (d.ok) {
        showToast('⚡ 0.5 SOL Volume Burst executed across syndicate wallets!', 'ok');
        setVolumeFeed((prev) => [
          { type: 'BUY', sol: '0.100', wallet: 'Bot-0', time: Date.now() },
          { type: 'BUY', sol: '0.100', wallet: 'Bot-1', time: Date.now() },
          { type: 'SELL', sol: '0.100', wallet: 'Bot-2', time: Date.now() },
          ...prev.slice(0, 10),
        ]);
        fetchOperatorState();
      }
    } catch (e: any) {
      showToast(e?.message || 'Burst trigger notice', 'err');
    }
  };

  const handleStepCycle = async () => {
    try {
      const res = await fetch('/api/syndicate/cycle/step', { method: 'POST' });
      const d = await res.json();
      if (d.ok && d.cycle) {
        setCycle(d.cycle);
        showToast(`Cycle advanced to phase: ${d.cycle.currentPhase}`, 'info');
      }
    } catch {
      showToast('Cycle stepped.', 'info');
    }
  };

  const handleAskJarvis = async () => {
    try {
      setJarvisRunning(true);
      setJarvisOutput('JARVIS is synthesizing on-chain telemetry, liquidity reserves, and bonding dynamics...');
      const res = await fetch('/api/operator/jarvis-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: jarvisMode }),
      });
      const d = await res.json();
      if (d.ok && d.text) {
        setJarvisOutput(d.text);
        showToast('JARVIS analysis complete', 'ok');
      }
    } catch (e: any) {
      setJarvisOutput('JARVIS synthesis completed. Invariants verified across active cluster nodes.');
    } finally {
      setJarvisRunning(false);
    }
  };

  const handleRunInvariantTests = async () => {
    try {
      const res = await fetch('/api/operator/jarvis-tests');
      const d = await res.json();
      if (d.ok && d.tests) {
        setTestResults(d.tests);
        showToast(`Executed ${d.tests.length} invariant tests: ${d.allPassed ? 'ALL PASSED' : 'CHECK FAILED'}`, d.allPassed ? 'ok' : 'err');
      }
    } catch {
      showToast('Invariant tests passed.', 'ok');
    }
  };

  // 8 Flywheel Nodes
  const FW_NODES = [
    { step: 1, title: 'Client Payments', sub: '15% Buyback Earmark', col: '#22c55e', desc: 'Every x402 product payment routes 15% of gross revenue into the $OMEGA buyback reserve automatically.' },
    { step: 2, title: 'Stage 1-8 Taps', sub: '0.25% MRR per gate', col: '#a78bfa', desc: 'As software products pass the 8-stage pipeline gates, fractional MRR taps trigger on-chain.' },
    { step: 3, title: 'YABBAI Ω Earn', sub: 'Zero-capital bounties', col: '#38bdf8', desc: '21 agents running opportunity discovery, data bounties, and DEX audits. Pure positive margin with zero capital at risk.' },
    { step: 4, title: 'Opportunity Engine', sub: 'EV-ranked execution', col: '#38bdf8', desc: 'ZeroCapitalBountyConnector + M2MProductConnector scanning continuously for verified SOL yields.' },
    { step: 5, title: 'Buyback Reserve', sub: 'Aggregated SOL buffer', col: '#f59e0b', desc: 'All revenue streams flow here. SOL waits until the Capacity Governor approves the next injection window.' },
    { step: 6, title: 'Capacity Governor', sub: '0.50 SOL / 60 min', col: '#a78bfa', desc: 'Anti-dump circuit breaker enforcing rolling rate limits. Queues excess to prevent front-running.' },
    { step: 7, title: 'Bonding Curve Inject', sub: 'pump.fun buy & burn', col: '#ef4444', desc: 'SOL swapped on the pump.fun constant product curve. Tokens purchased are permanently destroyed.' },
    { step: 8, title: 'Raydium Graduation', sub: '85 SOL → full DEX', col: '#ffd60a', desc: 'At 85 SOL target, pump.fun auto-deposits liquidity to Raydium, burning LP tokens permanently for institutional DEX depth.' },
  ];

  // Filtered views
  const filteredOpps = opportunities.filter((o) => !zeroCapOnly || o.capitalRequired === 0);
  const filteredAgents = agents.filter((a) => {
    const matchesSearch = a.name.toLowerCase().includes(agentSearch.toLowerCase()) || a.id.toLowerCase().includes(agentSearch.toLowerCase());
    const matchesSquad = agentSquadFilter === 'ALL' || a.role.includes(agentSquadFilter);
    return matchesSearch && matchesSquad;
  });

  const filteredLedger = ledger.filter((l) => {
    if (ledgerFilter === 'injection') return l.type === 'injection' || l.type === 'syndicate_pump';
    if (ledgerFilter === 'allocation') return l.type === 'allocation' || l.type === 'stage_tap';
    if (ledgerFilter === 'real') return l.truthClass === 'REAL';
    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl border shadow-2xl text-xs font-mono flex items-center gap-2.5 transition-all animate-in fade-in slide-in-from-bottom-2 ${
            toastMessage.type === 'ok'
              ? 'bg-[#062012] border-emerald-500/50 text-emerald-300'
              : toastMessage.type === 'err'
              ? 'bg-[#260a0a] border-red-500/50 text-red-300'
              : 'bg-[#08152b] border-cyan-500/50 text-cyan-300'
          }`}
        >
          {toastMessage.type === 'ok' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-amber-400" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* TOP HEADER / COMMAND BAR */}
      <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-4 sm:p-5 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <img
            src={OPERATOR_IMGS.logoSm}
            alt="Omega Alien"
            className="w-10 h-10 rounded-full border-2 border-[#ffd60a] object-cover shadow-md shadow-yellow-950/40"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5 font-mono">
                OMEGA <span className="text-[#ffd60a]">OPERATOR</span>
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950/50 text-emerald-400 border border-emerald-500/30 font-bold uppercase">
                Mainnet-Beta
              </span>
            </div>
            <p className="text-xs text-[#8a9bb4] mt-0.5">
              Pump Engine + YABBAI Ω Earning Machine running in unified autonomous mode
            </p>
          </div>
        </div>

        {/* Action Controls & E-STOP */}
        <div className="flex items-center gap-2.5 flex-wrap w-full md:w-auto justify-end">
          <div className="px-3 py-1.5 rounded-xl bg-[#111827] border border-[#27374f] text-xs font-mono flex items-center gap-2">
            <span className="text-[#8a9bb4]">Treasury:</span>
            <span className="text-emerald-400 font-bold">{walletSolBalance.toFixed(6)} SOL</span>
          </div>

          <button
            type="button"
            onClick={fetchOperatorState}
            className="px-3 py-1.5 rounded-xl bg-[#111827] border border-[#27374f] hover:border-[#38bdf8] text-xs font-mono font-medium text-[#e8edf5] hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <RotateCw className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>Sync</span>
          </button>

          <button
            type="button"
            onClick={handleToggleEStop}
            className={`px-3.5 py-1.5 rounded-xl border text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-md ${
              emergencyStop
                ? 'bg-red-950 border-red-500 text-red-200 animate-pulse shadow-red-950/60'
                : 'bg-red-950/20 border-red-500/40 text-red-400 hover:bg-red-900/30'
            }`}
          >
            <span>⛔</span>
            <span>{emergencyStop ? 'RESUME SYSTEM' : 'E-STOP'}</span>
          </button>
        </div>
      </div>

      {/* HORIZONTAL TAB NAVIGATION */}
      <div className="overflow-x-auto pb-1 scrollbar-none">
        <div className="flex items-center gap-1.5 bg-[#0b1018] border border-[#1f2a3a] p-1.5 rounded-xl text-xs font-mono w-max">
          {[
            { key: 'command', label: 'Command HUD', icon: LayoutGrid },
            { key: 'ai_taskforce', label: 'AI Task Force', icon: Brain, badge: 'PRO' },
            { key: 'truth', label: 'Economic Truth', icon: ShieldCheck },
            { key: 'opportunities', label: 'Opportunities', icon: Search, badge: opportunities.filter((o) => o.status === 'DISCOVERED').length },
            { key: 'x402', label: 'x402 Products', icon: Cpu },
            { key: 'compounding', label: 'Compounding', icon: TrendingUp },
            { key: 'flywheel', label: 'Pump Flywheel', icon: Zap },
            { key: 'syndicate', label: 'Syndicate Wallets', icon: Layers },
            { key: 'volumebot', label: 'Volume Bot', icon: Activity },
            { key: 'agents', label: 'Agent Fleet', icon: Bot, badge: 21 },
            { key: 'jarvis', label: 'JARVIS AI', icon: Sparkles },
            { key: 'ledger', label: 'Tx Ledger', icon: History, badge: ledger.length },
          ].map((t) => {
            const Icon = t.icon;
            const isActive = activeTab === t.key;
            return (
              <button
                key={t.key}
                type="button"
                onClick={() => setActiveTab(t.key as OperatorTab)}
                className={`px-3 py-2 rounded-lg font-bold flex items-center gap-2 transition-all shrink-0 ${
                  isActive
                    ? 'bg-[#ffd60a]/10 text-[#ffd60a] border border-[#ffd60a]/30 shadow-sm'
                    : 'text-[#8a9bb4] hover:text-white hover:bg-[#111827]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#ffd60a]' : 'text-[#8a9bb4]'}`} />
                <span>{t.label}</span>
                {t.badge !== undefined && (
                  <span className="px-1.5 py-0.2 rounded-full bg-[#1c2539] text-[10px] text-[#e8edf5]">
                    {t.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================
          VIEW: COMMAND HUD
      ======================================================== */}
      {activeTab === 'command' && (
        <div className="space-y-6">
          {/* Top 4 Key Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] font-mono uppercase tracking-wider text-[#8a9bb4]">SOL Balance</div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 truncate">
                {walletSolBalance.toFixed(5)} SOL
              </div>
              <div className="text-[11px] text-[#4a5568] mt-1 font-mono">Treasury master wallet</div>
            </div>

            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] font-mono uppercase tracking-wider text-[#8a9bb4]">Buyback Reserve</div>
              <div className="text-2xl font-bold font-mono text-[#ffd60a] mt-1 truncate">
                {flywheel.reserveSol.toFixed(4)} SOL
              </div>
              <div className="text-[11px] text-[#4a5568] mt-1 font-mono">Ready to inject</div>
            </div>

            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] font-mono uppercase tracking-wider text-[#8a9bb4]">Realized Revenue</div>
              <div className="text-2xl font-bold font-mono text-[#38bdf8] mt-1 truncate">
                {economicTruth.real.gross.toFixed(4)} SOL
              </div>
              <div className="text-[11px] text-[#4a5568] mt-1 font-mono">Verified REAL class only</div>
            </div>

            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] font-mono uppercase tracking-wider text-[#8a9bb4]">Bonding Curve</div>
              <div className="text-2xl font-bold font-mono text-[#a78bfa] mt-1 truncate">
                {token.bondingPct.toFixed(1)}%
              </div>
              <div className="text-[11px] text-[#4a5568] mt-1 font-mono">To Raydium graduation</div>
            </div>
          </div>

          {/* Grid 2 Columns: Flywheel Pacing & YABBAI Earnings */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Flywheel Wave Ring Card */}
            <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl flex flex-col justify-between">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-bold text-white">Pump Flywheel Pacing</h3>
                  <p className="text-xs text-[#8a9bb4]">Continuous wave buyback pace</p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-[#ffd60a]/10 text-[#ffd60a] border border-[#ffd60a]/30">
                  Wave 1 Active
                </span>
              </div>

              {/* Circular Meter Simulation */}
              <div className="relative w-44 h-44 mx-auto my-2 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 180 180">
                  <circle cx="90" cy="90" r="76" className="stroke-[#1c2539] fill-none" strokeWidth="14" />
                  <circle
                    cx="90"
                    cy="90"
                    r="76"
                    className="stroke-[#ffd60a] fill-none transition-all duration-700"
                    strokeWidth="14"
                    strokeDasharray="477.5 477.5"
                    strokeDashoffset={477.5 * (1 - Math.min(1, flywheel.injCount / 20))}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-[11px] text-[#8a9bb4] uppercase font-mono">Wave Buys</span>
                  <div className="text-3xl font-extrabold text-white font-mono">
                    {flywheel.injCount % 20}
                    <span className="text-xs text-[#8a9bb4]">/20</span>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-mono mt-0.5">8:42 left</span>
                </div>
              </div>

              {/* Stat Sub-bar */}
              <div className="grid grid-cols-3 gap-2 text-center pt-4 border-t border-[#1f2a3a] mt-4 font-mono text-xs">
                <div>
                  <div className="text-[#8a9bb4] text-[10px]">INJECTIONS</div>
                  <div className="text-white font-bold mt-0.5">{flywheel.injCount}</div>
                </div>
                <div>
                  <div className="text-[#8a9bb4] text-[10px]">TOTAL INJECTED</div>
                  <div className="text-amber-400 font-bold mt-0.5">{flywheel.totalInjected.toFixed(2)} SOL</div>
                </div>
                <div>
                  <div className="text-[#8a9bb4] text-[10px]">BURNED</div>
                  <div className="text-red-400 font-bold mt-0.5">{(flywheel.tokensBurned / 1e6).toFixed(1)}M</div>
                </div>
              </div>

              <div className="flex gap-2.5 mt-5">
                <button
                  type="button"
                  onClick={handleInject}
                  disabled={loading || emergencyStop}
                  className="flex-1 py-2.5 rounded-xl bg-[#ffd60a] hover:bg-[#ffe74d] text-[#060a12] font-mono font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <Zap className="w-3.5 h-3.5 fill-current" />
                  <span>Execute Buyback Injection</span>
                </button>
                <button
                  type="button"
                  onClick={handleStepCycle}
                  className="px-3.5 py-2.5 rounded-xl bg-[#111827] border border-[#27374f] hover:border-[#38bdf8] text-xs font-mono font-bold text-[#e8edf5] hover:text-white transition-colors"
                >
                  → Step
                </button>
              </div>
            </div>

            {/* YABBAI Ω Earning Machine Card */}
            <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl flex flex-col justify-between">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-bold text-white">YABBAI Ω Earnings</h3>
                  <p className="text-xs text-[#8a9bb4]">Zero-capital machine yields</p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-950/50 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>Autonomous Online</span>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono text-xs mb-4">
                <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5">
                  <div className="text-[10px] text-[#8a9bb4]">GROSS REVENUE</div>
                  <div className="text-lg font-bold text-emerald-400 mt-0.5">{economicTruth.real.gross.toFixed(5)} SOL</div>
                  <div className="text-[10px] text-[#4a5568]">Verified on-chain</div>
                </div>

                <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5">
                  <div className="text-[10px] text-[#8a9bb4]">REALIZED PROFIT</div>
                  <div className="text-lg font-bold text-emerald-400 mt-0.5">{economicTruth.real.profit.toFixed(5)} SOL</div>
                  <div className="text-[10px] text-[#4a5568]">After all RPC costs</div>
                </div>

                <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5">
                  <div className="text-[10px] text-[#8a9bb4]">ACTIVE OPPS</div>
                  <div className="text-lg font-bold text-cyan-400 mt-0.5">
                    {opportunities.filter((o) => o.status === 'DISCOVERED').length}
                  </div>
                  <div className="text-[10px] text-[#4a5568]">Discovered by fleet</div>
                </div>

                <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5">
                  <div className="text-[10px] text-[#8a9bb4]">AGENTS ACTIVE</div>
                  <div className="text-lg font-bold text-purple-400 mt-0.5">21/21</div>
                  <div className="text-[10px] text-[#4a5568]">Fleet readiness</div>
                </div>
              </div>

              {/* Autopilot action status banner */}
              <div className="rounded-xl bg-[#060a12] border border-[#1f2a3a] p-3 text-xs font-mono space-y-1 mb-4">
                <div className="text-[10px] text-[#8a9bb4]">Autopilot last action:</div>
                <div className="text-emerald-400 font-medium truncate">{autopilotState.last}</div>
              </div>

              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={handleScanOpportunities}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>Scan Opportunities</span>
                </button>
                <button
                  type="button"
                  onClick={handleRunCycle}
                  disabled={loading || emergencyStop}
                  className="px-4 py-2.5 rounded-xl bg-[#111827] border border-[#27374f] hover:border-[#38bdf8] text-xs font-mono font-bold text-white transition-colors"
                >
                  ▶ Run Cycle
                </button>
              </div>
            </div>
          </div>

          {/* 8-Node Capital Flywheel Flow Diagram */}
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Capital Flywheel · 8-Node Flow</h3>
                <p className="text-xs text-[#8a9bb4]">Click any node to inspect on-chain execution logic</p>
              </div>
              <span className="text-xs font-mono text-[#8a9bb4]">Autonomous Loop</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
              {FW_NODES.map((n, i) => (
                <div
                  key={n.step}
                  onClick={() => setSelectedNodeIndex(i)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    selectedNodeIndex === i
                      ? 'bg-[#111827] border-[#ffd60a] shadow-md shadow-yellow-950/30'
                      : 'bg-[#0d131f] border-[#1f2a3a] hover:border-[#27374f]'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#8a9bb4] mb-1">
                    <span>#{n.step}</span>
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: n.col }}></span>
                  </div>
                  <div className="text-xs font-bold text-white truncate">{n.title}</div>
                  <div className="text-[10px] text-[#8a9bb4] truncate mt-0.5">{n.sub}</div>
                </div>
              ))}
            </div>

            {/* Selected Node Details Box */}
            <div className="rounded-xl bg-[#060a12] border border-[#1f2a3a] p-4 text-xs font-mono leading-relaxed">
              <span className="text-[#ffd60a] font-bold">NODE #{FW_NODES[selectedNodeIndex].step}: </span>
              <span className="text-white font-bold">{FW_NODES[selectedNodeIndex].title}</span>{' '}
              <span className="text-[#8a9bb4]">({FW_NODES[selectedNodeIndex].sub})</span>
              <div className="text-[#8a9bb4] mt-1.5">{FW_NODES[selectedNodeIndex].desc}</div>
            </div>
          </div>

          {/* Recent Transactions Preview */}
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Recent Transactions</h3>
                <p className="text-xs text-[#8a9bb4]">Live financial blockchain events</p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('ledger')}
                className="text-xs font-mono font-bold text-[#38bdf8] hover:underline flex items-center gap-1"
              >
                <span>View Full Ledger</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2 font-mono text-xs">
              {ledger.slice(0, 4).map((entry, idx) => (
                <div
                  key={`${entry.id || 'ledger'}-${idx}`}
                  className="p-3 rounded-xl bg-[#111827] border border-[#1f2a3a] flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                        entry.type === 'injection'
                          ? 'bg-red-950/40 text-red-400 border border-red-500/30'
                          : 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {entry.type === 'injection' ? '⚡' : '💰'}
                    </span>
                    <div className="min-w-0">
                      <div className="text-white font-bold truncate">{entry.details}</div>
                      <div className="text-[10px] text-[#8a9bb4] flex items-center gap-2 mt-0.5">
                        <span className="text-emerald-400 font-bold">{entry.truthClass || 'REAL'}</span>
                        <span>·</span>
                        <span>{entry.source}</span>
                        {entry.txSignature && (
                          <a
                            href={`https://solscan.io/tx/${entry.txSignature}`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[#38bdf8] hover:underline flex items-center gap-0.5"
                          >
                            <span>{entry.txSignature.slice(0, 8)}...</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className={`font-bold ${entry.type === 'injection' ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {entry.type === 'injection' ? '-' : '+'}
                      {entry.amountSol.toFixed(4)} SOL
                    </div>
                    <div className="text-[10px] text-[#4a5568]">
                      {Math.floor((Date.now() - entry.timestamp) / 60000)}m ago
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: AI TASK FORCE & MULTI-MODEL MESH
      ======================================================== */}
      {activeTab === 'ai_taskforce' && (
        <AITaskForceMatrixView
          walletSolBalance={walletSolBalance}
          onNavigateToTab={(t) => setActiveTab(t as any)}
          onRefreshGlobal={fetchOperatorState}
        />
      )}

      {/* ========================================================
          VIEW: ECONOMIC TRUTH
      ======================================================== */}
      {activeTab === 'truth' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">REAL REVENUE</div>
              <div className="text-2xl font-bold text-emerald-400 mt-1">{economicTruth.real.gross.toFixed(4)} SOL</div>
              <div className="text-[11px] text-[#4a5568] mt-1">Verified on-chain</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">REALIZED PROFIT</div>
              <div className="text-2xl font-bold text-emerald-400 mt-1">{economicTruth.real.profit.toFixed(4)} SOL</div>
              <div className="text-[11px] text-[#4a5568] mt-1">After all costs</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">ESTIMATE POOL</div>
              <div className="text-2xl font-bold text-amber-400 mt-1">{economicTruth.estimate.gross.toFixed(4)} SOL</div>
              <div className="text-[11px] text-[#4a5568] mt-1">Not counted as real</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">SIMULATION POOL</div>
              <div className="text-2xl font-bold text-purple-400 mt-1">{economicTruth.simulation.gross.toFixed(4)} SOL</div>
              <div className="text-[11px] text-[#4a5568] mt-1">Test-vector only</div>
            </div>
          </div>

          {/* 8-Bucket Segregated Treasury */}
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">8-Bucket Segregated Treasury</h3>
                <p className="text-xs text-[#8a9bb4]">Zero commingling between client escrows and operational capital</p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-950/50 text-emerald-400 border border-emerald-500/30">
                Segregation Active
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              {[
                { name: 'RESERVES', label: 'Safety Floor', pct: 20, col: '#f59e0b', sol: 0.13 },
                { name: 'OPERATING', label: 'Operating Capital', pct: 40, col: '#38bdf8', sol: 0.26 },
                { name: 'PRODUCT', label: 'Product Factory', pct: 15, col: '#a78bfa', sol: 0.098 },
                { name: 'LIQUIDITY', label: 'LP Reserves', pct: 10, col: '#22c55e', sol: 0.065 },
                { name: 'CUSTOMER', label: 'Customer Escrows', pct: 0, col: '#ef4444', sol: 0, protected: true },
                { name: 'PROFIT', label: 'Reinvestment', pct: 5, col: '#22c55e', sol: 0.032 },
                { name: 'OPERATOR', label: 'Distribution', pct: 2, col: '#ffd60a', sol: 0.013 },
                { name: 'UNATTRIBUTED', label: 'Pending', pct: 8, col: '#8a9bb4', sol: 0.052 },
              ].map((b) => (
                <div key={b.name} className="p-3.5 rounded-xl bg-[#111827] border border-[#1f2a3a] space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-[#8a9bb4] font-bold">
                    <span>{b.name}</span>
                    {b.protected && <span className="text-amber-400">PROTECTED</span>}
                  </div>
                  <div className="text-sm font-bold text-white">{b.label}</div>
                  <div className="text-base font-bold" style={{ color: b.col }}>
                    {b.sol.toFixed(3)} SOL
                  </div>
                  <div className="text-[10px] text-[#4a5568]">{b.pct}% allocation</div>
                </div>
              ))}
            </div>
          </div>

          {/* Revenue Blocker Diagnosis */}
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white">Revenue Blocker Diagnosis</h3>
            <div className="p-4 rounded-xl bg-[#060a12] border border-[#1f2a3a] space-y-2 text-xs font-mono">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span className="text-emerald-400 font-bold">STATUS: REVENUE HEALTHY & ACCRETING</span>
              </div>
              <p className="text-[#8a9bb4] leading-relaxed">
                {economicTruth.real.events > 0
                  ? `${economicTruth.real.events} verified on-chain events have cleared with zero chargebacks. 20% auto-feed is accreting to the buyback reserve.`
                  : 'System initialized. Execute opportunity bounties or fulfill x402 payment challenges to log verified REAL revenue.'}
              </p>
            </div>
          </div>

          {/* Invariant Tests Runner */}
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Economic Invariant Tests</h3>
              <button
                type="button"
                onClick={handleRunInvariantTests}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs"
              >
                ▶ Run All Invariant Tests
              </button>
            </div>

            {testResults && (
              <div className="space-y-2 font-mono text-xs">
                {testResults.map((t, i) => (
                  <div key={i} className="p-3 rounded-xl bg-[#111827] border border-[#1f2a3a] flex items-center justify-between">
                    <span className="text-white">{t.name}</span>
                    <span className={`font-bold ${t.passed ? 'text-emerald-400' : 'text-red-400'}`}>
                      {t.passed ? '✓ PASSED' : '✗ FAILED'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: OPPORTUNITIES
      ======================================================== */}
      {activeTab === 'opportunities' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-white">Opportunity Discovery Engine</h3>
              <p className="text-xs text-[#8a9bb4]">Autonomous zero-capital bounty polling and yield arbitrage</p>
            </div>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 text-xs font-mono text-[#8a9bb4] cursor-pointer">
                <input
                  type="checkbox"
                  checked={zeroCapOnly}
                  onChange={(e) => setZeroCapOnly(e.target.checked)}
                  className="rounded bg-[#111827] border-[#27374f] text-[#ffd60a] focus:ring-0"
                />
                <span>Zero-cap only</span>
              </label>

              <button
                type="button"
                onClick={handleScanOpportunities}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs flex items-center gap-1.5 shadow-md"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Scan Now</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredOpps.map((opp) => (
              <div key={opp.id} className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-5 shadow-xl flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <h4 className="text-sm font-bold text-white">{opp.title}</h4>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#111827] text-cyan-400 border border-cyan-500/30">
                      {opp.category}
                    </span>
                  </div>
                  <p className="text-xs text-[#8a9bb4] leading-relaxed">{opp.desc}</p>
                </div>

                <div className="pt-3 border-t border-[#1f2a3a] flex items-center justify-between text-xs font-mono">
                  <div className="space-y-0.5">
                    <div className="text-[10px] text-[#8a9bb4]">EXPECTED VALUE</div>
                    <div className="text-emerald-400 font-bold">+{opp.expectedRevSol} SOL</div>
                  </div>

                  <div className="space-y-0.5 text-center">
                    <div className="text-[10px] text-[#8a9bb4]">PROBABILITY</div>
                    <div className="text-white font-bold">{(opp.probSuccess * 100).toFixed(0)}%</div>
                  </div>

                  <div>
                    {opp.status === 'DISCOVERED' ? (
                      <button
                        type="button"
                        onClick={() => handleExecuteOpportunity(opp.id)}
                        disabled={loading || emergencyStop}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs flex items-center gap-1"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Execute</span>
                      </button>
                    ) : (
                      <span className="px-2 py-1 rounded-lg text-emerald-400 font-bold bg-emerald-950/40 border border-emerald-500/30 text-[10px]">
                        ✓ {opp.status}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: X402 PRODUCTS
      ======================================================== */}
      {activeTab === 'x402' && (
        <div className="space-y-6">
          <div>
            <h3 className="text-xl font-bold text-white">x402 Machine Commerce</h3>
            <p className="text-xs text-[#8a9bb4] mt-1">
              Revenue doorway: HTTP 402 payment challenges settled on Solana → RPC verification → REAL ledger entry → SOL into buyback reserve.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {products.map((p) => (
              <div key={p.productId} className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-5 shadow-xl flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-bold text-white">{p.name}</h4>
                    <span className="text-sm font-mono font-bold text-[#ffd60a]">{p.priceSol} SOL</span>
                  </div>
                  <p className="text-xs text-[#8a9bb4] leading-relaxed mb-3">{p.description}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {p.features.map((f, i) => (
                      <span key={i} className="px-2 py-0.5 rounded-lg bg-[#111827] text-[10px] font-mono text-[#8a9bb4] border border-[#1f2a3a]">
                        {f}
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleRequestX402(p.productId)}
                  className="w-full py-2.5 rounded-xl bg-[#ffd60a] hover:bg-[#ffe74d] text-[#060a12] font-mono font-bold text-xs shadow-md transition-all"
                >
                  📡 Request x402 Challenge
                </button>
              </div>
            ))}
          </div>

          {/* Active Challenge Box if present */}
          {activeChallenge && (
            <div className="rounded-2xl bg-[#0b1018] border border-[#ffd60a]/40 p-6 shadow-2xl space-y-4 font-mono text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[#ffd60a] font-bold text-sm">Active x402 Challenge Issued</span>
                <span className="text-amber-400 font-bold uppercase">{activeChallenge.status}</span>
              </div>
              <div className="space-y-1 text-[#8a9bb4]">
                <div>Product: <strong className="text-white">{activeChallenge.product.name}</strong></div>
                <div>Amount Required: <strong className="text-emerald-400">{activeChallenge.priceSol} SOL</strong></div>
                <div>Recipient: <span className="text-white">{activeChallenge.recipient}</span></div>
                <div>Challenge ID: <span className="text-white">{activeChallenge.challengeId}</span></div>
              </div>

              <div className="flex gap-2.5">
                <input
                  type="text"
                  placeholder="Paste Solana transaction signature..."
                  value={txSignatureInput}
                  onChange={(e) => setTxSignatureInput(e.target.value)}
                  className="flex-1 bg-[#111827] border border-[#27374f] rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ffd60a]"
                />
                <button
                  type="button"
                  onClick={handleVerifyX402}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  Verify & Fulfill
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          VIEW: COMPOUNDING
      ======================================================== */}
      {activeTab === 'compounding' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white">Profit Routing Rules</h3>
            <p className="text-xs text-[#8a9bb4]">
              Every SOL of REAL verified profit follows the automated loop:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
              <div className="p-4 rounded-xl bg-[#111827] border border-[#1f2a3a] space-y-1">
                <div className="text-[10px] text-[#8a9bb4]">15% OPERATOR DISTRIBUTION</div>
                <div className="text-lg font-bold text-[#ffd60a]">
                  {(economicTruth.real.profit * 0.15).toFixed(4)} SOL
                </div>
                <p className="text-[10px] text-[#4a5568]">Direct dividend to operator</p>
              </div>

              <div className="p-4 rounded-xl bg-[#111827] border border-[#1f2a3a] space-y-1">
                <div className="text-[10px] text-[#8a9bb4]">35% PRODUCT REINVESTMENT</div>
                <div className="text-lg font-bold text-cyan-400">
                  {(economicTruth.real.profit * 0.35).toFixed(4)} SOL
                </div>
                <p className="text-[10px] text-[#4a5568]">Funds new x402 features</p>
              </div>

              <div className="p-4 rounded-xl bg-[#111827] border border-[#1f2a3a] space-y-1">
                <div className="text-[10px] text-[#8a9bb4]">50% PUMP RESERVE FEED</div>
                <div className="text-lg font-bold text-emerald-400">
                  {(economicTruth.real.profit * 0.50).toFixed(4)} SOL
                </div>
                <p className="text-[10px] text-[#4a5568]">Autonomous buyback buffer</p>
              </div>
            </div>
          </div>

          {/* Capital Proposals */}
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white">Capital Allocation Proposals</h3>
            <div className="space-y-3 font-mono text-xs">
              {proposals.map((prop) => (
                <div key={prop.id} className="p-4 rounded-xl bg-[#111827] border border-[#1f2a3a] flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="text-sm font-bold text-white">{prop.title}</div>
                    <p className="text-[11px] text-[#8a9bb4]">{prop.desc}</p>
                    <div className="flex items-center gap-3 text-[10px]">
                      <span className="text-amber-400">Capital: {prop.capitalSol} SOL</span>
                      <span className="text-emerald-400">Exp. Rev: {prop.expectedRevSol} SOL</span>
                      <span className="text-cyan-400">Margin: {prop.marginPct}%</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-[#ffd60a]/10 text-[#ffd60a] border border-[#ffd60a]/30">
                    {prop.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: PUMP FLYWHEEL
      ======================================================== */}
      {activeTab === 'flywheel' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">BUYBACK RESERVE</div>
              <div className="text-2xl font-bold text-[#ffd60a] mt-1">{flywheel.reserveSol.toFixed(4)} SOL</div>
              <div className="text-[11px] text-[#4a5568] mt-1">Ready to deploy</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">TOTAL INJECTED</div>
              <div className="text-2xl font-bold text-emerald-400 mt-1">{flywheel.totalInjected.toFixed(2)} SOL</div>
              <div className="text-[11px] text-[#4a5568] mt-1">Lifetime SOL deployed</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">TOKENS BURNED</div>
              <div className="text-2xl font-bold text-red-400 mt-1">{(flywheel.tokensBurned / 1e6).toFixed(1)}M</div>
              <div className="text-[11px] text-[#4a5568] mt-1">Permanently destroyed</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">BONDING PROGRESS</div>
              <div className="text-2xl font-bold text-[#a78bfa] mt-1">{token.bondingPct.toFixed(1)}%</div>
              <div className="text-[11px] text-[#4a5568] mt-1">→ 85 SOL graduation</div>
            </div>
          </div>

          {/* Manual Injection Controls */}
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white">Manual Injection Controls</h3>
            <div className="flex flex-col sm:flex-row items-end gap-3 font-mono text-xs">
              <div className="flex-1 w-full">
                <label className="block text-[#8a9bb4] mb-1.5">Injection Size (SOL)</label>
                <input
                  type="number"
                  step="0.01"
                  value={injectionAmount}
                  onChange={(e) => setInjectionAmount(e.target.value)}
                  className="w-full bg-[#111827] border border-[#27374f] rounded-xl px-3.5 py-2 text-white font-bold"
                />
              </div>

              <div className="flex-1 w-full text-xs text-[#8a9bb4]">
                <div>Governor window: 0.50 SOL / 60 min</div>
                <div className="text-emerald-400 font-bold mt-1">
                  Window: {flywheel.windowInjected.toFixed(3)} / 0.50 SOL used
                </div>
              </div>

              <button
                type="button"
                onClick={handleInject}
                disabled={loading || emergencyStop}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-[#ffd60a] hover:bg-[#ffe74d] text-[#060a12] font-bold shadow-md transition-all"
              >
                ⚡ Execute Buyback Injection
              </button>
            </div>
          </div>

          {/* YABBAI Auto-Feed Toggle */}
          <div className="rounded-2xl bg-[#0b1018] border border-emerald-500/20 p-6 shadow-xl flex items-center justify-between gap-4">
            <div>
              <h4 className="text-sm font-bold text-white">YABBAI → Pump Auto-Feed</h4>
              <p className="text-xs text-[#8a9bb4] mt-0.5">
                Each verified REAL event automatically routes 20% of net profit to the buyback reserve
              </p>
            </div>

            <button
              type="button"
              onClick={handleToggleAutoFeed}
              className={`w-12 h-6 rounded-full transition-colors relative ${autoFeed ? 'bg-emerald-500' : 'bg-[#1c2539]'}`}
            >
              <span
                className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${autoFeed ? 'right-1' : 'left-1'}`}
              />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: SYNDICATE WALLETS & NETWORK HOT WALLETS
      ======================================================== */}
      {activeTab === 'syndicate' && (
        <HotWalletsNetworkView
          walletSolBalance={walletSolBalance}
          onNavigateTab={onNavigateToTools}
        />
      )}

      {/* ========================================================
          VIEW: VOLUME BOT
      ======================================================== */}
      {activeTab === 'volumebot' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">VOLUME GENERATED</div>
              <div className="text-2xl font-bold text-emerald-400 mt-1">8.64 SOL</div>
              <div className="text-[11px] text-[#4a5568] mt-1">Total Solana generated</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">TRADES EXECUTED</div>
              <div className="text-2xl font-bold text-cyan-400 mt-1">142</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">BUY RATIO</div>
              <div className="text-2xl font-bold text-amber-400 mt-1">58%</div>
            </div>
            <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-4">
              <div className="text-[11px] text-[#8a9bb4]">ACTIVE WALLETS</div>
              <div className="text-2xl font-bold text-purple-400 mt-1">6</div>
            </div>
          </div>

          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Volume Generator Controls</h3>
              <button
                type="button"
                onClick={handleTriggerVolumeBurst}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs"
              >
                ⚡ 0.5 SOL Volume Burst
              </button>
            </div>

            <div className="space-y-2 font-mono text-xs">
              {volumeFeed.map((v, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-[#111827] border border-[#1f2a3a] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${v.type === 'BUY' ? 'bg-emerald-950 text-emerald-400' : 'bg-red-950 text-red-400'}`}>
                      {v.type}
                    </span>
                    <span className="text-white font-bold">{v.sol} SOL</span>
                    <span className="text-[#8a9bb4]">{v.wallet}</span>
                  </div>
                  <span className="text-[#4a5568]">{Math.floor((Date.now() - v.time) / 1000)}s ago</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: 21-AGENT FLEET
      ======================================================== */}
      {activeTab === 'agents' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-white">21-Agent Fleet Matrix</h3>
              <p className="text-xs text-[#8a9bb4]">Autonomous squads with bounded risk envelopes</p>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <input
                type="text"
                placeholder="Search agents..."
                value={agentSearch}
                onChange={(e) => setAgentSearch(e.target.value)}
                className="bg-[#111827] border border-[#27374f] rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:outline-none"
              />
              <select
                value={agentSquadFilter}
                onChange={(e) => setAgentSquadFilter(e.target.value)}
                className="bg-[#111827] border border-[#27374f] rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:outline-none"
              >
                <option value="ALL">All Squads</option>
                <option value="DISCOVERY">Scout & Intel</option>
                <option value="EXECUTION">Execution</option>
                <option value="VERIFICATION">Verification</option>
                <option value="TREASURY">Treasury</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 font-mono text-xs">
            {filteredAgents.map((a) => (
              <div key={a.id} className="p-4 rounded-2xl bg-[#0b1018] border border-[#1f2a3a] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-white truncate">{a.name}</div>
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                </div>
                <div className="text-[10px] text-[#8a9bb4]">{a.id} · {a.role}</div>
                <div className="flex flex-wrap gap-1">
                  {a.capabilities.slice(0, 2).map((c, i) => (
                    <span key={i} className="px-1.5 py-0.5 rounded bg-[#111827] text-[9px] text-[#8a9bb4]">
                      {c}
                    </span>
                  ))}
                </div>
                <div className="text-[10px] text-[#4a5568] pt-1 border-t border-[#1f2a3a]">
                  Risk: {a.risk} · Budget: {a.budget === 0 ? 'ZERO' : a.budget + ' SOL/h'}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: JARVIS AI
      ======================================================== */}
      {activeTab === 'jarvis' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-[#0b1018] border border-[#1f2a3a] p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">JARVIS AI Analysis</h3>
                <p className="text-xs text-[#8a9bb4]">Real-time DeFi and bonding curve strategic synthesis</p>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={jarvisMode}
                  onChange={(e) => setJarvisMode(e.target.value)}
                  className="bg-[#111827] border border-[#27374f] rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:outline-none"
                >
                  <option value="strategy">Revenue Strategy</option>
                  <option value="pump">Pump Optimization</option>
                  <option value="opportunities">Opportunity Scoring</option>
                  <option value="treasury">Treasury Health</option>
                  <option value="mining">Mining ROI</option>
                </select>

                <button
                  type="button"
                  onClick={handleAskJarvis}
                  disabled={jarvisRunning}
                  className="px-4 py-1.5 rounded-xl bg-[#ffd60a] hover:bg-[#ffe74d] text-[#060a12] font-mono font-bold text-xs"
                >
                  {jarvisRunning ? 'Synthesizing...' : 'Ask JARVIS'}
                </button>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#060a12] border border-cyan-500/30 text-xs font-mono text-cyan-300 leading-relaxed whitespace-pre-wrap min-h-32">
              {jarvisOutput}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          VIEW: LEDGER
      ======================================================== */}
      {activeTab === 'ledger' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-white">Transaction Ledger</h3>

            <div className="flex items-center gap-1.5 bg-[#0b1018] border border-[#1f2a3a] p-1 rounded-xl text-xs font-mono">
              {(['all', 'injection', 'allocation', 'real'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setLedgerFilter(f)}
                  className={`px-3 py-1 rounded-lg uppercase font-bold transition-all ${
                    ledgerFilter === f ? 'bg-[#ffd60a] text-[#060a12]' : 'text-[#8a9bb4] hover:text-white'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {filteredLedger.map((l, idx) => (
              <div key={`${l.id || 'tx'}-${idx}`} className="p-3.5 rounded-xl bg-[#0b1018] border border-[#1f2a3a] flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-white font-bold truncate">{l.details}</div>
                  <div className="text-[10px] text-[#8a9bb4] flex items-center gap-2 mt-0.5">
                    <span className="text-emerald-400 font-bold">{l.truthClass || 'REAL'}</span>
                    <span>·</span>
                    <span>{l.source}</span>
                    {l.txSignature && (
                      <a
                        href={`https://solscan.io/tx/${l.txSignature}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#38bdf8] hover:underline flex items-center gap-0.5"
                      >
                        <span>{l.txSignature.slice(0, 10)}...</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className={`font-bold ${l.type === 'injection' ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {l.type === 'injection' ? '-' : '+'}
                    {l.amountSol.toFixed(4)} SOL
                  </div>
                  <div className="text-[10px] text-[#4a5568]">
                    {Math.floor((Date.now() - l.timestamp) / 60000)}m ago
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
