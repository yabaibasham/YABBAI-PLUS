import React, { useState, useEffect } from 'react';
import {
  Flame,
  Rocket,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Coins,
  Copy,
  Check,
  TrendingUp,
  Share2,
  Users,
  Clock,
  Zap,
  ArrowRight,
  Send,
  Lock,
} from 'lucide-react';
import { OMEGA_ASSETS } from './omegaAssets';
import type { WalletState } from '../../types';
import { PumpTradeTerminal } from '../idx/PumpTradeTerminal';

interface BashamMemeLaunchViewProps {
  wallet: WalletState;
  onNavigateToStaking?: () => void;
  onNavigateToCreatePool?: () => void;
  onNavigateToAITaskForce?: () => void;
}

export const BashamMemeLaunchView: React.FC<BashamMemeLaunchViewProps> = ({
  wallet,
  onNavigateToStaking,
  onNavigateToCreatePool,
  onNavigateToAITaskForce,
}) => {
  const [copied, setCopied] = useState(false);
  const [whitelistJoined, setWhitelistJoined] = useState(false);
  const [whitelistCount, setWhitelistCount] = useState(14820);
  const [userEmail, setUserEmail] = useState('');

  // Countdown timer to the big launch
  const [timeLeft, setTimeLeft] = useState({
    days: 2,
    hours: 14,
    minutes: 36,
    seconds: 45,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCopyContract = () => {
    navigator.clipboard?.writeText(OMEGA_ASSETS.contractAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleJoinWhitelist = (e: React.FormEvent) => {
    e.preventDefault();
    setWhitelistJoined(true);
    setWhitelistCount((prev) => prev + 1);
  };

  const tweetText = encodeURIComponent(
    `Get ready for the best meme coin to ever exist: $BASHAM (Omega Alien) launching on Solana! Official updates dropping on @omegaalienmeme 🚀👽\n\nStaking vaults active & fair launch incoming! https://x.com/omegaalienmeme`
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Hero Showcase Banner */}
      <div className="relative rounded-3xl p-6 sm:p-10 bg-gradient-to-br from-[#0c0f1d] via-[#101426] to-[#180f2d] border border-[#232a47] shadow-2xl overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-purple-500/15 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute top-1/2 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px] pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Text & Pitch */}
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-500/20 to-cyan-500/20 border border-purple-500/40 text-purple-300 text-xs font-mono font-bold tracking-wider">
              <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" />
              <span>THE BEST SOLANA MEME COIN TO EVER EXIST</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.08]">
              MEET <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-500 bg-clip-text text-transparent">BASHAM</span>
              <br />
              <span className="text-2xl sm:text-3xl lg:text-4xl text-[#94a3b8] font-extrabold font-mono">
                THE OMEGA ALIEN
              </span>
            </h1>

            <p className="text-sm sm:text-base text-[#94a3b8] font-mono max-w-xl leading-relaxed">
              We are launching the most viral, liquidity-backed meme token in Solana history very shortly. Autonomous Raydium buyback flywheel, unMineable revenue injections, and StakePoint high-yield vaults.
            </p>

            {/* Official Announcement Strip */}
            <div className="p-3.5 rounded-2xl bg-[#090d18]/90 border border-[#1f2b45] flex items-center justify-between gap-3 max-w-xl">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center font-bold">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </div>
                <div>
                  <div className="text-[10px] font-mono uppercase text-[#64748b]">Official Announcement Channel</div>
                  <div className="text-xs font-mono font-extrabold text-white">x.com/omegaalienmeme</div>
                </div>
              </div>

              <a
                href={OMEGA_ASSETS.xAccount}
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-200 text-black text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-md"
              >
                <span>Follow Updates</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href={`https://twitter.com/intent/tweet?text=${tweetText}`}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-mono text-xs font-extrabold shadow-lg shadow-cyan-950/50 flex items-center gap-2 transition-all hover:scale-[1.02]"
              >
                <Share2 className="w-4 h-4" />
                <span>Spread the Word on X</span>
              </a>

              {onNavigateToStaking && (
                <button
                  onClick={onNavigateToStaking}
                  className="px-5 py-3 rounded-xl bg-[#141b2c] hover:bg-[#1c273e] border border-[#2b3a5c] text-white font-mono text-xs font-bold flex items-center gap-2 transition-all"
                >
                  <Coins className="w-4 h-4 text-cyan-400" />
                  <span>Explore Staking Pools</span>
                </button>
              )}
            </div>
          </div>

          {/* Right Mascot & Launch Countdown */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center">
            {/* Hologram Mascot Card */}
            <div className="relative w-full max-w-sm rounded-3xl p-5 bg-[#090d19]/90 border border-[#243353] shadow-2xl space-y-4">
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-gradient-to-tr from-cyan-950 to-purple-950 flex items-center justify-center border border-[#1d2a45]">
                <img
                  src={OMEGA_ASSETS.mascotHero || OMEGA_ASSETS.logo}
                  alt="Omega Alien Mascot"
                  className="w-full h-full object-contain p-4 filter drop-shadow-[0_10px_20px_rgba(56,189,248,0.35)]"
                />
                <div className="absolute top-3 left-3 px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[10px] font-mono font-bold">
                  $BASHAM MASCOT
                </div>
                <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>PRE-LAUNCH SYNDICATE</span>
                </div>
              </div>

              {/* Countdown Ticker */}
              <div className="p-3.5 rounded-2xl bg-[#060a12] border border-[#172033] space-y-2">
                <div className="text-[10px] font-mono uppercase text-[#64748b] text-center tracking-wider">
                  Public Fair Launch Countdown
                </div>
                <div className="grid grid-cols-4 gap-2 text-center font-mono">
                  <div className="p-2 rounded-xl bg-[#0e1422] border border-[#1c273e]">
                    <div className="text-xl font-black text-white">{timeLeft.days}</div>
                    <div className="text-[9px] text-[#64748b] uppercase">Days</div>
                  </div>
                  <div className="p-2 rounded-xl bg-[#0e1422] border border-[#1c273e]">
                    <div className="text-xl font-black text-white">{timeLeft.hours}</div>
                    <div className="text-[9px] text-[#64748b] uppercase">Hours</div>
                  </div>
                  <div className="p-2 rounded-xl bg-[#0e1422] border border-[#1c273e]">
                    <div className="text-xl font-black text-white">{timeLeft.minutes}</div>
                    <div className="text-[9px] text-[#64748b] uppercase">Mins</div>
                  </div>
                  <div className="p-2 rounded-xl bg-[#0e1422] border border-[#1c273e]">
                    <div className="text-xl font-black text-cyan-400">{timeLeft.seconds}</div>
                    <div className="text-[9px] text-[#64748b] uppercase">Secs</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contract & Tokenomics Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Tokenomics Card 1 */}
        <div className="p-5 rounded-2xl bg-[#080d17] border border-[#192338] space-y-2">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center">
            <Coins className="w-5 h-5" />
          </div>
          <h3 className="text-base font-extrabold text-white font-mono">1,000,000,000 Supply</h3>
          <p className="text-xs text-[#8a93a8] font-mono leading-relaxed">
            100% of supply deposited directly to fair launch bonding curve and Raydium CPMM. Zero team dumps, zero VC lockups.
          </p>
        </div>

        {/* Tokenomics Card 2 */}
        <div className="p-5 rounded-2xl bg-[#080d17] border border-[#192338] space-y-2">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-extrabold text-white font-mono">0% Tax · Revoked Mint</h3>
          <p className="text-xs text-[#8a93a8] font-mono leading-relaxed">
            Freeze authority and mint authority permanently revoked on-chain via SPL Token Program. Verified clean audit.
          </p>
        </div>

        {/* Tokenomics Card 3 */}
        <div className="p-5 rounded-2xl bg-[#080d17] border border-[#192338] space-y-2">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 flex items-center justify-center">
            <Flame className="w-5 h-5" />
          </div>
          <h3 className="text-base font-extrabold text-white font-mono">100% LP Burnt at Graduation</h3>
          <p className="text-xs text-[#8a93a8] font-mono leading-relaxed">
            Upon reaching the 85 SOL Raydium graduation target, all liquidity tokens are sent to incinerator burn address forever.
          </p>
        </div>
      </div>

      {/* Contract Address Copy Box */}
      <div className="p-5 rounded-2xl bg-[#090e1a] border border-[#1b263e] shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="text-[10px] font-mono uppercase text-[#64748b] tracking-wider">
            Verified Mint Authority / Contract Address
          </div>
          <div className="text-xs sm:text-sm font-mono font-bold text-white mt-1 break-all">
            {OMEGA_ASSETS.contractAddress}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyContract}
            className="px-4 py-2 rounded-xl bg-[#141d30] hover:bg-[#1d2b48] border border-[#233454] text-cyan-300 font-mono text-xs font-bold flex items-center gap-2 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Mint' : 'Copy Address'}</span>
          </button>
          <a
            href={`https://solscan.io/token/${OMEGA_ASSETS.contractAddress}`}
            target="_blank"
            rel="noreferrer"
            className="p-2 rounded-xl bg-[#141d30] hover:bg-[#1d2b48] border border-[#233454] text-[#8a93a8] hover:text-white transition-colors"
            title="Inspect on Solscan"
          >
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Gemini 4 Argon Autonomous AI Market Dominance */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-[#091122] via-[#0b152d] to-[#120f26] border border-amber-500/30 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 font-bold">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>ARGON 4 AUTONOMOUS ENGINE · TAKING OVER SOLANA</span>
            <span className="text-slate-500">·</span>
            <span className="text-emerald-400">1M Deep Reasoning Core Active</span>
          </div>
          <p className="text-xs text-[#8a9bb4] font-mono leading-relaxed max-w-2xl">
            Google Gemini 4 Argon runs 24/7 continuous bonding curve velocity models, liquidity vacuuming, and automated MEV sandwich defense for $BASHAM.
          </p>
        </div>
        {onNavigateToAITaskForce && (
          <button
            onClick={onNavigateToAITaskForce}
            className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#060a12] font-mono text-xs font-extrabold flex items-center gap-2 shadow-lg shadow-amber-950/40 shrink-0 transition-all active:scale-95"
          >
            <span>Deploy Argon 4 Matrix</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Solana Anchor Smart Contract & Swap Execution Component */}
      <div className="pt-2">
        <PumpTradeTerminal
          mintAddress="svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3"
          tokenSymbol="BASHAM"
          tokenName="Basham Meme Coin"
          onGraduated={() => {
            if (onNavigateToCreatePool) onNavigateToCreatePool();
          }}
        />
      </div>

      {/* Whitelist / Early Syndicate Signup */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0c1424] to-[#120f26] border border-[#233352] shadow-xl relative overflow-hidden">
        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono font-bold">
            <Users className="w-3.5 h-3.5" />
            <span>JOIN THE 14,800+ MEME SYNDICATE</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
            Get Instant Launch Whitelist Alert
          </h2>

          <p className="text-xs sm:text-sm text-[#94a3b8] font-mono leading-relaxed">
            The moment $BASHAM liquidity goes live on pump.fun and Raydium, our automated alert bot pings your wallet and Telegram/X accounts so you never miss the bonding curve floor.
          </p>

          {whitelistJoined ? (
            <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-mono text-xs flex items-center gap-3">
              <Check className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <div className="font-bold">You are confirmed in the $BASHAM Syndicate!</div>
                <div className="text-[11px] text-emerald-400/80">
                  Wallet {wallet.formattedAddress} registered. Keep notifications on at x.com/omegaalienmeme.
                </div>
              </div>
            </div>
          ) : (
            <form onSubmit={handleJoinWhitelist} className="flex flex-col sm:flex-row gap-2.5 pt-2">
              <input
                type="text"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                placeholder="Enter your X handle or wallet address..."
                required
                className="flex-1 bg-[#070b13] border border-[#1f2d47] rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-[#64748b] focus:outline-none focus:border-cyan-500"
              />
              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-bold shadow-md shadow-cyan-950/40 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
              >
                <Send className="w-4 h-4" />
                <span>Reserve Early Access</span>
              </button>
            </form>
          )}

          <div className="text-[11px] text-[#64748b] font-mono flex items-center gap-2">
            <span>{whitelistCount.toLocaleString()} traders reserved</span>
            <span>•</span>
            <span>Free Syndicate Access</span>
          </div>
        </div>
      </div>
    </div>
  );
};
