// Exact client-side math mirroring the on-chain Rust Anchor contract (programs/meme-pump-engine)

export const BPS_DENOMINATOR = 10_000;
export const GRADUATION_THRESHOLD_LAMPORTS = 86_000_000_000; // 86 SOL

export interface BuyQuoteResult {
  tokensOut: number;
  netSol: number;
  feeSol: number;
  pricePerTokenSol: number;
  slippageMinTokensOut: number;
}

export interface SellQuoteResult {
  grossSolOut: number;
  netSolOut: number;
  feeSol: number;
  pricePerTokenSol: number;
  slippageMinSolOut: number;
}

/**
 * Computes exact output tokens and fees for a Buy order
 * Formula:
 * fee = solAmount * feeBps / 10,000
 * netSol = solAmount - fee
 * k = virtualSol * virtualToken
 * newVirtualSol = virtualSol + netSol
 * newVirtualToken = k / newVirtualSol
 * tokensOut = virtualToken - newVirtualToken
 */
export function computeBuyQuote(
  virtualSolReserves: number,
  virtualTokenReserves: number,
  solAmountLamports: number,
  feeBps: number = 50,
  slippageBps: number = 100
): BuyQuoteResult {
  if (solAmountLamports <= 0 || virtualSolReserves <= 0 || virtualTokenReserves <= 0) {
    return { tokensOut: 0, netSol: 0, feeSol: 0, pricePerTokenSol: 0, slippageMinTokensOut: 0 };
  }

  const fee = Math.floor((solAmountLamports * feeBps) / BPS_DENOMINATOR);
  const net = solAmountLamports - fee;

  const k = BigInt(Math.floor(virtualSolReserves)) * BigInt(Math.floor(virtualTokenReserves));
  const newVirtualSol = BigInt(Math.floor(virtualSolReserves)) + BigInt(net);
  const newVirtualToken = k / newVirtualSol;
  const tokensOutBig = BigInt(Math.floor(virtualTokenReserves)) - newVirtualToken;

  const tokensOut = Number(tokensOutBig);
  const minTokens = Math.floor(tokensOut * (1 - slippageBps / BPS_DENOMINATOR));
  const price = tokensOut > 0 ? (solAmountLamports / 1e9) / (tokensOut / 1e6) : 0;

  return {
    tokensOut,
    netSol: net,
    feeSol: fee,
    pricePerTokenSol: price,
    slippageMinTokensOut: minTokens,
  };
}

/**
 * Computes exact output SOL and fees for a Sell order
 * Formula:
 * k = virtualSol * virtualToken
 * newVirtualToken = virtualToken + tokenAmount
 * newVirtualSol = k / newVirtualToken
 * grossSolOut = virtualSol - newVirtualSol
 * fee = grossSolOut * feeBps / 10,000
 * netSolOut = grossSolOut - fee
 */
export function computeSellQuote(
  virtualSolReserves: number,
  virtualTokenReserves: number,
  tokenAmount: number,
  feeBps: number = 50,
  slippageBps: number = 100
): SellQuoteResult {
  if (tokenAmount <= 0 || virtualSolReserves <= 0 || virtualTokenReserves <= 0) {
    return { grossSolOut: 0, netSolOut: 0, feeSol: 0, pricePerTokenSol: 0, slippageMinSolOut: 0 };
  }

  const k = BigInt(Math.floor(virtualSolReserves)) * BigInt(Math.floor(virtualTokenReserves));
  const newVirtualToken = BigInt(Math.floor(virtualTokenReserves)) + BigInt(Math.floor(tokenAmount));
  const newVirtualSol = k / newVirtualToken;
  const grossSolOutBig = BigInt(Math.floor(virtualSolReserves)) - newVirtualSol;

  const gross = Number(grossSolOutBig);
  const fee = Math.floor((gross * feeBps) / BPS_DENOMINATOR);
  const net = Math.max(0, gross - fee);
  const minSol = Math.floor(net * (1 - slippageBps / BPS_DENOMINATOR));
  const price = tokenAmount > 0 ? (gross / 1e9) / (tokenAmount / 1e6) : 0;

  return {
    grossSolOut: gross,
    netSolOut: net,
    feeSol: fee,
    pricePerTokenSol: price,
    slippageMinSolOut: minSol,
  };
}
