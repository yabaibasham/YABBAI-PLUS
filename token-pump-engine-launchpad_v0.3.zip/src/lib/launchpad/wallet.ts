import { Buffer } from 'buffer';
import { ComputeBudgetProgram, Keypair, PublicKey, Transaction, TransactionInstruction } from '@solana/web3.js';

/**
 * Browser wallet helpers for the launchpad. The wallet (Phantom, Solflare…) signs; the server
 * only relays the signed bytes to the RPC and waits for confirmation.
 */

interface InjectedWallet {
  publicKey?: { toString(): string } | null;
  connect: (opts?: { onlyIfTrusted?: boolean }) => Promise<{ publicKey?: { toString(): string } } | void>;
  signTransaction: (tx: Transaction) => Promise<Transaction>;
}

export function getWallet(): InjectedWallet | null {
  const w = window as any;
  return w.phantom?.solana ?? w.solflare ?? w.solana ?? null;
}

export async function connectWallet(onlyIfTrusted = false): Promise<PublicKey | null> {
  const wallet = getWallet();
  if (!wallet) {
    if (onlyIfTrusted) return null;
    throw new Error('No Solana wallet found in this browser. Install Phantom and refresh.');
  }
  try {
    const res = await wallet.connect(onlyIfTrusted ? { onlyIfTrusted: true } : undefined);
    const key = (res && res.publicKey) || wallet.publicKey;
    return key ? new PublicKey(key.toString()) : null;
  } catch (e) {
    if (onlyIfTrusted) return null;
    throw e;
  }
}

export function explorerUrl(kind: 'tx' | 'account' | 'token', id: string, cluster: string) {
  return `https://solscan.io/${kind}/${id}${cluster === 'devnet' ? '?cluster=devnet' : ''}`;
}

/** Builds the transaction, has the wallet sign it, adds any extra signers, and relays it. */
export async function signAndRelay(opts: {
  feePayer: PublicKey;
  instructions: TransactionInstruction[];
  extraSigners?: Keypair[];
  computeUnits?: number;
  priorityMicroLamports?: number;
}): Promise<string> {
  const wallet = getWallet();
  if (!wallet) throw new Error('Connect a wallet first.');

  const bh = await fetch('/api/launchpad/blockhash').then((r) => r.json());
  if (!bh?.blockhash) throw new Error(bh?.error || 'Could not get a recent blockhash from the RPC.');

  const tx = new Transaction({ feePayer: opts.feePayer, blockhash: bh.blockhash, lastValidBlockHeight: bh.lastValidBlockHeight });
  tx.add(ComputeBudgetProgram.setComputeUnitLimit({ units: opts.computeUnits ?? 200_000 }));
  if (opts.priorityMicroLamports) tx.add(ComputeBudgetProgram.setComputeUnitPrice({ microLamports: opts.priorityMicroLamports }));
  tx.add(...opts.instructions);

  // The wallet signs first; extra keypairs (e.g. the new token's mint) sign afterwards,
  // which is the order Phantom asks dapps to use.
  const signed = await wallet.signTransaction(tx);
  for (const kp of opts.extraSigners ?? []) signed.partialSign(kp);

  const res = await fetch('/api/launchpad/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tx: Buffer.from(signed.serialize()).toString('base64') }),
  }).then((r) => r.json());
  if (!res?.ok) {
    const err = new Error(res?.error || 'Transaction failed.') as Error & { signature?: string };
    err.signature = res?.signature;
    throw err;
  }
  return res.signature as string;
}

// end of src/lib/launchpad/wallet.ts
