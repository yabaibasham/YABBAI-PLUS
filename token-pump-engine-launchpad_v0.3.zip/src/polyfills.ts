// Some Solana packages read the global `Buffer` while they load, and browsers don't have one.
// main.tsx imports this file first, so Buffer exists before any of those packages run.
import { Buffer } from 'buffer';

const g = globalThis as typeof globalThis & { Buffer?: typeof Buffer };
if (!g.Buffer) g.Buffer = Buffer;
