#!/usr/bin/env bash
# Build and deploy the launchpad program with the Anchor CLI. See DEPLOY.md for the full walkthrough.
#   ./scripts/deploy.sh devnet        (free: uses devnet SOL from the faucet)
#   ./scripts/deploy.sh mainnet-beta  (costs real SOL; do this only after testing on devnet)
set -euo pipefail
CLUSTER="${1:-devnet}"

command -v solana >/dev/null || { echo "Solana CLI missing: sh -c \"\$(curl -sSfL https://release.anza.xyz/stable/install)\""; exit 1; }
command -v anchor >/dev/null || { echo "Anchor CLI missing: cargo install --git https://github.com/coral-xyz/anchor avm --locked && avm install 0.30.1 && avm use 0.30.1"; exit 1; }

echo "Deployer wallet: $(solana address)  (this wallet becomes the upgrade authority and the only one allowed to initialize)"
echo "Balance on $CLUSTER: $(solana balance --url "$CLUSTER")"

echo "Running program tests..."
cargo test -p meme-pump-engine --features test-mode

echo "Building (default features only, never test-mode)..."
anchor build

PROGRAM_ID="$(solana address -k target/deploy/meme_pump_engine-keypair.json)"
echo "Program ID: $PROGRAM_ID"
grep -q "$PROGRAM_ID" programs/meme-pump-engine/src/lib.rs || {
  echo "declare_id! in lib.rs does not match target/deploy/meme_pump_engine-keypair.json. Run 'anchor keys sync', rebuild, and set LAUNCHPAD_PROGRAM_ID."
  exit 1
}

anchor deploy --provider.cluster "$CLUSTER"
echo "Deployed. Next: open the app's Launchpad > Platform tab with this deployer wallet in Phantom and press Initialize."
