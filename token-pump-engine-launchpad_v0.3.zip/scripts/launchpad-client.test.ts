/**
 * Checks src/lib/launchpad/client.ts against byte-level vectors exported by the Rust program tests.
 *   cargo test -p meme-pump-engine --features test-mode   # writes target/launchpad-vectors.json
 *   npx tsx scripts/launchpad-client.test.ts
 */
import { readFileSync } from 'fs';
import * as L from '../src/lib/launchpad/client';

const v = JSON.parse(readFileSync(new URL('../target/launchpad-vectors.json', import.meta.url), 'utf8'));
let fails = 0;
let passes = 0;
const check = (name: string, ok: boolean, detail = '') => {
  if (ok) passes++;
  else {
    fails++;
    console.log(`FAIL ${name} ${detail}`);
  }
};
const hex = (b: Uint8Array) => Buffer.from(b).toString('hex');
const k = v.keys;

// PDAs
const P = L.launchpadPdas(v.programId);
for (const [name, got] of Object.entries({
  global: P.global, mintAuthority: P.mintAuthority, programData: P.programData, curve: P.curve(k.mint),
  launch7: P.launchRecord(7), metadata: P.metadata(k.mint), vault: P.vault(k.mint),
})) check(`pda ${name}`, got.toBase58() === v.pdas[name], `${got.toBase58()} != ${v.pdas[name]}`);

// Instructions: identical bytes and identical account lists
const I = L.launchpadInstructions(v.programId);
const D = L.DEFAULT_CURVE;
const built: Record<string, ReturnType<typeof I.buy>> = {
  initializeGlobal: I.initializeGlobal(k.creator, { feeRecipient: k.fee, migrationAuthority: k.migrator, feeBps: 100, creatorFeeShareBps: 3000, ...D }),
  updateGlobal: I.updateGlobal(k.creator, { feeRecipient: k.fee, feeBps: 250, creatorFeeShareBps: 4000, paused: true, tokenTotalSupply: D.tokenTotalSupply }),
  launchToken: I.launchToken(k.creator, k.mint, 7, 'Burn City', 'BURN', 'https://example.com/burn.json'),
  buy: I.buy(k.buyer, k.fee, k.mint, 1_500_000_000n, 123_456n),
  sell: I.sell(k.buyer, k.fee, k.mint, 987_654_321n, 42n),
  claimCreatorFees: I.claimCreatorFees(k.creator, k.mint),
  withdrawForMigration: I.withdrawForMigration(k.migrator, k.mint),
  recordMigrationPool: I.recordMigrationPool(k.migrator, k.mint, k.pool),
};
for (const want of v.instructions) {
  const got = built[want.name];
  check(`ix ${want.name} program`, got.programId.toBase58() === v.programId);
  check(`ix ${want.name} data`, hex(got.data) === want.data, `\n got ${hex(got.data)}\nwant ${want.data}`);
  const gotKeys = got.keys.map((m) => ({ pubkey: m.pubkey.toBase58(), isSigner: m.isSigner, isWritable: m.isWritable }));
  const norm = (a: { pubkey: string; isSigner: boolean; isWritable: boolean }[]) => a.map((m) => `${m.pubkey}:${m.isSigner}:${m.isWritable}`).join('|');
  check(`ix ${want.name} accounts`, norm(gotKeys) === norm(want.accounts), norm(gotKeys));
}

// Account decoding
const bytes = (h: string) => Uint8Array.from(Buffer.from(h, 'hex'));
const g = L.decodeGlobal(bytes(v.accounts.global));
check('decode Global', g.authority === k.creator && g.feeRecipient === k.fee && g.migrationAuthority === k.migrator && g.feeBps === 100 && g.creatorFeeShareBps === 3000 &&
  g.paused && g.initialVirtualSolReserves === D.initialVirtualSolReserves && g.initialRealTokenReserves === D.initialRealTokenReserves &&
  g.tokenTotalSupply === D.tokenTotalSupply && g.launchCount === 12n && g.bump === 254, JSON.stringify(g, (_, x) => (typeof x === 'bigint' ? `${x}` : x)));
const c = L.decodeCurve(bytes(v.accounts.curve));
check('decode CurveState', c.mint === k.mint && c.creator === k.creator && c.launchIndex === 3n && c.createdAt === 1_793_000_000n &&
  c.virtualSolReserves === 31_000_000_000n && c.realSolReserves === 1_000_000_000n && c.realTokenReserves === 758_100_000_000_000n &&
  c.initialRealTokenReserves === D.initialRealTokenReserves && c.volumeLamports === 5_000_000_000n && c.feesLamports === 50_000_000n &&
  c.creatorFeesLamports === 15_000_000n && c.creatorFeesClaimed === 4_000_000n && L.unclaimedCreatorFees(c) === 11_000_000n &&
  c.tradeCount === 9n && !c.complete && c.migrated && c.migrationSol === 7n && c.migrationTokens === 8n && c.migrationPool === k.pool && c.bump === 253,
  JSON.stringify(c, (_, x) => (typeof x === 'bigint' ? `${x}` : x)));
const r = L.decodeLaunchRecord(bytes(v.accounts.launchRecord));
check('decode LaunchRecord', r.index === 3n && r.mint === k.mint && r.creator === k.creator && r.createdAt === 1_793_000_000n && r.bump === 252);
let threw = false;
try { L.decodeCurve(bytes(v.accounts.global)); } catch { threw = true; }
check('decoder rejects the wrong account type', threw);

// Curve math: same numbers and same errors as Rust
const rustErr = (s: string) => (s.match(/Error Code: (\w+)/) || s.match(/error_name: "(\w+)"/) || [])[1];
const big = (o: Record<string, string>) => Object.fromEntries(Object.entries(o).map(([a, b]) => [a, typeof b === 'string' ? BigInt(b) : b]));
for (const t of v.math.buy) {
  const run = () => L.quoteBuy(BigInt(t.virtualSol), BigInt(t.virtualToken), BigInt(t.realToken), t.feeBps, BigInt(t.maxSolIn));
  if (t.result.error) {
    let code = '';
    try { run(); } catch (e: any) { code = e.code; }
    check(`buy error ${t.maxSolIn}`, code === rustErr(t.result.error), `${code} vs ${t.result.error}`);
  } else {
    const q = run();
    const want = big(t.result);
    check(`buy ${t.maxSolIn}`, q.solIn === want.solIn && q.fee === want.fee && q.tokensOut === want.tokensOut &&
      q.newVirtualSol === want.newVirtualSol && q.newVirtualToken === want.newVirtualToken && q.completes === t.result.completes);
  }
}
for (const t of v.math.sell) {
  const run = () => L.quoteSell(BigInt(t.virtualSol), BigInt(t.virtualToken), BigInt(t.realSol), t.feeBps, BigInt(t.tokenAmount));
  if (t.result.error) {
    let code = '';
    try { run(); } catch (e: any) { code = e.code; }
    check(`sell error ${t.tokenAmount}`, code === rustErr(t.result.error), `${code} vs ${t.result.error}`);
  } else {
    const q = run();
    const want = big(t.result);
    check(`sell ${t.tokenAmount}`, q.solOutGross === want.solOutGross && q.fee === want.fee && q.solOutNet === want.solOutNet &&
      q.newVirtualSol === want.newVirtualSol && q.newVirtualToken === want.newVirtualToken);
  }
}

// Fee split: same platform/creator split as Rust
for (const t of v.math.split) {
  const got = L.splitFee(BigInt(t.fee), t.shareBps);
  check(`split ${t.fee}/${t.shareBps}`, got.platform === BigInt(t.platform) && got.creator === BigInt(t.creator), `${got.platform}/${got.creator}`);
}

// Budget helper: never overspends, never leaves a whole lamport of curve input unused
for (let i = 0; i < 2000; i++) {
  const total = BigInt(Math.floor(Math.random() * 5e10)) + 1n;
  const bps = Math.floor(Math.random() * 501);
  const s = L.solInForBudget(total, bps);
  const ok = s + L.feeOn(s, bps) <= total && s + 1n + L.feeOn(s + 1n, bps) > total;
  if (!ok) { check(`solInForBudget ${total}/${bps}`, false); break; }
}
check('solInForBudget property', true);
check('progressPct', L.progressPct({ realTokenReserves: 0n, initialRealTokenReserves: 5n }) === 100 &&
  L.progressPct({ realTokenReserves: D.initialRealTokenReserves, initialRealTokenReserves: D.initialRealTokenReserves }) === 0);
const toComplete = L.solToComplete({ virtualSolReserves: D.initialVirtualSolReserves, virtualTokenReserves: D.initialVirtualTokenReserves, realTokenReserves: D.initialRealTokenReserves });
check('solToComplete matches a capped buy', toComplete === BigInt(v.math.buy[3].result.solIn), `${toComplete}`);
check('describeProgramError', L.describeProgramError('failed: custom program error: 0x1775').startsWith('Price moved'));

console.log(`${passes} passed, ${fails} failed`);
process.exit(fails ? 1 : 0);
