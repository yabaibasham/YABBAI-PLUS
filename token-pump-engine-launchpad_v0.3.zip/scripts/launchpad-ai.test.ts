/**
 * Runs the discovery / growth / risk-report layer against account bytes written by the real program
 * (target/launchpad-snapshot.json from `cargo test ... export_state_snapshot`). RPC calls are served from the snapshot.
 *   npx tsx scripts/launchpad-ai.test.ts
 */
import { readFileSync } from 'fs';
import os from 'os';
import path from 'path';
import { Connection, PublicKey } from '@solana/web3.js';

process.env.LAUNCHPAD_METRICS_FILE = path.join(os.tmpdir(), `lp-metrics-${Date.now()}.json`);
delete process.env.GEMINI_API_KEY;

const snap = JSON.parse(readFileSync(new URL('../target/launchpad-snapshot.json', import.meta.url), 'utf8'));
const L = await import('../src/lib/launchpad/client');
const P = L.launchpadPdas(snap.programId);

(Connection.prototype as any).getMultipleAccountsInfo = async (keys: PublicKey[]) =>
  keys.map((k) => {
    const s = k.toBase58();
    if (s === P.programId.toBase58()) return { executable: true, lamports: 1, owner: PublicKey.default, data: Buffer.alloc(0) };
    const a = snap.accounts[s];
    return a ? { executable: false, lamports: a.lamports, owner: new PublicKey(a.owner), data: Buffer.from(a.data, 'base64') } : null;
  });
(Connection.prototype as any).getBalance = async () => snap.feeWalletLamports;
(Connection.prototype as any).getTokenLargestAccounts = async (mint: PublicKey) => {
  // live curve: buyer holds `buyerTokensOfLive`, curve vault holds the rest of supply
  const m = mint.toBase58();
  const buyerAta = P.ata(snap.buyer, m);
  return {
    value: [
      { address: P.vault(m), amount: '900000000000000' },
      { address: buyerAta, amount: m === snap.mints.live ? snap.buyerTokensOfLive : '0' },
    ],
  };
};

const { launchpadAiService } = await import('../src/server/launchpadAiService');
let fails = 0;
const check = (name: string, ok: boolean, detail: unknown = '') => {
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${name}${ok ? '' : ' ' + JSON.stringify(detail)}`);
  if (!ok) fails++;
};

const d: any = await launchpadAiService.discovery();
check('discovery LIVE', d.status === 'LIVE', d);
check('trending has the traded live token first', d.lists.trending[0]?.mint === snap.mints.live, d.lists.trending);
check('graduated list has the migrated token', d.lists.graduated.some((r: any) => r.mint === snap.mints.graduated));
check('fresh token is not trending (no trades)', !d.lists.trending.some((r: any) => r.mint === snap.mints.fresh));
check('newest first is the fresh token', d.lists.newest[0]?.mint === snap.mints.fresh, d.lists.newest.map((r: any) => r.symbol));

const r: any = await launchpadAiService.tokenReport(snap.mints.live, true);
check('report ok', r.ok, r);
check('report: buyer concentration flagged', r.flags.some((f: any) => f.level !== 'info' && /wallet/.test(f.text)), r.flags);
check('report: no AI text without key', r.ai === false && r.summary === null);
check('report: unknown mint rejected', (await launchpadAiService.tokenReport(PublicKey.unique().toBase58())).ok === false);

const g: any = await launchpadAiService.growth();
check('growth ok', g.ok && g.status === 'LIVE' && g.snapshots === 1, g);
check('growth flags migration-free state correctly', !g.actions.some((a: any) => /waiting for migration/.test(a.text)), g.actions);
check('growth mentions unclaimed creator fees', g.actions.some((a: any) => /unclaimed/.test(a.text)), g.actions);

const st: any = await (await import('../src/server/launchpadService')).launchpadService.state();
const t = st.totals;
check('totals: platform + creator = total fees', BigInt(t.platformFeesLamports) + BigInt(t.creatorFeesLamports) === BigInt(t.totalFeesLamports), t);
check('totals: creator share is 30% of fees (floor per trade)', Number(t.creatorFeesLamports) > 0.299 * Number(t.totalFeesLamports) && Number(t.creatorFeesLamports) <= 0.3 * Number(t.totalFeesLamports), t);

console.log(fails ? `${fails} failed` : 'all passed');
process.exit(fails ? 1 : 0);
