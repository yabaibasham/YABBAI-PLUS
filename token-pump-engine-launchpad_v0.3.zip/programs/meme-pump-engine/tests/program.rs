//! Runs the program natively inside solana-program-test (real System, SPL Token and ATA programs).
//! The Metaplex program is replaced by a no-op stub, so metadata creation itself is not exercised here.
//! Run with: cargo test -p meme-pump-engine --features test-mode
use anchor_lang::{solana_program::bpf_loader_upgradeable, AccountDeserialize, AccountSerialize, InstructionData, ToAccountMetas};
use anchor_spl::{associated_token::get_associated_token_address, metadata::mpl_token_metadata, token::spl_token};
use meme_pump_engine::{
    accounts as acc, instruction as ixd, math,
    instructions::{GlobalParams, UpdateGlobalParams},
    state::{CurveState, Global, LaunchRecord},
};
use solana_program_test::{processor, BanksClientError, ProgramTest, ProgramTestContext};
use solana_sdk::{
    account::Account,
    account_info::AccountInfo,
    entrypoint::ProgramResult,
    instruction::{Instruction, InstructionError},
    native_token::LAMPORTS_PER_SOL,
    program_pack::Pack,
    pubkey::Pubkey,
    rent::Rent,
    signature::{Keypair, Signer},
    system_program, sysvar,
    transaction::{Transaction, TransactionError},
};

const ID: Pubkey = meme_pump_engine::ID;
const V_SOL: u64 = 30 * LAMPORTS_PER_SOL;
const V_TOK: u64 = 1_073_000_000_000_000;
const REAL_TOK: u64 = 793_100_000_000_000;
const SUPPLY: u64 = 1_000_000_000_000_000;
const FEE_BPS: u16 = 100;
/// 30% of each fee goes to the token's creator
const CREATOR_SHARE: u16 = 3_000;

fn entry(program_id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    let accounts = Box::leak(Box::new(accounts.to_vec()));
    meme_pump_engine::entry(program_id, accounts, data)
}
fn noop(_: &Pubkey, _: &[AccountInfo], _: &[u8]) -> ProgramResult {
    Ok(())
}

// ---------- PDAs & instruction builders (mirrored by the TypeScript client) ----------
fn global_pda() -> Pubkey { Pubkey::find_program_address(&[b"global"], &ID).0 }
fn mint_authority_pda() -> Pubkey { Pubkey::find_program_address(&[b"mint_authority"], &ID).0 }
fn curve_pda(mint: &Pubkey) -> Pubkey { Pubkey::find_program_address(&[b"curve", mint.as_ref()], &ID).0 }
fn launch_pda(index: u64) -> Pubkey { Pubkey::find_program_address(&[b"launch", &index.to_le_bytes()], &ID).0 }
fn program_data_pda() -> Pubkey { Pubkey::find_program_address(&[ID.as_ref()], &bpf_loader_upgradeable::ID).0 }
fn metadata_pda(mint: &Pubkey) -> Pubkey {
    let p = mpl_token_metadata::ID;
    Pubkey::find_program_address(&[b"metadata", p.as_ref(), mint.as_ref()], &p).0
}
fn ata(owner: &Pubkey, mint: &Pubkey) -> Pubkey { get_associated_token_address(owner, mint) }

fn ix_init_global(authority: Pubkey, params: GlobalParams) -> Instruction {
    Instruction {
        program_id: ID,
        accounts: acc::InitializeGlobal {
            authority,
            global: global_pda(),
            program: ID,
            program_data: program_data_pda(),
            system_program: system_program::ID,
        }
        .to_account_metas(None),
        data: ixd::InitializeGlobal { params }.data(),
    }
}
fn ix_update_global(authority: Pubkey, params: UpdateGlobalParams) -> Instruction {
    Instruction {
        program_id: ID,
        accounts: acc::UpdateGlobal { authority, global: global_pda() }.to_account_metas(None),
        data: ixd::UpdateGlobal { params }.data(),
    }
}
fn ix_launch(creator: Pubkey, mint: Pubkey, index: u64, name: &str, symbol: &str, uri: &str) -> Instruction {
    let curve = curve_pda(&mint);
    Instruction {
        program_id: ID,
        accounts: acc::LaunchToken {
            creator,
            global: global_pda(),
            mint_authority: mint_authority_pda(),
            mint,
            curve_state: curve,
            token_vault: ata(&curve, &mint),
            launch_record: launch_pda(index),
            token_metadata_program: mpl_token_metadata::ID,
            metadata: metadata_pda(&mint),
            token_program: spl_token::ID,
            associated_token_program: anchor_spl::associated_token::ID,
            system_program: system_program::ID,
            rent: sysvar::rent::ID,
        }
        .to_account_metas(None),
        data: ixd::LaunchToken { name: name.into(), symbol: symbol.into(), uri: uri.into() }.data(),
    }
}
fn ix_buy(buyer: Pubkey, fee_recipient: Pubkey, mint: Pubkey, max_sol_in: u64, min_tokens_out: u64) -> Instruction {
    let curve = curve_pda(&mint);
    Instruction {
        program_id: ID,
        accounts: acc::Buy {
            buyer,
            global: global_pda(),
            fee_recipient,
            mint,
            curve_state: curve,
            token_vault: ata(&curve, &mint),
            buyer_token_account: ata(&buyer, &mint),
            token_program: spl_token::ID,
            associated_token_program: anchor_spl::associated_token::ID,
            system_program: system_program::ID,
        }
        .to_account_metas(None),
        data: ixd::Buy { max_sol_in, min_tokens_out }.data(),
    }
}
fn ix_sell(seller: Pubkey, fee_recipient: Pubkey, mint: Pubkey, token_amount: u64, min_sol_out: u64) -> Instruction {
    let curve = curve_pda(&mint);
    Instruction {
        program_id: ID,
        accounts: acc::Sell {
            seller,
            global: global_pda(),
            fee_recipient,
            mint,
            curve_state: curve,
            token_vault: ata(&curve, &mint),
            seller_token_account: ata(&seller, &mint),
            token_program: spl_token::ID,
            system_program: system_program::ID,
        }
        .to_account_metas(None),
        data: ixd::Sell { token_amount, min_sol_out }.data(),
    }
}
fn ix_claim(creator: Pubkey, mint: Pubkey) -> Instruction {
    Instruction {
        program_id: ID,
        accounts: acc::ClaimCreatorFees { creator, curve_state: curve_pda(&mint) }.to_account_metas(None),
        data: ixd::ClaimCreatorFees {}.data(),
    }
}
fn ix_withdraw(migration_authority: Pubkey, mint: Pubkey) -> Instruction {
    let curve = curve_pda(&mint);
    Instruction {
        program_id: ID,
        accounts: acc::WithdrawForMigration {
            migration_authority,
            global: global_pda(),
            mint,
            curve_state: curve,
            token_vault: ata(&curve, &mint),
            destination_token_account: ata(&migration_authority, &mint),
            token_program: spl_token::ID,
            associated_token_program: anchor_spl::associated_token::ID,
            system_program: system_program::ID,
        }
        .to_account_metas(None),
        data: ixd::WithdrawForMigration {}.data(),
    }
}
fn ix_record_pool(migration_authority: Pubkey, mint: Pubkey, pool: Pubkey) -> Instruction {
    Instruction {
        program_id: ID,
        accounts: acc::RecordMigrationPool { migration_authority, global: global_pda(), curve_state: curve_pda(&mint) }
            .to_account_metas(None),
        data: ixd::RecordMigrationPool { pool }.data(),
    }
}

// ---------- harness ----------
struct Env {
    ctx: ProgramTestContext,
    creator: Keypair,
    buyer: Keypair,
    whale: Keypair,
    migrator: Keypair,
    fee_wallet: Keypair,
}

async fn setup() -> Env {
    let mut pt = ProgramTest::new("meme_pump_engine", ID, processor!(entry));
    pt.prefer_bpf(false);
    pt.add_program("mpl_stub", mpl_token_metadata::ID, processor!(noop));
    let (creator, buyer, whale, migrator, fee_wallet) = (Keypair::new(), Keypair::new(), Keypair::new(), Keypair::new(), Keypair::new());
    for (k, sol) in [(&creator, 10), (&buyer, 100), (&whale, 500), (&migrator, 5), (&fee_wallet, 1)] {
        pt.add_account(k.pubkey(), Account { lamports: sol * LAMPORTS_PER_SOL, ..Account::default() });
    }
    let ctx = pt.start_with_context().await;
    Env { ctx, creator, buyer, whale, migrator, fee_wallet }
}

impl Env {
    async fn send(&mut self, ixs: &[Instruction], signers: &[&Keypair]) -> Result<(), BanksClientError> {
        let bh = self.ctx.get_new_latest_blockhash().await.unwrap();
        let mut all: Vec<&Keypair> = vec![&self.ctx.payer];
        all.extend_from_slice(signers);
        let tx = Transaction::new_signed_with_payer(ixs, Some(&self.ctx.payer.pubkey()), &all, bh);
        self.ctx.banks_client.process_transaction(tx).await
    }
    async fn lamports(&mut self, k: &Pubkey) -> u64 {
        self.ctx.banks_client.get_balance(*k).await.unwrap()
    }
    async fn anchor<T: AccountDeserialize>(&mut self, k: &Pubkey) -> T {
        let a = self.ctx.banks_client.get_account(*k).await.unwrap().expect("account missing");
        T::try_deserialize(&mut a.data.as_slice()).unwrap()
    }
    async fn token_balance(&mut self, k: &Pubkey) -> u64 {
        match self.ctx.banks_client.get_account(*k).await.unwrap() {
            Some(a) => spl_token::state::Account::unpack(&a.data).unwrap().amount,
            None => 0,
        }
    }
    async fn mint_state(&mut self, k: &Pubkey) -> spl_token::state::Mint {
        let a = self.ctx.banks_client.get_account(*k).await.unwrap().unwrap();
        spl_token::state::Mint::unpack(&a.data).unwrap()
    }
}

fn err_code(r: Result<(), BanksClientError>) -> u32 {
    match r {
        Err(BanksClientError::TransactionError(TransactionError::InstructionError(_, InstructionError::Custom(c)))) => c,
        Err(BanksClientError::SimulationError { err: TransactionError::InstructionError(_, InstructionError::Custom(c)), .. }) => c,
        other => panic!("expected a custom program error, got {other:?}"),
    }
}
// Anchor error codes: 6000 + variant index
const E_COMPLETED: u32 = 6000;
const E_NOT_COMPLETED: u32 = 6001;
const E_ALREADY_MIGRATED: u32 = 6002;
const E_NOT_MIGRATED: u32 = 6003;
const E_SLIPPAGE: u32 = 6005;
const E_FEE_TOO_HIGH: u32 = 6007;
const E_UNAUTHORIZED: u32 = 6008;
const E_PAUSED: u32 = 6010;
const E_BAD_PARAMS: u32 = 6011;
const E_BAD_METADATA: u32 = 6012;
const E_BAD_SHARE: u32 = 6013;
const E_NOTHING_TO_CLAIM: u32 = 6014;

fn default_params(fee_recipient: Pubkey, migration_authority: Pubkey) -> GlobalParams {
    GlobalParams {
        fee_recipient,
        migration_authority,
        fee_bps: FEE_BPS,
        creator_fee_share_bps: CREATOR_SHARE,
        initial_virtual_sol_reserves: V_SOL,
        initial_virtual_token_reserves: V_TOK,
        initial_real_token_reserves: REAL_TOK,
        token_total_supply: SUPPLY,
    }
}

async fn init(env: &mut Env) {
    let payer = env.ctx.payer.pubkey();
    let p = default_params(env.fee_wallet.pubkey(), env.migrator.pubkey());
    env.send(&[ix_init_global(payer, p)], &[]).await.unwrap();
}

async fn launch(env: &mut Env, index: u64) -> Pubkey {
    let mint = Keypair::new();
    let creator = env.creator.insecure_clone();
    let ix = ix_launch(creator.pubkey(), mint.pubkey(), index, "Burn City", "BURN", "https://example.com/burn.json");
    env.send(&[ix], &[&creator, &mint]).await.unwrap();
    mint.pubkey()
}

#[tokio::test]
async fn admin_controls_are_guarded() {
    let mut env = setup().await;
    let payer = env.ctx.payer.pubkey();
    let (fw, mg) = (env.fee_wallet.pubkey(), env.migrator.pubkey());

    // Fee above the 5% cap and nonsensical curves are rejected
    let mut p = default_params(fw, mg);
    p.fee_bps = 501;
    assert_eq!(err_code(env.send(&[ix_init_global(payer, p)], &[]).await), E_FEE_TOO_HIGH);
    let mut p = default_params(fw, mg);
    p.initial_real_token_reserves = SUPPLY;
    assert_eq!(err_code(env.send(&[ix_init_global(payer, p)], &[]).await), E_BAD_PARAMS);
    let mut p = default_params(fw, mg);
    p.creator_fee_share_bps = 10_001;
    assert_eq!(err_code(env.send(&[ix_init_global(payer, p)], &[]).await), E_BAD_SHARE);

    init(&mut env).await;
    let g: Global = env.anchor(&global_pda()).await;
    assert_eq!((g.authority, g.fee_recipient, g.migration_authority, g.fee_bps, g.launch_count), (payer, fw, mg, FEE_BPS, 0));

    // Can't initialize twice
    assert!(env.send(&[ix_init_global(payer, default_params(fw, mg))], &[]).await.is_err());

    // Only the authority can update
    let stranger = env.buyer.insecure_clone();
    let upd = UpdateGlobalParams { fee_bps: Some(50), ..Default::default() };
    assert_eq!(err_code(env.send(&[ix_update_global(stranger.pubkey(), upd.clone())], &[&stranger]).await), E_UNAUTHORIZED);
    env.send(&[ix_update_global(payer, upd)], &[]).await.unwrap();
    let g: Global = env.anchor(&global_pda()).await;
    assert_eq!(g.fee_bps, 50);
    let too_high = UpdateGlobalParams { fee_bps: Some(900), ..Default::default() };
    assert_eq!(err_code(env.send(&[ix_update_global(payer, too_high)], &[]).await), E_FEE_TOO_HIGH);
    assert_eq!(env.anchor::<Global>(&global_pda()).await.creator_fee_share_bps, CREATOR_SHARE);
    let bad_share = UpdateGlobalParams { creator_fee_share_bps: Some(20_000), ..Default::default() };
    assert_eq!(err_code(env.send(&[ix_update_global(payer, bad_share)], &[]).await), E_BAD_SHARE);
    env.send(&[ix_update_global(payer, UpdateGlobalParams { creator_fee_share_bps: Some(5_000), ..Default::default() })], &[]).await.unwrap();
    assert_eq!(env.anchor::<Global>(&global_pda()).await.creator_fee_share_bps, 5_000);

    // Hand authority to a new key; the old one loses access
    let new_admin = env.whale.insecure_clone();
    env.send(&[ix_update_global(payer, UpdateGlobalParams { new_authority: Some(new_admin.pubkey()), ..Default::default() })], &[]).await.unwrap();
    let pause = UpdateGlobalParams { paused: Some(true), ..Default::default() };
    assert_eq!(err_code(env.send(&[ix_update_global(payer, pause.clone())], &[]).await), E_UNAUTHORIZED);
    env.send(&[ix_update_global(new_admin.pubkey(), pause)], &[&new_admin]).await.unwrap();
    assert!(env.anchor::<Global>(&global_pda()).await.paused);
}

#[tokio::test]
async fn full_lifecycle() {
    let mut env = setup().await;
    init(&mut env).await;
    let fee_wallet = env.fee_wallet.pubkey();

    // ---- launch ----
    let bad = Keypair::new();
    let creator = env.creator.insecure_clone();
    let ix = ix_launch(creator.pubkey(), bad.pubkey(), 0, "", "X", "https://x");
    assert_eq!(err_code(env.send(&[ix], &[&creator, &bad]).await), E_BAD_METADATA);

    let mint = launch(&mut env, 0).await;
    let curve_key = curve_pda(&mint);
    let curve: CurveState = env.anchor(&curve_key).await;
    assert_eq!((curve.mint, curve.creator, curve.launch_index), (mint, creator.pubkey(), 0));
    assert_eq!((curve.virtual_sol_reserves, curve.virtual_token_reserves, curve.real_token_reserves, curve.initial_real_token_reserves), (V_SOL, V_TOK, REAL_TOK, REAL_TOK));
    assert!(!curve.complete && !curve.migrated);
    assert_eq!(env.token_balance(&ata(&curve_key, &mint)).await, SUPPLY);
    let m = env.mint_state(&mint).await;
    assert_eq!((m.supply, m.decimals), (SUPPLY, 6));
    assert!(m.mint_authority.is_none(), "mint authority must be revoked");
    assert!(m.freeze_authority.is_none(), "freeze authority must never be set");
    let rec: LaunchRecord = env.anchor(&launch_pda(0)).await;
    assert_eq!((rec.index, rec.mint, rec.creator), (0, mint, creator.pubkey()));
    assert_eq!(env.anchor::<Global>(&global_pda()).await.launch_count, 1);

    // ---- buy: exact fee to the platform, exact tokens to the buyer ----
    let buyer = env.buyer.insecure_clone();
    let spend = 2 * LAMPORTS_PER_SOL;
    let q = math::quote_buy(V_SOL, V_TOK, REAL_TOK, FEE_BPS, spend).unwrap();
    let ata_rent = Rent::default().minimum_balance(spl_token::state::Account::LEN);
    let (fee_before, buyer_before, curve_before) = (env.lamports(&fee_wallet).await, env.lamports(&buyer.pubkey()).await, env.lamports(&curve_key).await);
    // Slippage guard
    assert_eq!(err_code(env.send(&[ix_buy(buyer.pubkey(), fee_wallet, mint, spend, q.tokens_out + 1)], &[&buyer]).await), E_SLIPPAGE);
    // Wrong fee recipient is rejected
    assert_eq!(err_code(env.send(&[ix_buy(buyer.pubkey(), buyer.pubkey(), mint, spend, 0)], &[&buyer]).await), E_UNAUTHORIZED);
    env.send(&[ix_buy(buyer.pubkey(), fee_wallet, mint, spend, q.tokens_out)], &[&buyer]).await.unwrap();
    let (q_platform, q_creator) = math::split_fee(q.fee, CREATOR_SHARE).unwrap();
    assert_eq!(q.fee, spend / 100);
    assert_eq!(q_creator, q.fee * 3 / 10);
    assert_eq!(env.lamports(&fee_wallet).await - fee_before, q_platform);
    assert_eq!(buyer_before - env.lamports(&buyer.pubkey()).await, q.sol_in + q.fee + ata_rent);
    assert_eq!(env.lamports(&curve_key).await - curve_before, q.sol_in + q_creator);
    assert_eq!(env.token_balance(&ata(&buyer.pubkey(), &mint)).await, q.tokens_out);
    let c: CurveState = env.anchor(&curve_key).await;
    assert_eq!((c.real_sol_reserves, c.real_token_reserves), (q.sol_in, REAL_TOK - q.tokens_out));
    assert_eq!((c.fees_lamports, c.volume_lamports, c.trade_count), (q.fee, q.sol_in, 1));
    assert_eq!((c.creator_fees_lamports, c.creator_fees_claimed), (q_creator, 0));

    // ---- sell half back ----
    let sell_amt = q.tokens_out / 2;
    let s = math::quote_sell(c.virtual_sol_reserves, c.virtual_token_reserves, c.real_sol_reserves, FEE_BPS, sell_amt).unwrap();
    let (fee_before, seller_before) = (env.lamports(&fee_wallet).await, env.lamports(&buyer.pubkey()).await);
    assert_eq!(err_code(env.send(&[ix_sell(buyer.pubkey(), fee_wallet, mint, sell_amt, s.sol_out_net + 1)], &[&buyer]).await), E_SLIPPAGE);
    env.send(&[ix_sell(buyer.pubkey(), fee_wallet, mint, sell_amt, s.sol_out_net)], &[&buyer]).await.unwrap();
    assert_eq!(env.lamports(&buyer.pubkey()).await - seller_before, s.sol_out_net);
    let (s_platform, s_creator) = math::split_fee(s.fee, CREATOR_SHARE).unwrap();
    assert_eq!(env.lamports(&fee_wallet).await - fee_before, s_platform);
    let c2: CurveState = env.anchor(&curve_key).await;
    assert_eq!(c2.real_sol_reserves, c.real_sol_reserves - s.sol_out_gross);
    assert_eq!(c2.fees_lamports, q.fee + s.fee);
    assert_eq!(c2.creator_fees_lamports, q_creator + s_creator);
    // Curve account always holds its rent + the real SOL it tracks + unclaimed creator fees
    let curve_rent = Rent::default().minimum_balance(8 + <CurveState as anchor_lang::Space>::INIT_SPACE);
    assert_eq!(env.lamports(&curve_key).await, curve_rent + c2.real_sol_reserves + c2.creator_fees_lamports);

    // ---- creator claims their share mid-curve; nobody else can ----
    assert_eq!(err_code(env.send(&[ix_claim(buyer.pubkey(), mint)], &[&buyer]).await), E_UNAUTHORIZED);
    let creator_before = env.lamports(&creator.pubkey()).await;
    env.send(&[ix_claim(creator.pubkey(), mint)], &[&creator]).await.unwrap();
    assert_eq!(env.lamports(&creator.pubkey()).await - creator_before, c2.creator_fees_lamports);
    assert_eq!(env.lamports(&curve_key).await, curve_rent + c2.real_sol_reserves);
    assert_eq!(err_code(env.send(&[ix_claim(creator.pubkey(), mint)], &[&creator]).await), E_NOTHING_TO_CLAIM);

    // ---- pause: launches and buys stop, sells stay open ----
    let payer = env.ctx.payer.pubkey();
    env.send(&[ix_update_global(payer, UpdateGlobalParams { paused: Some(true), ..Default::default() })], &[]).await.unwrap();
    assert_eq!(err_code(env.send(&[ix_buy(buyer.pubkey(), fee_wallet, mint, LAMPORTS_PER_SOL, 0)], &[&buyer]).await), E_PAUSED);
    let m2 = Keypair::new();
    let ix = ix_launch(creator.pubkey(), m2.pubkey(), 1, "Paused", "NO", "https://x");
    assert_eq!(err_code(env.send(&[ix], &[&creator, &m2]).await), E_PAUSED);
    env.send(&[ix_sell(buyer.pubkey(), fee_wallet, mint, 1_000_000, 0)], &[&buyer]).await.unwrap();
    env.send(&[ix_update_global(payer, UpdateGlobalParams { paused: Some(false), ..Default::default() })], &[]).await.unwrap();

    // ---- withdraw before sell-out is refused ----
    let migrator = env.migrator.insecure_clone();
    assert_eq!(err_code(env.send(&[ix_withdraw(migrator.pubkey(), mint)], &[&migrator]).await), E_NOT_COMPLETED);

    // ---- a whale offering 200 SOL is capped at the remaining sale supply ----
    let whale = env.whale.insecure_clone();
    let c: CurveState = env.anchor(&curve_key).await;
    let big = math::quote_buy(c.virtual_sol_reserves, c.virtual_token_reserves, c.real_token_reserves, FEE_BPS, 200 * LAMPORTS_PER_SOL).unwrap();
    assert!(big.completes && big.sol_in < 90 * LAMPORTS_PER_SOL);
    let whale_before = env.lamports(&whale.pubkey()).await;
    env.send(&[ix_buy(whale.pubkey(), fee_wallet, mint, 200 * LAMPORTS_PER_SOL, 0)], &[&whale]).await.unwrap();
    assert_eq!(whale_before - env.lamports(&whale.pubkey()).await, big.sol_in + big.fee + ata_rent);
    let done: CurveState = env.anchor(&curve_key).await;
    assert!(done.complete);
    assert_eq!(done.real_token_reserves, 0);
    let lp_reserve = SUPPLY - REAL_TOK;
    assert_eq!(env.token_balance(&ata(&curve_key, &mint)).await, lp_reserve);
    assert!(done.real_sol_reserves > 84 * LAMPORTS_PER_SOL && done.real_sol_reserves < 86 * LAMPORTS_PER_SOL, "{}", done.real_sol_reserves);

    // ---- trading is closed once complete ----
    assert_eq!(err_code(env.send(&[ix_buy(buyer.pubkey(), fee_wallet, mint, LAMPORTS_PER_SOL, 0)], &[&buyer]).await), E_COMPLETED);
    assert_eq!(err_code(env.send(&[ix_sell(buyer.pubkey(), fee_wallet, mint, 1_000, 0)], &[&buyer]).await), E_COMPLETED);

    // ---- only the migration authority can withdraw, exactly once ----
    assert_eq!(err_code(env.send(&[ix_withdraw(buyer.pubkey(), mint)], &[&buyer]).await), E_UNAUTHORIZED);
    assert_eq!(err_code(env.send(&[ix_record_pool(migrator.pubkey(), mint, Pubkey::new_unique())], &[&migrator]).await), E_NOT_MIGRATED);
    let mig_before = env.lamports(&migrator.pubkey()).await;
    env.send(&[ix_withdraw(migrator.pubkey(), mint)], &[&migrator]).await.unwrap();
    assert_eq!(env.lamports(&migrator.pubkey()).await + ata_rent - mig_before, done.real_sol_reserves);
    assert_eq!(env.token_balance(&ata(&migrator.pubkey(), &mint)).await, lp_reserve);
    // Migration never touches the creator's unclaimed fees
    let unclaimed = done.creator_fees_lamports - done.creator_fees_claimed;
    assert!(unclaimed > 0);
    assert_eq!(env.lamports(&curve_key).await, curve_rent + unclaimed);
    let creator_before = env.lamports(&creator.pubkey()).await;
    env.send(&[ix_claim(creator.pubkey(), mint)], &[&creator]).await.unwrap();
    assert_eq!(env.lamports(&creator.pubkey()).await - creator_before, unclaimed);
    assert_eq!(env.lamports(&curve_key).await, curve_rent);
    let migrated: CurveState = env.anchor(&curve_key).await;
    assert!(migrated.migrated);
    assert_eq!((migrated.migration_sol, migrated.migration_tokens, migrated.real_sol_reserves), (done.real_sol_reserves, lp_reserve, 0));
    assert_eq!(err_code(env.send(&[ix_withdraw(migrator.pubkey(), mint)], &[&migrator]).await), E_ALREADY_MIGRATED);

    // ---- record the DEX pool ----
    let pool = Pubkey::new_unique();
    assert_eq!(err_code(env.send(&[ix_record_pool(buyer.pubkey(), mint, pool)], &[&buyer]).await), E_UNAUTHORIZED);
    env.send(&[ix_record_pool(migrator.pubkey(), mint, pool)], &[&migrator]).await.unwrap();
    assert_eq!(env.anchor::<CurveState>(&curve_key).await.migration_pool, pool);

    // ---- platform fees: every lamport is accounted for ----
    let fin = env.anchor::<CurveState>(&curve_key).await;
    assert_eq!(env.lamports(&fee_wallet).await - LAMPORTS_PER_SOL, fin.fees_lamports - fin.creator_fees_lamports);
    assert_eq!(fin.creator_fees_claimed, fin.creator_fees_lamports);

    // ---- second launch gets the next registry index ----
    let mint2 = launch(&mut env, 1).await;
    assert_eq!(env.anchor::<LaunchRecord>(&launch_pda(1)).await.mint, mint2);
    assert_eq!(env.anchor::<Global>(&global_pda()).await.launch_count, 2);
}

/// Writes byte-level vectors so the TypeScript client can be checked against this program.
#[test]
fn export_client_vectors() {
    use serde_json::{json, Value};
    let k = |n: u8| Pubkey::new_from_array([n; 32]);
    let (creator, mint, buyer, fee, migrator, pool) = (k(1), k(2), k(3), k(4), k(5), k(6));
    let metas = |ix: &Instruction| -> Value {
        ix.accounts
            .iter()
            .map(|m| json!({ "pubkey": m.pubkey.to_string(), "isSigner": m.is_signer, "isWritable": m.is_writable }))
            .collect()
    };
    let enc = |name: &str, ix: Instruction| json!({ "name": name, "data": hex(&ix.data), "accounts": metas(&ix) });

    let gp = default_params(fee, migrator);
    let upd = UpdateGlobalParams { fee_recipient: Some(fee), fee_bps: Some(250), creator_fee_share_bps: Some(4_000), paused: Some(true), token_total_supply: Some(SUPPLY), ..Default::default() };
    let instructions = vec![
        enc("initializeGlobal", ix_init_global(creator, gp.clone())),
        enc("updateGlobal", ix_update_global(creator, upd)),
        enc("launchToken", ix_launch(creator, mint, 7, "Burn City", "BURN", "https://example.com/burn.json")),
        enc("buy", ix_buy(buyer, fee, mint, 1_500_000_000, 123_456)),
        enc("sell", ix_sell(buyer, fee, mint, 987_654_321, 42)),
        enc("claimCreatorFees", ix_claim(creator, mint)),
        enc("withdrawForMigration", ix_withdraw(migrator, mint)),
        enc("recordMigrationPool", ix_record_pool(migrator, mint, pool)),
    ];

    let global = Global {
        authority: creator, fee_recipient: fee, migration_authority: migrator, fee_bps: 100, creator_fee_share_bps: 3_000, paused: true,
        initial_virtual_sol_reserves: V_SOL, initial_virtual_token_reserves: V_TOK, initial_real_token_reserves: REAL_TOK,
        token_total_supply: SUPPLY, launch_count: 12, bump: 254,
    };
    let curve = CurveState {
        mint, creator, launch_index: 3, created_at: 1_793_000_000, virtual_sol_reserves: 31_000_000_000,
        virtual_token_reserves: 1_038_000_000_000_000, real_sol_reserves: 1_000_000_000, real_token_reserves: 758_100_000_000_000,
        initial_real_token_reserves: REAL_TOK, token_total_supply: SUPPLY, volume_lamports: 5_000_000_000, fees_lamports: 50_000_000,
        creator_fees_lamports: 15_000_000, creator_fees_claimed: 4_000_000, trade_count: 9,
        complete: false, migrated: true, migration_sol: 7, migration_tokens: 8, migration_pool: pool, bump: 253,
    };
    let record = LaunchRecord { index: 3, mint, creator, created_at: 1_793_000_000, bump: 252 };
    let ser = |f: &dyn Fn(&mut Vec<u8>)| { let mut b = Vec::new(); f(&mut b); hex(&b) };

    let mut buys = vec![];
    for (vs, vt, rt, bps, max_in) in [
        (V_SOL, V_TOK, REAL_TOK, 100u16, 1_000_000_000u64),
        (V_SOL, V_TOK, REAL_TOK, 100, 1),
        (V_SOL, V_TOK, REAL_TOK, 0, 123_456_789),
        (V_SOL, V_TOK, REAL_TOK, 500, 500_000_000_000),
        (V_SOL + 40_000_000_000, 455_000_000_000_000, 175_100_000_000_000, 100, 7_777_777_777),
    ] {
        let r = match math::quote_buy(vs, vt, rt, bps, max_in) {
            Ok(q) => json!({ "solIn": q.sol_in.to_string(), "fee": q.fee.to_string(), "tokensOut": q.tokens_out.to_string(),
                "newVirtualSol": q.new_virtual_sol.to_string(), "newVirtualToken": q.new_virtual_token.to_string(), "completes": q.completes }),
            Err(e) => json!({ "error": e.to_string() }),
        };
        buys.push(json!({ "virtualSol": vs.to_string(), "virtualToken": vt.to_string(), "realToken": rt.to_string(), "feeBps": bps, "maxSolIn": max_in.to_string(), "result": r }));
    }
    let mut sells = vec![];
    for (vs, vt, rs, bps, amt) in [
        (31_000_000_000u64, 1_038_000_000_000_000u64, 1_000_000_000u64, 100u16, 10_000_000_000_000u64),
        (31_000_000_000, 1_038_000_000_000_000, 1_000_000_000, 100, 1),
        (31_000_000_000, 1_038_000_000_000_000, 1_000_000_000, 0, 35_000_000_000_000),
        (31_000_000_000, 1_038_000_000_000_000, 1_000_000_000, 250, 40_000_000_000_000),
    ] {
        let r = match math::quote_sell(vs, vt, rs, bps, amt) {
            Ok(q) => json!({ "solOutGross": q.sol_out_gross.to_string(), "fee": q.fee.to_string(), "solOutNet": q.sol_out_net.to_string(),
                "newVirtualSol": q.new_virtual_sol.to_string(), "newVirtualToken": q.new_virtual_token.to_string() }),
            Err(e) => json!({ "error": e.to_string() }),
        };
        sells.push(json!({ "virtualSol": vs.to_string(), "virtualToken": vt.to_string(), "realSol": rs.to_string(), "feeBps": bps, "tokenAmount": amt.to_string(), "result": r }));
    }

    let splits: Vec<Value> = [(10_000_000u64, 3_000u16), (7, 5_000), (123, 0), (123, 10_000), (999_999_999, 3_333)]
        .iter()
        .map(|&(fee, bps)| {
            let (p, c) = math::split_fee(fee, bps).unwrap();
            json!({ "fee": fee.to_string(), "shareBps": bps, "platform": p.to_string(), "creator": c.to_string() })
        })
        .collect();
    let out = json!({
        "programId": ID.to_string(),
        "keys": { "creator": creator.to_string(), "mint": mint.to_string(), "buyer": buyer.to_string(), "fee": fee.to_string(), "migrator": migrator.to_string(), "pool": pool.to_string() },
        "pdas": {
            "global": global_pda().to_string(), "mintAuthority": mint_authority_pda().to_string(), "programData": program_data_pda().to_string(),
            "curve": curve_pda(&mint).to_string(), "launch7": launch_pda(7).to_string(), "metadata": metadata_pda(&mint).to_string(),
            "vault": ata(&curve_pda(&mint), &mint).to_string(),
        },
        "instructions": instructions,
        "accounts": {
            "global": ser(&|b| global.try_serialize(b).unwrap()),
            "curve": ser(&|b| curve.try_serialize(b).unwrap()),
            "launchRecord": ser(&|b| record.try_serialize(b).unwrap()),
        },
        "math": { "buy": buys, "sell": sells, "split": splits },
        "errorCodes": { "6000": "CurveCompleted", "6005": "SlippageExceeded", "6010": "Paused" },
    });
    let path = concat!(env!("CARGO_MANIFEST_DIR"), "/../../target/launchpad-vectors.json");
    std::fs::write(path, serde_json::to_string_pretty(&out).unwrap()).unwrap();
}

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}

/// Runs a short real session and saves the resulting on-chain accounts, so the server and UI
/// can be tested against bytes this program actually wrote.
#[tokio::test]
async fn export_state_snapshot() {
    use serde_json::json;
    let mut env = setup().await;
    init(&mut env).await;
    let fee_wallet = env.fee_wallet.pubkey();
    let (buyer, whale, migrator) = (env.buyer.insecure_clone(), env.whale.insecure_clone(), env.migrator.insecure_clone());

    let live = launch(&mut env, 0).await;
    env.send(&[ix_buy(buyer.pubkey(), fee_wallet, live, 2 * LAMPORTS_PER_SOL, 0)], &[&buyer]).await.unwrap();
    env.send(&[ix_buy(whale.pubkey(), fee_wallet, live, 5 * LAMPORTS_PER_SOL, 0)], &[&whale]).await.unwrap();
    env.send(&[ix_sell(buyer.pubkey(), fee_wallet, live, 10_000_000_000_000, 0)], &[&buyer]).await.unwrap();

    let graduated = launch(&mut env, 1).await;
    env.send(&[ix_buy(whale.pubkey(), fee_wallet, graduated, 200 * LAMPORTS_PER_SOL, 0)], &[&whale]).await.unwrap();
    env.send(&[ix_withdraw(migrator.pubkey(), graduated)], &[&migrator]).await.unwrap();
    let pool = Pubkey::new_unique();
    env.send(&[ix_record_pool(migrator.pubkey(), graduated, pool)], &[&migrator]).await.unwrap();

    let fresh = launch(&mut env, 2).await;

    let mut accounts = serde_json::Map::new();
    let mut keys = vec![global_pda()];
    for (i, m) in [live, graduated, fresh].iter().enumerate() {
        keys.push(launch_pda(i as u64));
        keys.push(curve_pda(m));
    }
    use base64::Engine as _;
    for k in keys {
        let a = env.ctx.banks_client.get_account(k).await.unwrap().unwrap();
        accounts.insert(k.to_string(), json!({ "owner": a.owner.to_string(), "lamports": a.lamports, "data": base64::engine::general_purpose::STANDARD.encode(&a.data) }));
    }
    let buyer_tokens = env.token_balance(&ata(&buyer.pubkey(), &live)).await;
    let out = json!({
        "programId": ID.to_string(),
        "authority": env.ctx.payer.pubkey().to_string(),
        "feeWallet": fee_wallet.to_string(),
        "feeWalletLamports": env.lamports(&fee_wallet).await,
        "migrator": migrator.pubkey().to_string(),
        "buyer": buyer.pubkey().to_string(),
        "buyerTokensOfLive": buyer_tokens.to_string(),
        "mints": { "live": live.to_string(), "graduated": graduated.to_string(), "fresh": fresh.to_string() },
        "pool": pool.to_string(),
        "accounts": accounts,
    });
    let path = concat!(env!("CARGO_MANIFEST_DIR"), "/../../target/launchpad-snapshot.json");
    std::fs::write(path, serde_json::to_string_pretty(&out).unwrap()).unwrap();
}
