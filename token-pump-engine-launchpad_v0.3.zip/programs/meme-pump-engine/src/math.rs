//! Bonding-curve math. Pure functions, mirrored in the TypeScript client.
//! Rounding always favours the curve, so real SOL can never be overdrawn.
use crate::constants::BPS_DENOMINATOR;
use crate::errors::PumpError;
use anchor_lang::prelude::*;

fn ceil_div(a: u128, b: u128) -> Result<u128> {
    require!(b > 0, PumpError::MathOverflow);
    Ok(a.checked_add(b - 1).ok_or(PumpError::MathOverflow)? / b)
}

fn to_u64(v: u128) -> Result<u64> {
    u64::try_from(v).map_err(|_| error!(PumpError::MathOverflow))
}

/// Platform fee on `amount`, rounded up.
pub fn fee_on(amount: u64, fee_bps: u16) -> Result<u64> {
    let raw = (amount as u128)
        .checked_mul(fee_bps as u128)
        .ok_or(PumpError::MathOverflow)?;
    to_u64(ceil_div(raw, BPS_DENOMINATOR)?)
}

/// Splits a trade fee into (platform, creator). The creator gets `creator_share_bps` of the fee,
/// rounded down, so the platform side never loses a lamport to rounding.
pub fn split_fee(fee: u64, creator_share_bps: u16) -> Result<(u64, u64)> {
    require!((creator_share_bps as u128) <= BPS_DENOMINATOR, PumpError::InvalidCreatorShare);
    let creator = to_u64(
        (fee as u128)
            .checked_mul(creator_share_bps as u128)
            .ok_or(PumpError::MathOverflow)?
            / BPS_DENOMINATOR,
    )?;
    Ok((fee - creator, creator))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BuyQuote {
    /// SOL that goes into the curve (fee is charged on top of this).
    pub sol_in: u64,
    pub fee: u64,
    pub tokens_out: u64,
    pub new_virtual_sol: u64,
    pub new_virtual_token: u64,
    /// True when this buy takes the last tokens for sale.
    pub completes: bool,
}

/// Quote a buy that puts at most `max_sol_in` into the curve.
/// If that would take more than the tokens left for sale, the buy is capped at the
/// remaining tokens and only the SOL needed for them is charged.
pub fn quote_buy(
    virtual_sol: u64,
    virtual_token: u64,
    real_token: u64,
    fee_bps: u16,
    max_sol_in: u64,
) -> Result<BuyQuote> {
    require!(max_sol_in > 0, PumpError::ZeroAmount);
    require!(real_token > 0, PumpError::CurveCompleted);
    let k = (virtual_sol as u128)
        .checked_mul(virtual_token as u128)
        .ok_or(PumpError::MathOverflow)?;

    let uncapped_v_sol = (virtual_sol as u128)
        .checked_add(max_sol_in as u128)
        .ok_or(PumpError::MathOverflow)?;
    let uncapped_v_tok = ceil_div(k, uncapped_v_sol)?;
    let uncapped_out = (virtual_token as u128)
        .checked_sub(uncapped_v_tok)
        .ok_or(PumpError::MathOverflow)?;

    let (sol_in, tokens_out, new_v_sol, new_v_tok, completes) = if uncapped_out >= real_token as u128 {
        let tokens_out = real_token as u128;
        let new_v_tok = (virtual_token as u128)
            .checked_sub(tokens_out)
            .ok_or(PumpError::MathOverflow)?;
        require!(new_v_tok > 0, PumpError::InvalidCurveParams);
        let new_v_sol = ceil_div(k, new_v_tok)?;
        let sol_in = new_v_sol
            .checked_sub(virtual_sol as u128)
            .ok_or(PumpError::MathOverflow)?;
        (sol_in, tokens_out, new_v_sol, new_v_tok, true)
    } else {
        (max_sol_in as u128, uncapped_out, uncapped_v_sol, uncapped_v_tok, false)
    };

    require!(tokens_out > 0, PumpError::ZeroAmount);
    require!(sol_in > 0 && sol_in <= max_sol_in as u128, PumpError::MathOverflow);
    let sol_in = to_u64(sol_in)?;
    Ok(BuyQuote {
        sol_in,
        fee: fee_on(sol_in, fee_bps)?,
        tokens_out: to_u64(tokens_out)?,
        new_virtual_sol: to_u64(new_v_sol)?,
        new_virtual_token: to_u64(new_v_tok)?,
        completes,
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SellQuote {
    /// SOL leaving the curve before the fee.
    pub sol_out_gross: u64,
    pub fee: u64,
    /// SOL the seller receives.
    pub sol_out_net: u64,
    pub new_virtual_sol: u64,
    pub new_virtual_token: u64,
}

pub fn quote_sell(
    virtual_sol: u64,
    virtual_token: u64,
    real_sol: u64,
    fee_bps: u16,
    token_amount: u64,
) -> Result<SellQuote> {
    require!(token_amount > 0, PumpError::ZeroAmount);
    let k = (virtual_sol as u128)
        .checked_mul(virtual_token as u128)
        .ok_or(PumpError::MathOverflow)?;
    let new_v_tok = (virtual_token as u128)
        .checked_add(token_amount as u128)
        .ok_or(PumpError::MathOverflow)?;
    let new_v_sol = ceil_div(k, new_v_tok)?;
    let gross = (virtual_sol as u128)
        .checked_sub(new_v_sol)
        .ok_or(PumpError::MathOverflow)?;
    require!(gross > 0, PumpError::ZeroAmount);
    require!(gross <= real_sol as u128, PumpError::InsufficientReserves);
    let gross = to_u64(gross)?;
    let fee = fee_on(gross, fee_bps)?;
    let net = gross.checked_sub(fee).ok_or(PumpError::MathOverflow)?;
    require!(net > 0, PumpError::ZeroAmount);
    Ok(SellQuote {
        sol_out_gross: gross,
        fee,
        sol_out_net: net,
        new_virtual_sol: to_u64(new_v_sol)?,
        new_virtual_token: to_u64(new_v_tok)?,
    })
}

/// Shared validation for curve parameters.
pub fn validate_curve_params(
    virtual_sol: u64,
    virtual_token: u64,
    real_token: u64,
    total_supply: u64,
) -> Result<()> {
    require!(virtual_sol > 0, PumpError::InvalidCurveParams);
    require!(real_token > 0, PumpError::InvalidCurveParams);
    // Some supply must be left over to seed the DEX pool after the curve sells out.
    require!(total_supply > real_token, PumpError::InvalidCurveParams);
    // The curve must still have virtual tokens left when the sale supply is gone.
    require!(virtual_token > real_token, PumpError::InvalidCurveParams);
    // k must fit comfortably in u128 math.
    (virtual_sol as u128)
        .checked_mul(virtual_token as u128)
        .ok_or(PumpError::InvalidCurveParams)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    const V_SOL: u64 = 30_000_000_000;
    const V_TOK: u64 = 1_073_000_000_000_000;
    const REAL_TOK: u64 = 793_100_000_000_000;

    #[test]
    fn fee_rounds_up() {
        assert_eq!(fee_on(1_000_000_000, 100).unwrap(), 10_000_000);
        assert_eq!(fee_on(1, 100).unwrap(), 1);
        assert_eq!(fee_on(0, 100).unwrap(), 0);
        assert_eq!(fee_on(12_345, 0).unwrap(), 0);
    }

    #[test]
    fn buy_keeps_k_from_shrinking() {
        let q = quote_buy(V_SOL, V_TOK, REAL_TOK, 100, 1_000_000_000).unwrap();
        assert!(!q.completes);
        assert_eq!(q.sol_in, 1_000_000_000);
        assert_eq!(q.fee, 10_000_000);
        assert!((q.new_virtual_sol as u128) * (q.new_virtual_token as u128) >= (V_SOL as u128) * (V_TOK as u128));
        assert_eq!(q.tokens_out, V_TOK - q.new_virtual_token);
    }

    #[test]
    fn oversized_buy_is_capped_at_sale_supply() {
        let q = quote_buy(V_SOL, V_TOK, REAL_TOK, 100, 500_000_000_000).unwrap();
        assert!(q.completes);
        assert_eq!(q.tokens_out, REAL_TOK);
        // ~85 SOL closes the default curve, not the 500 offered
        assert!(q.sol_in > 84_900_000_000 && q.sol_in < 85_100_000_000, "{}", q.sol_in);
    }

    #[test]
    fn round_trip_never_profits() {
        let b = quote_buy(V_SOL, V_TOK, REAL_TOK, 0, 2_000_000_000).unwrap();
        let s = quote_sell(b.new_virtual_sol, b.new_virtual_token, b.sol_in, 0, b.tokens_out).unwrap();
        assert!(s.sol_out_gross <= b.sol_in);
    }

    #[test]
    fn sell_cannot_overdraw_real_sol() {
        let b = quote_buy(V_SOL, V_TOK, REAL_TOK, 0, 1_000_000).unwrap();
        // Selling more tokens than were bought would need more SOL than the curve holds
        assert!(quote_sell(b.new_virtual_sol, b.new_virtual_token, b.sol_in, 0, b.tokens_out * 2).is_err());
    }

    #[test]
    fn fee_split_adds_up() {
        assert_eq!(split_fee(10_000_000, 3_000).unwrap(), (7_000_000, 3_000_000));
        assert_eq!(split_fee(7, 5_000).unwrap(), (4, 3)); // rounding goes to the platform side
        assert_eq!(split_fee(123, 0).unwrap(), (123, 0));
        assert_eq!(split_fee(123, 10_000).unwrap(), (0, 123));
        assert!(split_fee(1, 10_001).is_err());
    }

    #[test]
    fn rejects_bad_params() {
        assert!(validate_curve_params(V_SOL, V_TOK, REAL_TOK, 1_000_000_000_000_000).is_ok());
        assert!(validate_curve_params(0, V_TOK, REAL_TOK, 1_000_000_000_000_000).is_err());
        assert!(validate_curve_params(V_SOL, V_TOK, REAL_TOK, REAL_TOK).is_err());
        assert!(validate_curve_params(V_SOL, REAL_TOK, REAL_TOK, 1_000_000_000_000_000).is_err());
    }
}
