use anchor_lang::prelude::*;

pub mod constants;
pub mod errors;
pub mod events;
pub mod instructions;
pub mod math;
pub mod state;

use instructions::*;

declare_id!("J7yRzjdTL9HPaEikZ3vzcU7z6BFqcYKTBkYPqKEbvyrh");

/// Bonding-curve token launchpad.
///
/// * `launch_token` creates a fixed-supply SPL token (mint authority revoked, immutable metadata)
///   and puts it on a constant-product bonding curve.
/// * Every `buy` / `sell` pays a fee (`Global.fee_bps`). `Global.creator_fee_share_bps` of it is earned by
///   the token's creator (claimable with `claim_creator_fees`); the rest goes straight to `Global.fee_recipient`.
/// * When the curve's sale supply is sold out it is `complete`; the migration authority then
///   withdraws the raised SOL and the reserved tokens to seed a DEX pool, and records the pool on-chain.
/// * Sells are never pausable, so holders can always exit while a curve is live.
#[program]
pub mod meme_pump_engine {
    use super::*;

    pub fn initialize_global(ctx: Context<InitializeGlobal>, params: GlobalParams) -> Result<()> {
        instructions::admin::initialize_global(ctx, params)
    }

    pub fn update_global(ctx: Context<UpdateGlobal>, params: UpdateGlobalParams) -> Result<()> {
        instructions::admin::update_global(ctx, params)
    }

    pub fn launch_token(ctx: Context<LaunchToken>, name: String, symbol: String, uri: String) -> Result<()> {
        instructions::launch::handler(ctx, name, symbol, uri)
    }

    pub fn buy(ctx: Context<Buy>, max_sol_in: u64, min_tokens_out: u64) -> Result<()> {
        instructions::trade::buy(ctx, max_sol_in, min_tokens_out)
    }

    pub fn sell(ctx: Context<Sell>, token_amount: u64, min_sol_out: u64) -> Result<()> {
        instructions::trade::sell(ctx, token_amount, min_sol_out)
    }

    pub fn claim_creator_fees(ctx: Context<ClaimCreatorFees>) -> Result<()> {
        instructions::creator::claim_creator_fees(ctx)
    }

    pub fn withdraw_for_migration(ctx: Context<WithdrawForMigration>) -> Result<()> {
        instructions::migration::withdraw_for_migration(ctx)
    }

    pub fn record_migration_pool(ctx: Context<RecordMigrationPool>, pool: Pubkey) -> Result<()> {
        instructions::migration::record_migration_pool(ctx, pool)
    }
}
