use anchor_lang::prelude::*;
use crate::constants::*;
use crate::errors::PumpError;
use crate::events::CreatorFeesClaimed;
use crate::state::CurveState;
use super::move_lamports;

/// The token's creator withdraws their unclaimed share of trading fees.
/// Works at any time, including after the curve has sold out and migrated.
#[derive(Accounts)]
pub struct ClaimCreatorFees<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,

    #[account(
        mut,
        seeds = [CURVE_SEED, curve_state.mint.as_ref()],
        bump = curve_state.bump,
        has_one = creator @ PumpError::Unauthorized,
    )]
    pub curve_state: Box<Account<'info, CurveState>>,
}

pub fn claim_creator_fees(ctx: Context<ClaimCreatorFees>) -> Result<()> {
    let (earned, claimed, mint) = {
        let c = &ctx.accounts.curve_state;
        (c.creator_fees_lamports, c.creator_fees_claimed, c.mint)
    };
    let amount = earned.checked_sub(claimed).ok_or(PumpError::MathOverflow)?;
    require!(amount > 0, PumpError::NothingToClaim);

    move_lamports(
        &ctx.accounts.curve_state.to_account_info(),
        &ctx.accounts.creator.to_account_info(),
        amount,
    )?;
    let c = &mut ctx.accounts.curve_state;
    c.creator_fees_claimed = earned;

    emit!(CreatorFeesClaimed {
        mint,
        creator: ctx.accounts.creator.key(),
        amount,
        total_claimed: earned,
        timestamp: Clock::get()?.unix_timestamp,
    });
    Ok(())
}
