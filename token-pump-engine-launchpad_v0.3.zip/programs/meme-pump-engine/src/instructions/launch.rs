use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    metadata::{create_metadata_accounts_v3, mpl_token_metadata::types::DataV2, CreateMetadataAccountsV3, Metadata},
    token::{self, spl_token::instruction::AuthorityType, Mint, MintTo, SetAuthority, Token, TokenAccount},
};
use crate::constants::*;
use crate::errors::PumpError;
use crate::events::TokenLaunched;
use crate::state::{CurveState, Global, LaunchRecord};

pub const MINT_AUTHORITY_SEED: &[u8] = b"mint_authority";

#[derive(Accounts)]
pub struct LaunchToken<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,

    #[account(mut, seeds = [GLOBAL_SEED], bump = global.bump)]
    pub global: Box<Account<'info, Global>>,

    /// CHECK: PDA that briefly holds mint authority during launch, then revokes it.
    #[account(seeds = [MINT_AUTHORITY_SEED], bump)]
    pub mint_authority: UncheckedAccount<'info>,

    /// New mint keypair, signs the transaction.
    #[account(init, payer = creator, mint::decimals = TOKEN_DECIMALS, mint::authority = mint_authority)]
    pub mint: Box<Account<'info, Mint>>,

    #[account(
        init,
        payer = creator,
        space = 8 + CurveState::INIT_SPACE,
        seeds = [CURVE_SEED, mint.key().as_ref()],
        bump,
    )]
    pub curve_state: Box<Account<'info, CurveState>>,

    #[account(init, payer = creator, associated_token::mint = mint, associated_token::authority = curve_state)]
    pub token_vault: Box<Account<'info, TokenAccount>>,

    #[account(
        init,
        payer = creator,
        space = 8 + LaunchRecord::INIT_SPACE,
        seeds = [LAUNCH_SEED, global.launch_count.to_le_bytes().as_ref()],
        bump,
    )]
    pub launch_record: Box<Account<'info, LaunchRecord>>,

    pub token_metadata_program: Program<'info, Metadata>,

    /// CHECK: metadata PDA, validated and created by the Metaplex Token Metadata program
    #[account(mut)]
    pub metadata: UncheckedAccount<'info>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

pub fn handler(ctx: Context<LaunchToken>, name: String, symbol: String, uri: String) -> Result<()> {
    let (paused, v_sol, v_tok, real_tok, supply, index) = {
        let g = &ctx.accounts.global;
        (
            g.paused,
            g.initial_virtual_sol_reserves,
            g.initial_virtual_token_reserves,
            g.initial_real_token_reserves,
            g.token_total_supply,
            g.launch_count,
        )
    };
    require!(!paused, PumpError::Paused);
    require!(!name.trim().is_empty() && name.len() <= MAX_NAME_LEN, PumpError::InvalidMetadata);
    require!(!symbol.trim().is_empty() && symbol.len() <= MAX_SYMBOL_LEN, PumpError::InvalidMetadata);
    require!(!uri.trim().is_empty() && uri.len() <= MAX_URI_LEN, PumpError::InvalidMetadata);

    let bump = [ctx.bumps.mint_authority];
    let signer_seeds: &[&[&[u8]]] = &[&[MINT_AUTHORITY_SEED, &bump]];

    // 1. Mint the whole fixed supply into the curve's vault.
    token::mint_to(
        CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            MintTo {
                mint: ctx.accounts.mint.to_account_info(),
                to: ctx.accounts.token_vault.to_account_info(),
                authority: ctx.accounts.mint_authority.to_account_info(),
            },
            signer_seeds,
        ),
        supply,
    )?;

    // 2. On-chain metadata, made immutable.
    create_metadata_accounts_v3(
        CpiContext::new_with_signer(
            ctx.accounts.token_metadata_program.to_account_info(),
            CreateMetadataAccountsV3 {
                metadata: ctx.accounts.metadata.to_account_info(),
                mint: ctx.accounts.mint.to_account_info(),
                mint_authority: ctx.accounts.mint_authority.to_account_info(),
                payer: ctx.accounts.creator.to_account_info(),
                update_authority: ctx.accounts.mint_authority.to_account_info(),
                system_program: ctx.accounts.system_program.to_account_info(),
                rent: ctx.accounts.rent.to_account_info(),
            },
            signer_seeds,
        ),
        DataV2 {
            name: name.clone(),
            symbol: symbol.clone(),
            uri: uri.clone(),
            seller_fee_basis_points: 0,
            creators: None,
            collection: None,
            uses: None,
        },
        false,
        true,
        None,
    )?;

    // 3. Revoke mint authority: nobody can ever mint more. (Freeze authority was never set.)
    token::set_authority(
        CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            SetAuthority {
                current_authority: ctx.accounts.mint_authority.to_account_info(),
                account_or_mint: ctx.accounts.mint.to_account_info(),
            },
            signer_seeds,
        ),
        AuthorityType::MintTokens,
        None,
    )?;

    let now = Clock::get()?.unix_timestamp;
    let mint_key = ctx.accounts.mint.key();
    let creator_key = ctx.accounts.creator.key();

    let curve = &mut ctx.accounts.curve_state;
    curve.mint = mint_key;
    curve.creator = creator_key;
    curve.launch_index = index;
    curve.created_at = now;
    curve.virtual_sol_reserves = v_sol;
    curve.virtual_token_reserves = v_tok;
    curve.real_sol_reserves = 0;
    curve.real_token_reserves = real_tok;
    curve.initial_real_token_reserves = real_tok;
    curve.token_total_supply = supply;
    curve.volume_lamports = 0;
    curve.fees_lamports = 0;
    curve.creator_fees_lamports = 0;
    curve.creator_fees_claimed = 0;
    curve.trade_count = 0;
    curve.complete = false;
    curve.migrated = false;
    curve.migration_sol = 0;
    curve.migration_tokens = 0;
    curve.migration_pool = Pubkey::default();
    curve.bump = ctx.bumps.curve_state;

    let record = &mut ctx.accounts.launch_record;
    record.index = index;
    record.mint = mint_key;
    record.creator = creator_key;
    record.created_at = now;
    record.bump = ctx.bumps.launch_record;

    ctx.accounts.global.launch_count = index.checked_add(1).ok_or(PumpError::MathOverflow)?;

    emit!(TokenLaunched {
        index,
        mint: mint_key,
        creator: creator_key,
        name,
        symbol,
        uri,
        virtual_sol_reserves: v_sol,
        virtual_token_reserves: v_tok,
        real_token_reserves: real_tok,
        token_total_supply: supply,
        timestamp: now,
    });
    Ok(())
}
