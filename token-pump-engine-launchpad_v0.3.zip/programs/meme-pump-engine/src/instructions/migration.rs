use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    token::{self, Mint, Token, TokenAccount},
};
use crate::constants::*;
use crate::errors::PumpError;
use crate::events::{MigrationPoolRecorded, MigrationWithdrawn};
use crate::state::{CurveState, Global};
use super::move_lamports;

/// After a curve sells out, the migration authority withdraws its SOL and the reserved
/// tokens to create the DEX pool. Everything is recorded on the curve for anyone to audit.
#[derive(Accounts)]
pub struct WithdrawForMigration<'info> {
    #[account(mut)]
    pub migration_authority: Signer<'info>,

    #[account(seeds = [GLOBAL_SEED], bump = global.bump, has_one = migration_authority @ PumpError::Unauthorized)]
    pub global: Box<Account<'info, Global>>,

    pub mint: Box<Account<'info, Mint>>,

    #[account(mut, seeds = [CURVE_SEED, mint.key().as_ref()], bump = curve_state.bump)]
    pub curve_state: Box<Account<'info, CurveState>>,

    #[account(mut, associated_token::mint = mint, associated_token::authority = curve_state)]
    pub token_vault: Box<Account<'info, TokenAccount>>,

    #[account(
        init_if_needed,
        payer = migration_authority,
        associated_token::mint = mint,
        associated_token::authority = migration_authority,
    )]
    pub destination_token_account: Box<Account<'info, TokenAccount>>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RecordMigrationPool<'info> {
    pub migration_authority: Signer<'info>,

    #[account(seeds = [GLOBAL_SEED], bump = global.bump, has_one = migration_authority @ PumpError::Unauthorized)]
    pub global: Box<Account<'info, Global>>,

    #[account(mut, seeds = [CURVE_SEED, curve_state.mint.as_ref()], bump = curve_state.bump)]
    pub curve_state: Box<Account<'info, CurveState>>,
}

pub fn withdraw_for_migration(ctx: Context<WithdrawForMigration>) -> Result<()> {
    let (complete, migrated, real_sol, bump) = {
        let c = &ctx.accounts.curve_state;
        (c.complete, c.migrated, c.real_sol_reserves, c.bump)
    };
    require!(complete, PumpError::CurveNotCompleted);
    require!(!migrated, PumpError::AlreadyMigrated);

    let tokens = ctx.accounts.token_vault.amount;
    let mint_key = ctx.accounts.mint.key();
    let bump_bytes = [bump];
    let signer_seeds: &[&[&[u8]]] = &[&[CURVE_SEED, mint_key.as_ref(), &bump_bytes]];
    if tokens > 0 {
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                token::Transfer {
                    from: ctx.accounts.token_vault.to_account_info(),
                    to: ctx.accounts.destination_token_account.to_account_info(),
                    authority: ctx.accounts.curve_state.to_account_info(),
                },
                signer_seeds,
            ),
            tokens,
        )?;
    }

    // No CPIs after this point.
    move_lamports(
        &ctx.accounts.curve_state.to_account_info(),
        &ctx.accounts.migration_authority.to_account_info(),
        real_sol,
    )?;

    let now = Clock::get()?.unix_timestamp;
    let c = &mut ctx.accounts.curve_state;
    c.migrated = true;
    c.migration_sol = real_sol;
    c.migration_tokens = tokens;
    c.real_sol_reserves = 0;

    emit!(MigrationWithdrawn {
        mint: mint_key,
        to: ctx.accounts.migration_authority.key(),
        sol_amount: real_sol,
        token_amount: tokens,
        timestamp: now,
    });
    Ok(())
}

pub fn record_migration_pool(ctx: Context<RecordMigrationPool>, pool: Pubkey) -> Result<()> {
    require!(ctx.accounts.curve_state.migrated, PumpError::NotMigrated);
    require!(pool != Pubkey::default(), PumpError::ZeroAmount);
    let c = &mut ctx.accounts.curve_state;
    c.migration_pool = pool;
    emit!(MigrationPoolRecorded { mint: c.mint, pool, timestamp: Clock::get()?.unix_timestamp });
    Ok(())
}
