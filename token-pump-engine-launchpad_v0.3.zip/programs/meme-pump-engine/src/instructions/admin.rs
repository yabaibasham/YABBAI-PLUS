use anchor_lang::prelude::*;
use crate::constants::*;
use crate::errors::PumpError;
use crate::events::GlobalUpdated;
use crate::math::validate_curve_params;
use crate::state::Global;

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Debug, PartialEq, Eq)]
pub struct GlobalParams {
    pub fee_recipient: Pubkey,
    pub migration_authority: Pubkey,
    pub fee_bps: u16,
    pub creator_fee_share_bps: u16,
    pub initial_virtual_sol_reserves: u64,
    pub initial_virtual_token_reserves: u64,
    pub initial_real_token_reserves: u64,
    pub token_total_supply: u64,
}

/// Every field is optional; only the ones you pass change.
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Debug, Default, PartialEq, Eq)]
pub struct UpdateGlobalParams {
    pub new_authority: Option<Pubkey>,
    pub fee_recipient: Option<Pubkey>,
    pub migration_authority: Option<Pubkey>,
    pub fee_bps: Option<u16>,
    pub creator_fee_share_bps: Option<u16>,
    pub paused: Option<bool>,
    pub initial_virtual_sol_reserves: Option<u64>,
    pub initial_virtual_token_reserves: Option<u64>,
    pub initial_real_token_reserves: Option<u64>,
    pub token_total_supply: Option<u64>,
}

/// Only the program's upgrade authority can initialize, so nobody can front-run the deploy
/// and make themselves the fee recipient.
#[cfg(not(feature = "test-mode"))]
#[derive(Accounts)]
pub struct InitializeGlobal<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    #[account(init, payer = authority, space = 8 + Global::INIT_SPACE, seeds = [GLOBAL_SEED], bump)]
    pub global: Box<Account<'info, Global>>,
    #[account(constraint = program.programdata_address()? == Some(program_data.key()) @ PumpError::Unauthorized)]
    pub program: Program<'info, crate::program::MemePumpEngine>,
    #[account(constraint = program_data.upgrade_authority_address == Some(authority.key()) @ PumpError::Unauthorized)]
    pub program_data: Account<'info, ProgramData>,
    pub system_program: Program<'info, System>,
}

/// Same account list as production, but without the upgrade-authority check (local tests only).
#[cfg(feature = "test-mode")]
#[derive(Accounts)]
pub struct InitializeGlobal<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    #[account(init, payer = authority, space = 8 + Global::INIT_SPACE, seeds = [GLOBAL_SEED], bump)]
    pub global: Box<Account<'info, Global>>,
    /// CHECK: unchecked in test-mode builds only
    pub program: UncheckedAccount<'info>,
    /// CHECK: unchecked in test-mode builds only
    pub program_data: UncheckedAccount<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdateGlobal<'info> {
    pub authority: Signer<'info>,
    #[account(mut, seeds = [GLOBAL_SEED], bump = global.bump, has_one = authority @ PumpError::Unauthorized)]
    pub global: Box<Account<'info, Global>>,
}

fn emit_global(g: &Global) {
    emit!(GlobalUpdated {
        authority: g.authority,
        fee_recipient: g.fee_recipient,
        migration_authority: g.migration_authority,
        fee_bps: g.fee_bps,
        creator_fee_share_bps: g.creator_fee_share_bps,
        paused: g.paused,
    });
}

pub fn initialize_global(ctx: Context<InitializeGlobal>, params: GlobalParams) -> Result<()> {
    require!(params.fee_bps <= MAX_FEE_BPS, PumpError::FeeTooHigh);
    require!(params.creator_fee_share_bps <= MAX_CREATOR_SHARE_BPS, PumpError::InvalidCreatorShare);
    validate_curve_params(
        params.initial_virtual_sol_reserves,
        params.initial_virtual_token_reserves,
        params.initial_real_token_reserves,
        params.token_total_supply,
    )?;

    let g = &mut ctx.accounts.global;
    g.authority = ctx.accounts.authority.key();
    g.fee_recipient = params.fee_recipient;
    g.migration_authority = params.migration_authority;
    g.fee_bps = params.fee_bps;
    g.creator_fee_share_bps = params.creator_fee_share_bps;
    g.paused = false;
    g.initial_virtual_sol_reserves = params.initial_virtual_sol_reserves;
    g.initial_virtual_token_reserves = params.initial_virtual_token_reserves;
    g.initial_real_token_reserves = params.initial_real_token_reserves;
    g.token_total_supply = params.token_total_supply;
    g.launch_count = 0;
    g.bump = ctx.bumps.global;
    emit_global(g);
    Ok(())
}

pub fn update_global(ctx: Context<UpdateGlobal>, params: UpdateGlobalParams) -> Result<()> {
    let g = &mut ctx.accounts.global;
    if let Some(v) = params.new_authority {
        g.authority = v;
    }
    if let Some(v) = params.fee_recipient {
        g.fee_recipient = v;
    }
    if let Some(v) = params.migration_authority {
        g.migration_authority = v;
    }
    if let Some(v) = params.fee_bps {
        require!(v <= MAX_FEE_BPS, PumpError::FeeTooHigh);
        g.fee_bps = v;
    }
    if let Some(v) = params.creator_fee_share_bps {
        require!(v <= MAX_CREATOR_SHARE_BPS, PumpError::InvalidCreatorShare);
        g.creator_fee_share_bps = v;
    }
    if let Some(v) = params.paused {
        g.paused = v;
    }
    if let Some(v) = params.initial_virtual_sol_reserves {
        g.initial_virtual_sol_reserves = v;
    }
    if let Some(v) = params.initial_virtual_token_reserves {
        g.initial_virtual_token_reserves = v;
    }
    if let Some(v) = params.initial_real_token_reserves {
        g.initial_real_token_reserves = v;
    }
    if let Some(v) = params.token_total_supply {
        g.token_total_supply = v;
    }
    // Curve changes only affect future launches, but must still be valid together.
    validate_curve_params(
        g.initial_virtual_sol_reserves,
        g.initial_virtual_token_reserves,
        g.initial_real_token_reserves,
        g.token_total_supply,
    )?;
    emit_global(g);
    Ok(())
}
