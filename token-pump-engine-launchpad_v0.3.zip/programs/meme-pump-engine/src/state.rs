use anchor_lang::prelude::*;

/// Platform-wide settings. One per program, PDA seeds = ["global"].
#[account]
#[derive(InitSpace)]
pub struct Global {
    /// Can change settings with `update_global`.
    pub authority: Pubkey,
    /// Receives the platform fee on every buy and sell.
    pub fee_recipient: Pubkey,
    /// Withdraws a sold-out curve's SOL and reserved tokens to seed its DEX pool.
    pub migration_authority: Pubkey,
    /// Platform fee in basis points (100 = 1%), capped at MAX_FEE_BPS.
    pub fee_bps: u16,
    /// Part of each trade fee paid to the token's creator, in bps of the fee (3000 = 30% of the fee).
    pub creator_fee_share_bps: u16,
    /// Pauses launches and buys. Sells always stay open.
    pub paused: bool,
    /// Curve parameters applied to new launches.
    pub initial_virtual_sol_reserves: u64,
    pub initial_virtual_token_reserves: u64,
    /// Tokens sold through the curve. The rest of the supply is reserved for the DEX pool.
    pub initial_real_token_reserves: u64,
    pub token_total_supply: u64,
    /// Number of launches so far; also the index of the next LaunchRecord.
    pub launch_count: u64,
    pub bump: u8,
}

/// One bonding curve per launched token. PDA seeds = ["curve", mint]. Holds the curve's SOL.
#[account]
#[derive(InitSpace)]
pub struct CurveState {
    pub mint: Pubkey,
    pub creator: Pubkey,
    pub launch_index: u64,
    pub created_at: i64,
    pub virtual_sol_reserves: u64,
    pub virtual_token_reserves: u64,
    /// SOL raised and held by this account (excluding its rent).
    pub real_sol_reserves: u64,
    /// Tokens still for sale on the curve.
    pub real_token_reserves: u64,
    /// Tokens that were for sale at launch (for progress = sold / initial).
    pub initial_real_token_reserves: u64,
    pub token_total_supply: u64,
    /// Lifetime SOL traded through the curve (buys in + sells out, before fees).
    pub volume_lamports: u64,
    /// Lifetime platform fees paid by this curve's trades.
    pub fees_lamports: u64,
    /// Lifetime creator share of those fees. Unclaimed creator fees stay in this account
    /// on top of `real_sol_reserves` until the creator calls `claim_creator_fees`.
    pub creator_fees_lamports: u64,
    pub creator_fees_claimed: u64,
    pub trade_count: u64,
    pub complete: bool,
    pub migrated: bool,
    pub migration_sol: u64,
    pub migration_tokens: u64,
    /// DEX pool created with the migrated funds (default pubkey until recorded).
    pub migration_pool: Pubkey,
    pub bump: u8,
}

/// Enumerable launch registry so any RPC can list launches with getMultipleAccounts.
/// PDA seeds = ["launch", index as u64 little-endian].
#[account]
#[derive(InitSpace)]
pub struct LaunchRecord {
    pub index: u64,
    pub mint: Pubkey,
    pub creator: Pubkey,
    pub created_at: i64,
    pub bump: u8,
}
