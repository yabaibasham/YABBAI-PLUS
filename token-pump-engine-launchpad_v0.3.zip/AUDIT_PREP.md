# Mainnet checklist

Real people's SOL sits in the bonding curves. Tick every box before `LAUNCHPAD_CLUSTER=mainnet-beta`.

## Program

- [ ] `npm run test:launchpad` passes (Rust unit + integration tests, client byte checks, AI layer test).
- [ ] Built **without** `--features test-mode` (that feature skips the upgrade-authority check on `initialize_global`).
      `scripts/deploy.sh` builds without it; check `anchor build` output if you build by hand.
- [ ] Independent security audit of `programs/meme-pump-engine`, with findings fixed. Give the auditor this file,
      `DEPLOY.md` and the tests. Areas to point them at:
  - lamport accounting in the curve account: rent + `real_sol_reserves` + unclaimed creator fees, always
  - `sell` and `claim_creator_fees` move lamports directly (no CPI after the debit)
  - rounding: curve and platform side never lose to rounding (`fee_on` rounds up, `split_fee` rounds the creator down)
  - `withdraw_for_migration` (custodial step) and `record_migration_pool`
  - admin powers: fee cap 5%, creator share 0–100% of the fee, pause never blocks sells
- [ ] Devnet run end to end: launch, buy, sell, creator claim, sell-out, withdraw, Raydium pool, record pool.
      Check every transaction on Solscan (`?cluster=devnet`).
- [ ] Decide on the upgrade authority: a hardware wallet or a multisig (Squads). Whoever holds it can change the program.

## Wallets

- [ ] Fee wallet: dedicated, holds > 0.001 SOL, keys only on hardware or in a multisig.
- [ ] Migration wallet: dedicated, publicly named as the graduation wallet, used for nothing else.
- [ ] Admin: your Phantom (or multisig), not the deployer keypair file.
- [ ] No private keys in the repo or in AI Studio files (`deploy-keypair.json` stays out; `.gitignore` covers keypairs).

## App

- [ ] Paid RPC (`SOLANA_MAINNET_RPC`, Helius or QuickNode). Public RPCs block `getTokenLargestAccounts` and rate-limit.
- [ ] `LAUNCHPAD_METRICS_FILE` on a persistent disk, or growth history resets on every deploy.
- [ ] Every sidebar screen that isn't LIVE is either hidden from public users or keeps its banner.
      SIM ONLY screens are never connected to a wallet that holds real funds.

## Business

- [ ] Terms of use and risk disclosure on the site: tokens are speculative, creators are not vetted, no returns are promised.
- [ ] Public fee page: platform fee %, creator share %, fee wallet and migration wallet addresses.
- [ ] Bookkeeping: platform fees arriving in the fee wallet are business income. Export the fee wallet history
      from Solscan for your records. Ask an accountant how token-launch fee income is treated for a sole trader.
- [ ] Get Australian legal advice on running a token launchpad (financial services and AML/CTF rules may apply)
      before opening it to the public on mainnet.
