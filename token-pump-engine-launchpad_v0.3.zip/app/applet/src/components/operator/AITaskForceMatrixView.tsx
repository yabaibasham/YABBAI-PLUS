import React, { useState, useEffect } from 'react';
import {
  Brain,
  Zap,
  Bot,
  TrendingUp,
  Cpu,
  Layers,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Terminal,
  Activity,
  ArrowUpRight,
  Flame,
  Coins,
  RefreshCw,
  Clock,
  Sliders,
  DollarSign,
  Copy,
  Check,
  Lock,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import type {
  AIModelType,
  AIModelEngine,
  StrategyUpgradeDef,
  AIPumpExecutionResult,
} from '../../types';

interface AITaskForceMatrixViewProps {
  walletSolBalance?: number;
  onNavigateToTab?: (tab: string) => void;
  onRefreshGlobal?: () => void;
}

export const AITaskForceMatrixView: React.FC<AITaskForceMatrixViewProps> = ({
  walletSolBalance = 0,
  onNavigateToTab,
  onRefreshGlobal,
}) => {
  // State - Default to GEMINI_4_ARGON as the flagship engine
  const [engines, setEngines] = useState<AIModelEngine[]>([]);
  const [strategies, setStrategies] = useState<StrategyUpgradeDef[]>([]);
  const [selectedEngine, setSelectedEngine] = useState<AIModelType>('GEMINI_4_ARGON');
  const [loading, setLoading] = useState<boolean>(false);
  const [inferring, setInferring] = useState<boolean>(false);
  const [pumping, setPumping] = useState<boolean>(false);
  const [pulsing, setPulsing] = useState<boolean>(false);

  // Pump form parameters
  const [pumpTokenMint, setPumpTokenMint] = useState<string>('7cnu3w5SbTxCrYTPavBJ7dib4Bdnf6mN5AG98xzDpump');
  const [pumpAmountSol, setPumpAmountSol] = useState<number>(0.05);
  const [pumpMode, setPumpMode] = useState<'WAVE_20' | 'SINGLE' | 'RAYDIUM_BOOST'>('WAVE_20');

  // Outputs & Telemetry
  const [inferencePrompt, setInferencePrompt] = useState<string>(
    'Google Gemini 4 Argon: Synthesize an optimal 20-wave pump schedule and multi-token arbitrage sequence for $BASHAM to achieve 85 SOL bonding graduation with zero slippage.'
  );
  const [inferenceResult, setInferenceResult] = useState<string>('');
  const [lastPumpResult, setLastPumpResult] = useState<AIPumpExecutionResult | null>(null);
  const [copiedLlamaCmd, setCopiedLlamaCmd] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [taskForceReports, setTaskForceReports] = useState<any[]>([]);

  const llamaCommand =
    'llama serve -hf DavidAU/Qwen3.8-27B-TURBO-Fable-Cold-Fusion-735-882-Heretic-Uncensored-NEO-CODER-MAX-MTP-GGUF:Q4_K_M --port 8080 -c 8192';

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Fetch Engines & Strategies
  const fetchData = async () => {
    try {
      setLoading(true);
      const [engRes, stratRes] = await Promise.all([
        fetch('/api/ai/engines'),
        fetch('/api/ai/strategies'),
      ]);
      const engData = await engRes.json();
      const stratData = await stratRes.json();

      if (engData.ok) {
        setEngines(engData.engines);
        // Ensure GEMINI_4_ARGON is selected if available
        const hasArgon = engData.engines.some((e: any) => e.id === 'GEMINI_4_ARGON');
        if (hasArgon && selectedEngine !== 'GEMINI_4_ARGON') {
          setSelectedEngine('GEMINI_4_ARGON');
        }
      }
      if (stratData.ok) setStrategies(stratData.strategies);
    } catch (e) {
      console.error('Failed to load AI orchestrator data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Handle Run Inference
  const handleRunInference = async () => {
    try {
      setInferring(true);
      setInferenceResult(`Querying ${selectedEngine}... Deep reasoning synthesis in progress across frontier models.`);
      const res = await fetch('/api/ai/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          engineId: selectedEngine,
          prompt: inferencePrompt,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setInferenceResult(data.responseText);
        showToast(`Inference synthesized via ${data.engineUsed} (${data.latencyMs}ms)`);
      } else {
        setInferenceResult(`Synthesis error: ${data.error || 'Server rejected request'}`);
      }
    } catch (e: any) {
      setInferenceResult(`Execution error: ${e?.message || 'Unknown network error'}`);
    } finally {
      setInferring(false);
    }
  };

  // Handle Execute AI Pump
  const handleExecuteAIPump = async () => {
    try {
      setPumping(true);
      const res = await fetch('/api/ai/execute-pump', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tokenMint: pumpTokenMint,
          solAmount: pumpAmountSol,
          modelType: selectedEngine,
          mode: pumpMode,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setLastPumpResult(data.execution);
        showToast(`AI Pump Verified! +${data.execution.bondingPctIncrease}% Curve Push via ${data.execution.modelName}`);
        fetchData();
        if (onRefreshGlobal) onRefreshGlobal();
      } else {
        showToast(`Pump execution failed: ${data.error}`);
      }
    } catch (e: any) {
      showToast(`Pump error: ${e?.message || 'Network error'}`);
    } finally {
      setPumping(false);
    }
  };

  // Handle Strategy Upgrade
  const handleUpgradeStrategy = async (strategyId: string) => {
    try {
      const res = await fetch('/api/ai/upgrade-strategy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ strategyId }),
      });
      const data = await res.json();
      if (data.ok) {
        showToast(`Strategy upgraded to Level ${data.upgraded.level}: ${data.upgraded.name}`);
        fetchData();
      } else {
        showToast(`Upgrade failed: ${data.error}`);
      }
    } catch (e: any) {
      showToast(`Upgrade error: ${e?.message}`);
    }
  };

  // Handle Task Force Pulse
  const handleTaskForcePulse = async () => {
    try {
      setPulsing(true);
      const res = await fetch('/api/ai/task-force-pulse', {
        method: 'POST',
      });
      const data = await res.json();
      if (data.ok) {
        setTaskForceReports(data.pulse.squadronReports);
        setInferenceResult(data.pulse.aiSynthesis);
        showToast(`Task Force Pulse synchronized! +${data.pulse.feeGeneratedSol} SOL fee added.`);
        fetchData();
      }
    } catch (e: any) {
      showToast(`Pulse error: ${e?.message}`);
    } finally {
      setPulsing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedLlamaCmd(true);
    setTimeout(() => setCopiedLlamaCmd(false), 2000);
    showToast('Llama serve command copied to clipboard!');
  };

  return (
    <div className="space-y-6 text-[#e8edf5]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-[#ffd60a] text-[#060a12] font-mono text-xs font-bold px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 border border-[#ffe74d] animate-in fade-in slide-in-from-top duration-200">
          <Sparkles className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* TOP HERO HEADER - MASTER CRYPTO TERMINAL */}
      <div className="rounded-2xl bg-[#090d16] border border-[#1b263b] p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
              <span className="font-bold tracking-wider uppercase">DeepMind Frontier Mesh</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-emerald-400 font-semibold">Gemini 4 Argon Core Active</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-slate-400">1M Context Window</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>BASHAM Sovereign AI Crypto Engine</span>
              <span className="text-xs font-mono font-bold text-amber-400 border border-amber-400/40 bg-amber-400/10 px-2 py-0.5 rounded">
                ARGON 4 UPGRADED
              </span>
            </h1>

            <p className="text-xs sm:text-sm text-[#8a9bb4] max-w-2xl font-mono leading-relaxed">
              Google Gemini 4 Argon deep reasoning core synchronized with JEV Elasticity Math, Liquid AI d1-3B continuous state-space dynamics, and local Qwen3.8-27B-TURBO GGUF to execute autonomous bonding curve pumps, harvest AMM yield, and conquer the Solana token market.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0 font-mono text-xs">
            <button
              type="button"
              onClick={handleTaskForcePulse}
              disabled={pulsing}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
            >
              <Activity className={`w-4 h-4 ${pulsing ? 'animate-spin' : ''}`} />
              <span>{pulsing ? 'Synchronizing Mesh...' : 'Task Force Pulse'}</span>
            </button>

            <button
              type="button"
              onClick={fetchData}
              disabled={loading}
              className="px-3.5 py-2.5 rounded-xl bg-[#111827] border border-[#223048] hover:border-[#384d72] text-[#8a9bb4] hover:text-white font-bold flex items-center gap-1.5 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>
        </div>

        {/* Live Token Status Quickbar - Zero-Pill High Contrast */}
        <div className="mt-6 pt-4 border-t border-[#172133] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="bg-[#05080f] border border-[#162235] p-3 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase font-bold tracking-wider">Target Token</div>
            <div className="font-bold text-white flex items-center gap-1.5 mt-1 truncate">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>$BASHAM (pump.fun)</span>
            </div>
            <div className="text-[10px] text-cyan-400/80 truncate font-mono mt-0.5">7cnu3w5...Dpump</div>
          </div>

          <div className="bg-[#05080f] border border-[#162235] p-3 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase font-bold tracking-wider">Active AI Driver</div>
            <div className="font-bold text-cyan-300 mt-1 flex items-center gap-1.5">
              <span>Gemini 4 Argon</span>
              <span className="text-[10px] text-emerald-400">· 100% Online</span>
            </div>
            <div className="text-[10px] text-[#8a9bb4] mt-0.5">DeepMind 1M Reasoning Core</div>
          </div>

          <div className="bg-[#05080f] border border-[#162235] p-3 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase font-bold tracking-wider">Strategy Earning Tier</div>
            <div className="font-bold text-amber-300 mt-1 flex items-center gap-1.5">
              <span>Level 3 / 6 Active</span>
              <span className="text-[10px] text-emerald-400 font-bold">· 2.4x Multiplier</span>
            </div>
            <div className="text-[10px] text-[#8a9bb4] mt-0.5">Target: 9.2x BASHAM Takeover</div>
          </div>

          <div className="bg-[#05080f] border border-[#162235] p-3 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase font-bold tracking-wider">Treasury Solana Pool</div>
            <div className="font-bold text-emerald-400 mt-1 truncate text-sm">
              {walletSolBalance.toFixed(4)} SOL
            </div>
            <div className="text-[10px] text-[#8a9bb4] mt-0.5">Live On-Chain RPC Buffer</div>
          </div>
        </div>
      </div>

      {/* SECTION 1: HOOKED-UP MULTI-AI ENGINES MATRIX */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white uppercase tracking-wider font-mono">
              Hooked-Up AI Model Ensemble
            </h2>
          </div>
          <span className="text-xs text-[#8a9bb4] font-mono">
            Active Driver: <strong className="text-cyan-400">{selectedEngine}</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {engines.map((eng) => {
            const isSelected = selectedEngine === eng.id;
            const isArgon = eng.id === 'GEMINI_4_ARGON';

            return (
              <div
                key={eng.id}
                onClick={() => setSelectedEngine(eng.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all relative flex flex-col justify-between ${
                  isSelected
                    ? isArgon
                      ? 'bg-[#0b1325] border-amber-400 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400'
                      : 'bg-[#0d1627] border-cyan-400 shadow-xl shadow-cyan-500/10 ring-1 ring-cyan-400'
                    : 'bg-[#080d16] border-[#182335] hover:border-[#273852] hover:bg-[#0b111c]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs font-mono">
                    <span className="text-[10px] font-bold text-[#8a9bb4]">
                      {eng.provider}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>{eng.status}</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 mt-2.5">
                    <h3 className="font-bold text-sm text-white">{eng.name}</h3>
                  </div>

                  <div className="text-[11px] font-mono text-amber-300/90 mt-0.5 line-clamp-1 font-semibold">
                    {eng.tag}
                  </div>

                  <p className="text-[11px] text-[#8a9bb4] mt-2 line-clamp-3 leading-relaxed">
                    {eng.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#162133] space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#6b7c96]">
                    <span>Latency:</span>
                    <span className="text-white font-bold">{eng.latencyMs}ms</span>
                  </div>

                  <div className="flex flex-wrap gap-1 text-[9px] font-mono text-[#93a7c4]">
                    {eng.capabilities.slice(0, 2).map((cap, i) => (
                      <span key={cap} className="bg-[#101827] px-1.5 py-0.5 rounded border border-[#1f2b40]">
                        {cap}
                      </span>
                    ))}
                  </div>

                  {isSelected && (
                    <div className="text-[10px] font-mono text-amber-400 font-bold flex items-center justify-end gap-1 mt-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>PRIMARY DRIVER</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Local Llama Serve Quick Launcher Banner */}
        <div className="p-3.5 rounded-xl bg-[#060a12] border border-cyan-500/20 font-mono text-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <Terminal className="w-4 h-4 text-cyan-400 shrink-0" />
            <div className="min-w-0">
              <span className="text-white font-bold">Llama Serve CLI (Qwen3.8-27B-TURBO GGUF): </span>
              <span className="text-[#8a9bb4] truncate block md:inline text-[11px]">
                {llamaCommand}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => copyToClipboard(llamaCommand)}
            className="px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center gap-1.5 text-xs font-bold shrink-0 transition-colors"
          >
            {copiedLlamaCmd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLlamaCmd ? 'COPIED!' : 'COPY COMMAND'}</span>
          </button>
        </div>
      </div>

      {/* SECTION 2: INTERACTIVE AI STRATEGY INFERENCE & LIVE PUMP TERMINAL */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LEFT COLUMN: AI STRATEGIC REASONING & INFERENCE ENGINE */}
        <div className="rounded-xl bg-[#080d16] border border-[#1b263b] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-sm text-white font-mono uppercase tracking-wider">
                Argon 4 Strategic Reasoning Core
              </h3>
            </div>
            <span className="text-[11px] font-mono text-cyan-400 font-bold">
              Active: {engines.find((e) => e.id === selectedEngine)?.name || selectedEngine}
            </span>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-mono text-[#8a9bb4] uppercase tracking-wider">
              Strategic Directive Prompt
            </label>
            <textarea
              rows={3}
              value={inferencePrompt}
              onChange={(e) => setInferencePrompt(e.target.value)}
              className="w-full bg-[#05080f] border border-[#1b263b] focus:border-cyan-500/50 rounded-xl p-3 text-xs text-white font-mono focus:outline-none transition-colors"
              placeholder="Enter strategy prompt..."
            />
          </div>

          {/* Prompt Presets */}
          <div className="flex flex-wrap items-center gap-1.5 font-mono text-[11px]">
            <span className="text-[#6b7c96]">Presets:</span>
            <button
              type="button"
              onClick={() =>
                setInferencePrompt(
                  'Google Gemini 4 Argon: Synthesize an optimal 20-wave pump schedule and multi-token arbitrage sequence for $BASHAM to achieve 85 SOL bonding graduation with zero slippage.'
                )
              }
              className="px-2.5 py-1 rounded bg-[#101827] border border-[#1c293f] hover:text-white text-[#8a9bb4] transition-colors"
            >
              Argon 4 Pump Wave
            </button>
            <button
              type="button"
              onClick={() =>
                setInferencePrompt(
                  'Analyze token $BASHAM bonding curve elasticity. What is the optimal SOL injection size to accelerate Raydium migration without triggering high slippage?'
                )
              }
              className="px-2.5 py-1 rounded bg-[#101827] border border-[#1c293f] hover:text-white text-[#8a9bb4] transition-colors"
            >
              Curve Elasticity
            </button>
            <button
              type="button"
              onClick={() =>
                setInferencePrompt(
                  'Audit Solana bonding curve contract invariants: verify mint authority revocation post-migration and permanent LP burn proof.'
                )
              }
              className="px-2.5 py-1 rounded bg-[#101827] border border-[#1c293f] hover:text-white text-[#8a9bb4] transition-colors"
            >
              Contract Audit
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRunInference}
              disabled={inferring}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#060a12] font-mono font-bold text-xs flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-amber-400/10"
            >
              <Sparkles className={`w-3.5 h-3.5 ${inferring ? 'animate-spin' : ''}`} />
              <span>{inferring ? 'Synthesizing Reasoning...' : 'Run Argon 4 Inference'}</span>
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="text-[11px] font-mono text-[#8a9bb4] uppercase tracking-wider flex items-center justify-between">
              <span>Model Output & Synthesis</span>
              {inferring && <span className="text-cyan-400 animate-pulse">Running live neural pass...</span>}
            </div>
            <div className="p-3.5 rounded-xl bg-[#05080f] border border-[#162235] text-xs font-mono text-cyan-300 leading-relaxed whitespace-pre-wrap min-h-36 max-h-64 overflow-y-auto">
              {inferenceResult || (
                <span className="text-[#4b5563]">
                  Select an engine above and click &quot;Run Argon 4 Inference&quot; to synthesize optimal token strategies across Gemini 4 Argon, JEV, LiquidAI, or Qwen-TURBO.
                </span>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIONABLE AI PUMP & TOKEN TERMINAL */}
        <div className="rounded-xl bg-[#080d16] border border-[#1b263b] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <h3 className="font-bold text-sm text-white font-mono uppercase tracking-wider">
                Autonomous Pump & Buyback Terminal
              </h3>
            </div>
            <span className="text-[11px] font-mono text-rose-400 font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
              <span>LIVE PUMP ENGINE</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-[#8a9bb4] uppercase font-bold">Target Token Mint</label>
              <input
                type="text"
                value={pumpTokenMint}
                onChange={(e) => setPumpTokenMint(e.target.value)}
                className="w-full bg-[#05080f] border border-[#1b263b] rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-[#8a9bb4] uppercase font-bold">Injection Amount (SOL)</label>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  step="0.01"
                  min="0.001"
                  value={pumpAmountSol}
                  onChange={(e) => setPumpAmountSol(parseFloat(e.target.value) || 0.01)}
                  className="w-full bg-[#05080f] border border-[#1b263b] rounded-xl px-3 py-2 text-xs text-emerald-400 font-mono font-bold focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Quick presets for SOL amount */}
          <div className="flex items-center gap-1.5 font-mono text-[11px]">
            <span className="text-[#6b7c96]">Quick Size:</span>
            {[0.01, 0.05, 0.1, 0.25, 0.5].map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => setPumpAmountSol(amt)}
                className={`px-2.5 py-1 rounded-lg border font-bold transition-all ${
                  pumpAmountSol === amt
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    : 'bg-[#101827] text-[#8a9bb4] border-[#1b263b] hover:text-white'
                }`}
              >
                {amt} SOL
              </button>
            ))}
          </div>

          {/* Execution Mode */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#8a9bb4] uppercase font-bold">Execution Mode</label>
            <div className="grid grid-cols-3 gap-2 font-mono text-xs">
              {[
                { id: 'WAVE_20', label: '20-Trade Wave', sub: 'Stealth retail' },
                { id: 'SINGLE', label: 'Instant Push', sub: 'Burst pump' },
                { id: 'RAYDIUM_BOOST', label: '90% SOL Pool', sub: 'Raydium depth' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPumpMode(m.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    pumpMode === m.id
                      ? 'bg-rose-500/10 border-rose-500/50 text-rose-300'
                      : 'bg-[#05080f] border-[#1b263b] text-[#8a9bb4] hover:text-white'
                  }`}
                >
                  <div className="font-bold text-white text-[11px]">{m.label}</div>
                  <div className="text-[10px] text-[#6b7c96]">{m.sub}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Execute Button */}
          <button
            type="button"
            onClick={handleExecuteAIPump}
            disabled={pumping}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 via-amber-500 to-amber-400 hover:from-rose-400 hover:to-amber-300 text-[#060a12] font-mono font-extrabold text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-xl shadow-rose-950/40 active:scale-[0.98] transition-all"
          >
            <Flame className={`w-4 h-4 ${pumping ? 'animate-bounce' : ''}`} />
            <span>
              {pumping
                ? 'AI TASK FORCE EXECUTING PUMP...'
                : `EXECUTE AI-OPTIMIZED PUMP (${pumpAmountSol} SOL)`}
            </span>
          </button>

          {/* Last Pump Telemetry Result Card */}
          {lastPumpResult && (
            <div className="p-3.5 rounded-xl bg-[#05080f] border border-emerald-500/30 font-mono text-xs space-y-2">
              <div className="flex items-center justify-between text-emerald-400 font-bold">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Execution Verified</span>
                </span>
                <span>+{lastPumpResult.bondingPctIncrease}% Curve Push</span>
              </div>
              <div className="text-[11px] text-[#8a9bb4]">{lastPumpResult.rationale}</div>
              <div className="pt-2 border-t border-[#162235] flex items-center justify-between text-[10px] text-[#6b7c96]">
                <span>Tx Signature:</span>
                <span className="text-cyan-400 truncate max-w-44">{lastPumpResult.txSignature}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SECTION 3: TOKEN STRATEGY UPGRADES FOUNDRY ("EARN AS MUCH MONEY & UPGRADE GAINING TOKEN STRATEGIES") */}
      <div className="rounded-xl bg-[#080d16] border border-[#1b263b] p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <h2 className="text-base font-bold text-white uppercase tracking-wider font-mono">
                Upgradeable Token Strategies Foundry
              </h2>
            </div>
            <p className="text-xs text-[#8a9bb4] font-mono mt-0.5">
              Unlock progressive quantitative strategies powered by Gemini 4 Argon throughout the project to maximize SOL earnings and compound bonding curve volume.
            </p>
          </div>

          <div className="text-emerald-400 font-mono text-xs font-bold flex items-center gap-1.5">
            <Coins className="w-4 h-4" />
            <span>EARNING ACCELERATOR: 9.2X MAX</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {strategies.map((strat) => {
            const isAvailable = strat.status === 'AVAILABLE';

            return (
              <div
                key={strat.id}
                className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                  strat.status === 'ACTIVE'
                    ? 'bg-[#0a1424] border-emerald-500/50 shadow-md shadow-emerald-950/20'
                    : isAvailable
                    ? 'bg-[#0c1422] border-cyan-500/40 hover:border-cyan-400'
                    : 'bg-[#060a12] border-[#141d2c] opacity-60'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-[10px] font-bold text-[#8a9bb4]">
                      LEVEL {strat.level} · {strat.category}
                    </span>
                    <span
                      className={`text-[10px] font-bold ${
                        strat.status === 'ACTIVE'
                          ? 'text-emerald-400'
                          : isAvailable
                          ? 'text-cyan-400'
                          : 'text-gray-500'
                      }`}
                    >
                      {strat.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-white">{strat.name}</h3>
                  <p className="text-[11px] text-[#8a9bb4] leading-relaxed line-clamp-3">
                    {strat.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#141e2e] space-y-3 font-mono">
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="bg-[#05080f] p-2 rounded-lg border border-[#162235]">
                      <div className="text-[#6b7c96]">Expected Yield</div>
                      <div className="text-emerald-400 font-bold text-xs mt-0.5">
                        +{strat.expectedYieldSol} SOL
                      </div>
                    </div>
                    <div className="bg-[#05080f] p-2 rounded-lg border border-[#162235]">
                      <div className="text-[#6b7c96]">Multiplier</div>
                      <div className="text-amber-300 font-bold text-xs mt-0.5">
                        {strat.boostMultiplier}x Boost
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[#8a9bb4]">Recommended AI:</span>
                    <span className="text-cyan-400 font-bold">{strat.aiEngineRecommended}</span>
                  </div>

                  {/* Action button */}
                  {strat.status === 'ACTIVE' ? (
                    <div className="w-full py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-center text-xs font-bold flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>STRATEGY DEPLOYED ({strat.actionCount} Actions)</span>
                    </div>
                  ) : isAvailable ? (
                    <button
                      type="button"
                      onClick={() => handleUpgradeStrategy(strat.id)}
                      className="w-full py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950/40 active:scale-95 transition-all"
                    >
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>UPGRADE STRATEGY (Cost: {strat.costSol} SOL)</span>
                    </button>
                  ) : (
                    <div className="w-full py-2 rounded-lg bg-[#0d131f] text-gray-500 text-center text-xs font-bold cursor-not-allowed">
                      <span>LOCKED · UNLOCK PREVIOUS LEVEL FIRST</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 4: TASK FORCE SQUADRONS SYNCHRONIZED REPORTS */}
      {taskForceReports.length > 0 && (
        <div className="rounded-xl bg-[#080d16] border border-[#1b263b] p-5 space-y-3 font-mono">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>Coordinated Task Force Squadron Reports</span>
            </h3>
            <span className="text-[11px] text-emerald-400 font-bold">All 4 Squadrons Reporting</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {taskForceReports.map((rep, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-[#05080f] border border-[#162235] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{rep.squadron}</span>
                  <span className="text-[10px] text-emerald-400 font-bold">
                    {rep.status}
                  </span>
                </div>
                <div className="text-[11px] text-amber-300">Leader: {rep.leader}</div>
                <div className="text-[11px] text-[#8a9bb4]">{rep.result}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
