# Deploying the launchpad

The launchpad has two parts:

- **The on-chain program** (`programs/meme-pump-engine`, Anchor 0.30.1). It launches tokens, runs the bonding
  curves and pays your platform fee on every trade. You deploy it once with the Solana and Anchor CLIs.
- **The app** (this AI Studio project). The Launchpad screen reads everything from the chain, and every action is
  a transaction your wallet signs. The server only reads chain data and relays signed transactions. It never holds
  keys.

Do everything on **devnet** first. It's free, and nothing there has real value.

## Before real money goes in

- **Get the program audited.** It has been rebuilt and tested: 11 Rust tests run it on a local Solana runtime
  with the real SPL Token program, including a full launch, trade, sell-out and migration. The browser client is
  also checked byte-for-byte against the program. None of that replaces an independent security audit, though.
  People's SOL sits in the curves.
- **Graduation is briefly custodial.** When a curve sells out, the *migration wallet* receives the raised SOL and
  the reserved tokens. It then creates the Raydium pool, burns the LP tokens and records the pool on-chain. Use a
  dedicated wallet for this and say so publicly. Every step is visible on Solscan.
- **Fund the fee wallet** with at least 0.001 SOL so it can receive small fees.
- **Don't put money in `deploy-keypair.json`.** It's a private key that sits in your project files. Use a fresh
  CLI wallet as the deployer, as described below.

## 1. Install the tools (on Windows, use WSL Ubuntu)

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh                       # Rust
sh -c "$(curl -sSfL https://release.anza.xyz/stable/install)"                        # Solana CLI
cargo install --git https://github.com/coral-xyz/anchor avm --locked && avm install 0.30.1 && avm use 0.30.1
```

## 2. Set the program ID

`declare_id!` in `programs/meme-pump-engine/src/lib.rs` is `J7yRzjdTL9HPaEikZ3vzcU7z6BFqcYKTBkYPqKEbvyrh`. That
address belongs to your original `target/deploy/meme_pump_engine-keypair.json`, which isn't in this zip because
it's a private key. Either:

- copy your original file back into `target/deploy/`, or
- run `anchor keys sync` to generate a new program address. Then set `LAUNCHPAD_PROGRAM_ID` to it in the app
  (step 5).

## 3. Test, build and deploy to devnet

```bash
solana-keygen new -o ~/.config/solana/id.json      # deployer wallet = upgrade authority; back it up
solana config set --url devnet
solana airdrop 5                                   # or https://faucet.solana.com
cargo test -p meme-pump-engine --features test-mode
npx tsx scripts/launchpad-client.test.ts           # app client vs program, byte for byte
./scripts/deploy.sh devnet                         # runs the tests, anchor build, anchor deploy
```

## 4. Initialize (one time) and hand the admin role to Phantom

Only the deployer (the program's upgrade authority) can do this. Nobody can front-run it and make themselves the
fee recipient.

```bash
npx tsx scripts/launchpad-admin.ts init --cluster devnet \
  --admin <YOUR_PHANTOM_ADDRESS> \
  --fee-wallet <WALLET_THAT_RECEIVES_FEES> \
  --migration-wallet <WALLET_THAT_RUNS_GRADUATIONS> \
  --fee-bps 100 \                                 # 100 = 1%, max 500 = 5%
  --creator-share-bps 3000                        # creators get 30% of each fee (0.3% of volume at a 1% fee)
npx tsx scripts/launchpad-admin.ts status --cluster devnet
```

This uses the pump-style curve: about 85 SOL sells out a token, 793.1M of the 1B supply is sold on the curve, and
206.9M is kept for the DEX pool. After this step, change the fee, wallets or pause state from the app's
**Launchpad → Platform** tab while connected as the admin.

> **Upgrading from v0.2?** v0.3 adds fields to the `Global` and curve accounts, so a v0.2 deployment's existing
> accounts can't be read by v0.3. If v0.2 is already on devnet, run `anchor keys sync` for a fresh program ID,
> deploy v0.3 there, and set `LAUNCHPAD_PROGRAM_ID`. Nothing on mainnet is affected because v0.2 was never deployed there.

## 5. Configure the app in AI Studio

Add these as secrets or environment variables:

| Name | Value |
|---|---|
| `LAUNCHPAD_CLUSTER` | `devnet` for now, `mainnet-beta` later |
| `LAUNCHPAD_PROGRAM_ID` | only if you changed it in step 2 |
| `SOLANA_DEVNET_RPC` / `SOLANA_MAINNET_RPC` | optional: your Helius or QuickNode URL (more reliable than public RPCs) |
| `GEMINI_API_KEY` | optional: AI launch drafts, risk summaries and growth notes. Without it, rule-based results still show. |
| `LAUNCHPAD_AI_MODEL` | optional: Gemini model for the launchpad AI (falls back to `GEMINI_MODEL`, then `gemini-2.5-flash`) |
| `LAUNCHPAD_METRICS_FILE` | optional: where growth snapshots are kept. Put it on a persistent disk on Render, or history resets on each deploy. |
| `PINATA_JWT` | optional: lets the Launch form upload the image and metadata to IPFS. Without it, creators paste a metadata URL. |

Files to add or replace are listed in `CHANGES.md`.

## 6. Try it on devnet

In Phantom, open Settings → Developer Settings, turn on Testnet Mode and choose Solana Devnet. Get devnet SOL from
the faucet. Then launch a test token, buy, sell, and check each transaction on Solscan (`?cluster=devnet`).

## 7. Mainnet

Work through `AUDIT_PREP.md` first. It lists what must be true before real SOL goes into curves.

- Deploying needs SOL for program rent. Run `solana program show <PROGRAM_ID> --url devnet` after the devnet
  deploy to see the size, and `solana rent <bytes>` for the cost. Expect a few SOL, which comes back if you
  close the program.
- `solana config set --url mainnet-beta`, then `./scripts/deploy.sh mainnet-beta`, then step 4 with
  `--cluster mainnet-beta`.
- Set `LAUNCHPAD_CLUSTER=mainnet-beta` and a mainnet RPC in AI Studio.

## Graduating a sold-out token

1. The token appears in **Platform → Graduation queue**.
2. Connect the migration wallet and press **Withdraw**. The SOL and reserved tokens move to that wallet.
3. On raydium.io, create a CPMM pool with exactly those amounts, so the opening price matches the curve's final
   price.
4. Burn the pool's LP tokens (Raydium's Burn & Earn, or send them to a burn address).
5. Paste the pool ID and press **Record**. It's stored on the token's curve account for anyone to check.

## Where your platform fees show up

Each trade splits its fee in the same transaction: the platform part goes straight to the fee wallet, and the
creator part stays in that token's curve account until the creator claims it (Creator earnings tab). The header shows
both totals from the program's on-chain counters, next to the fee wallet's live balance. **The fee wallet balance on
Solscan is your real revenue.** Every other number is a counter you can check against it.
